#!/usr/bin/env python3
"""Method-aligned criterion-family discovery and robustness analysis.

Important safeguards
--------------------
* Approved family labels are not read until all embeddings, cluster scans, and the
  selected agglomerative partition have been fitted.
* Stability is estimated by subsampling 85% of the corpus without replacement;
  outputs therefore use the term ``resampling`` rather than ``bootstrap``.
* HDBSCAN uses cosine dissimilarity as the primary specification. The historical
  Euclidean implementation is retained only as a sensitivity specification.
"""
from __future__ import annotations

import argparse
import json
import math
import warnings
from collections import Counter
from pathlib import Path
from typing import Any

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.cluster.hierarchy import cut_tree, dendrogram, linkage
from scipy.sparse import hstack
from scipy.spatial.distance import cdist
from sklearn.cluster import AgglomerativeClustering, HDBSCAN
from sklearn.decomposition import TruncatedSVD
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics import (
    adjusted_rand_score,
    normalized_mutual_info_score,
    pairwise_distances,
    silhouette_samples,
    silhouette_score,
)
from sklearn.preprocessing import Normalizer


def load_config(root: Path) -> dict[str, Any]:
    return json.loads((root / "config/study_config.json").read_text(encoding="utf-8"))


def save_csv(path: Path, frame: pd.DataFrame) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    frame.to_csv(path, index=False, encoding="utf-8-sig")


def build_text(row: pd.Series, spec: dict[str, int]) -> str:
    fields = []
    fields.extend([str(row["source_name"])] * int(spec["name_repeat"]))
    fields.extend([str(row["description"])] * int(spec["description_repeat"]))
    fields.extend([f"Parent criterion: {row['source_parent_name']}"] * int(spec["parent_repeat"]))
    return ". ".join(x for x in fields if x and x.lower() != "nan")


def make_embedding(texts: list[str], cfg: dict[str, Any]) -> tuple[np.ndarray, dict[str, Any]]:
    word = TfidfVectorizer(
        lowercase=True,
        strip_accents="unicode",
        analyzer="word",
        ngram_range=tuple(cfg["word_ngram_range"]),
        min_df=1,
        sublinear_tf=True,
    )
    char = TfidfVectorizer(
        lowercase=True,
        strip_accents="unicode",
        analyzer="char_wb",
        ngram_range=tuple(cfg["character_ngram_range"]),
        min_df=1,
        sublinear_tf=True,
    )
    word_matrix = word.fit_transform(texts)
    char_matrix = char.fit_transform(texts)
    matrix = hstack([word_matrix, float(cfg["character_block_scale"]) * char_matrix]).tocsr()
    retained = min(int(cfg["svd_components"]), matrix.shape[0] - 1, matrix.shape[1] - 1)
    if retained < 2:
        raise ValueError("The corpus is too small for the configured SVD representation.")
    svd = TruncatedSVD(n_components=retained, random_state=int(cfg["embedding_seed"]))
    embedding = Normalizer(copy=False).fit_transform(svd.fit_transform(matrix))
    return embedding, {
        "n_items": len(texts),
        "word_features": word_matrix.shape[1],
        "character_features": char_matrix.shape[1],
        "combined_features": matrix.shape[1],
        "svd_dimensions": retained,
        "explained_variance_ratio": float(svd.explained_variance_ratio_.sum()),
    }


def agglomerative(embedding: np.ndarray, k: int) -> np.ndarray:
    return AgglomerativeClustering(n_clusters=k, metric="cosine", linkage="average").fit_predict(embedding)


def resampling_stability(
    embedding: np.ndarray,
    full_labels: np.ndarray,
    k: int,
    repetitions: int,
    fraction: float,
    seed: int,
) -> dict[str, float]:
    rng = np.random.default_rng(seed)
    n = len(embedding)
    size = min(n, max(k + 2, int(round(fraction * n))))
    values: list[float] = []
    for _ in range(repetitions):
        indices = np.sort(rng.choice(n, size=size, replace=False))
        subset_labels = agglomerative(embedding[indices], k)
        values.append(adjusted_rand_score(full_labels[indices], subset_labels))
    arr = np.asarray(values, dtype=float)
    return {
        "resampling_ari_mean": float(arr.mean()),
        "resampling_ari_sd": float(arr.std()),
        "resampling_ari_p10": float(np.quantile(arr, 0.10)),
        "resampling_ari_p90": float(np.quantile(arr, 0.90)),
    }


def resampling_stability_grid(
    embedding: np.ndarray,
    full_labels_by_k: dict[int, np.ndarray],
    cluster_counts: list[int],
    repetitions: int,
    fraction: float,
    seed: int,
) -> dict[int, dict[str, float]]:
    """Compute stability for all candidate k values from shared resamples.

    In the frozen configuration, every candidate k uses the same 85% subsample
    size and the same seeded sequence of subsets. Average-linkage hierarchy is
    therefore fitted once per subset and cut at every candidate k. This is
    partition-equivalent to fitting ``AgglomerativeClustering`` separately for
    each k, but avoids thousands of duplicate hierarchy fits.
    """
    n = len(embedding)
    base_size = int(round(fraction * n))
    sizes = {k: min(n, max(k + 2, base_size)) for k in cluster_counts}

    # General fallback for configurations where k changes the subsample size.
    if len(set(sizes.values())) != 1:
        return {
            k: resampling_stability(embedding, full_labels_by_k[k], k, repetitions, fraction, seed)
            for k in cluster_counts
        }

    size = next(iter(sizes.values()))
    rng = np.random.default_rng(seed)
    values: dict[int, list[float]] = {k: [] for k in cluster_counts}
    for _ in range(repetitions):
        indices = np.sort(rng.choice(n, size=size, replace=False))
        subset_embedding = embedding[indices]
        hierarchy = linkage(subset_embedding, method="average", metric="cosine")
        partitions = cut_tree(hierarchy, n_clusters=cluster_counts)
        for column, k in enumerate(cluster_counts):
            values[k].append(
                adjusted_rand_score(full_labels_by_k[k][indices], partitions[:, column])
            )

    results: dict[int, dict[str, float]] = {}
    for k, scores in values.items():
        arr = np.asarray(scores, dtype=float)
        results[k] = {
            "resampling_ari_mean": float(arr.mean()),
            "resampling_ari_sd": float(arr.std()),
            "resampling_ari_p10": float(np.quantile(arr, 0.10)),
            "resampling_ari_p90": float(np.quantile(arr, 0.90)),
        }
    return results


def cluster_summary(
    corpus: pd.DataFrame,
    embedding: np.ndarray,
    labels: np.ndarray,
    solution: str,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    cluster_rows: list[dict[str, Any]] = []
    assignment_rows: list[dict[str, Any]] = []
    silhouettes = silhouette_samples(embedding, labels, metric="cosine")
    unique = sorted(np.unique(labels))
    for cluster_id in unique:
        indices = np.where(labels == cluster_id)[0]
        sub = embedding[indices]
        distances = cdist(sub, sub, metric="cosine")
        medoid_idx = indices[int(np.argmin(distances.sum(axis=1)))]
        source_counts = corpus.iloc[indices]["model_id"].value_counts().to_dict()
        cluster_rows.append(
            {
                "solution": solution,
                "cluster_id": int(cluster_id),
                "cluster_size": int(len(indices)),
                "medoid_raw_id": corpus.iloc[medoid_idx]["raw_id"],
                "medoid_name": corpus.iloc[medoid_idx]["source_name"],
                "mean_member_silhouette": float(np.mean(silhouettes[indices])),
                "minimum_member_silhouette": float(np.min(silhouettes[indices])),
                "source_distribution": json.dumps(source_counts, ensure_ascii=False, sort_keys=True),
                "members": " || ".join(
                    f"{corpus.iloc[i]['raw_id']} {corpus.iloc[i]['model_id']} — {corpus.iloc[i]['source_name']}"
                    for i in indices
                ),
            }
        )
        for i in indices:
            assignment_rows.append(
                {
                    "raw_id": corpus.iloc[i]["raw_id"],
                    "model_id": corpus.iloc[i]["model_id"],
                    "source_code": corpus.iloc[i]["source_code"],
                    "source_name": corpus.iloc[i]["source_name"],
                    "cluster_id": int(cluster_id),
                    "cluster_medoid": corpus.iloc[medoid_idx]["source_name"],
                    "silhouette": float(silhouettes[i]),
                    "boundary_candidate": bool(silhouettes[i] < 0.20),
                }
            )
    return pd.DataFrame(cluster_rows), pd.DataFrame(assignment_rows)


def run_hdbscan(
    embedding: np.ndarray,
    metric_mode: str,
    min_cluster_size: int,
    min_samples: int | None,
) -> np.ndarray:
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=FutureWarning)
        if metric_mode == "cosine_precomputed":
            distances = pairwise_distances(embedding, metric="cosine")
            model = HDBSCAN(
                min_cluster_size=min_cluster_size,
                min_samples=min_samples,
                metric="precomputed",
                allow_single_cluster=False,
                copy=True,
            )
            return model.fit_predict(distances)
        if metric_mode == "euclidean":
            model = HDBSCAN(
                min_cluster_size=min_cluster_size,
                min_samples=min_samples,
                metric="euclidean",
                allow_single_cluster=False,
                copy=True,
            )
            return model.fit_predict(embedding)
    raise ValueError(f"Unsupported HDBSCAN metric mode: {metric_mode}")


def hdbscan_metrics(
    embedding: np.ndarray,
    labels: np.ndarray,
    selected_agglomerative: np.ndarray,
    approved_labels: np.ndarray,
) -> dict[str, float | int]:
    mask = labels >= 0
    clusters = len(set(labels[mask])) if mask.any() else 0
    result: dict[str, float | int] = {
        "n_clusters": clusters,
        "noise_fraction": float((~mask).mean()),
        "non_noise_n": int(mask.sum()),
    }
    if mask.sum() >= 3 and clusters >= 2:
        result.update(
            {
                "silhouette_cosine_non_noise": float(
                    silhouette_score(embedding[mask], labels[mask], metric="cosine")
                ),
                "ari_vs_selected_agglomerative": float(
                    adjusted_rand_score(selected_agglomerative[mask], labels[mask])
                ),
                "nmi_vs_selected_agglomerative": float(
                    normalized_mutual_info_score(selected_agglomerative[mask], labels[mask])
                ),
                "ari_vs_approved_codebook": float(adjusted_rand_score(approved_labels[mask], labels[mask])),
                "nmi_vs_approved_codebook": float(
                    normalized_mutual_info_score(approved_labels[mask], labels[mask])
                ),
            }
        )
    return result


def main(root: Path, quick: bool = False) -> None:
    cfg = load_config(root)["criterion_discovery"]
    out = root / "outputs/01_criterion_discovery"
    figs = root / "figures/01_criterion_discovery"
    out.mkdir(parents=True, exist_ok=True)
    figs.mkdir(parents=True, exist_ok=True)

    corpus = pd.read_csv(root / "data/criterion/criterion_corpus.csv", encoding="utf-8-sig")
    if len(corpus) != 100:
        raise ValueError(f"Expected 100 raw criteria, found {len(corpus)}")

    repetitions = 10 if quick else int(cfg["resampling_repetitions"])
    scan_rows: list[dict[str, Any]] = []
    selection_rows: list[dict[str, Any]] = []
    embeddings: dict[str, np.ndarray] = {}
    labels_by_variant_k: dict[tuple[str, int], np.ndarray] = {}
    metadata_rows: list[dict[str, Any]] = []

    # No approved labels are loaded before this fit/selection block.
    for variant, spec in cfg["representations"].items():
        texts = [build_text(row, spec) for _, row in corpus.iterrows()]
        embedding, metadata = make_embedding(texts, cfg)
        embeddings[variant] = embedding
        metadata_rows.append({"variant": variant, **metadata})
        variant_rows: list[dict[str, Any]] = []
        cluster_counts = list(range(int(cfg["k_min"]), int(cfg["k_max"]) + 1))
        full_labels_by_k: dict[int, np.ndarray] = {}
        for k in cluster_counts:
            labels = agglomerative(embedding, k)
            labels_by_variant_k[(variant, k)] = labels
            full_labels_by_k[k] = labels

        stability_by_k = resampling_stability_grid(
            embedding,
            full_labels_by_k,
            cluster_counts,
            repetitions,
            float(cfg["resampling_fraction"]),
            int(cfg["resampling_seed"]),
        )

        for k in cluster_counts:
            labels = full_labels_by_k[k]
            sizes = np.bincount(labels)
            row = {
                "variant": variant,
                "k": k,
                "silhouette_cosine": float(silhouette_score(embedding, labels, metric="cosine")),
                **stability_by_k[k],
                "singleton_clusters": int((sizes == 1).sum()),
                "singleton_rate": float((sizes == 1).sum() / k),
                "minimum_cluster_size": int(sizes.min()),
                "median_cluster_size": float(np.median(sizes)),
                "maximum_cluster_size": int(sizes.max()),
            }
            scan_rows.append(row)
            variant_rows.append(row)
        max_silhouette = max(r["silhouette_cosine"] for r in variant_rows)
        eligible = [
            r
            for r in variant_rows
            if r["silhouette_cosine"]
            >= float(cfg["near_optimal_silhouette_fraction"]) * max_silhouette
            and r["resampling_ari_mean"] >= float(cfg["minimum_resampling_stability"])
            and r["singleton_rate"] <= float(cfg["maximum_singleton_rate"])
        ]
        selected = min(eligible, key=lambda r: r["k"]) if eligible else max(
            variant_rows, key=lambda r: (r["silhouette_cosine"], r["resampling_ari_mean"])
        )
        selection_rows.append(
            {
                "variant": variant,
                "selected_k": int(selected["k"]),
                "selected_silhouette": selected["silhouette_cosine"],
                "selected_resampling_ari": selected["resampling_ari_mean"],
                "selected_singleton_rate": selected["singleton_rate"],
                "selection_rule": "minimum k satisfying near-optimal silhouette, stability, and singleton constraints",
            }
        )

    scan = pd.DataFrame(scan_rows)
    selection = pd.DataFrame(selection_rows)
    primary_variant = "weighted"
    selected_k = int(selection.loc[selection["variant"] == primary_variant, "selected_k"].iloc[0])
    embedding = embeddings[primary_variant]
    selected_labels = labels_by_variant_k[(primary_variant, selected_k)]
    k26_labels = labels_by_variant_k[(primary_variant, 26)]

    # Approved labels enter only now, after the clustering solution has been fixed.
    mapping = pd.read_csv(root / "data/criterion/raw_to_family_mapping.csv", encoding="utf-8-sig")
    mapping = mapping.set_index("raw_id").loc[corpus["raw_id"]].reset_index()
    approved_codes = mapping["approved_family_code"].astype(str)
    approved_lookup = {code: idx for idx, code in enumerate(sorted(approved_codes.unique()))}
    approved_labels = np.array([approved_lookup[c] for c in approved_codes], dtype=int)

    scan["approved_codebook_ari_posthoc"] = np.nan
    scan["approved_codebook_nmi_posthoc"] = np.nan
    for index, row in scan.iterrows():
        labels = labels_by_variant_k[(row["variant"], int(row["k"]))]
        scan.at[index, "approved_codebook_ari_posthoc"] = adjusted_rand_score(approved_labels, labels)
        scan.at[index, "approved_codebook_nmi_posthoc"] = normalized_mutual_info_score(approved_labels, labels)

    free_summary, free_assignments = cluster_summary(corpus, embedding, selected_labels, f"weighted_k{selected_k}")
    k26_summary, k26_assignments = cluster_summary(corpus, embedding, k26_labels, "weighted_k26")

    hcfg = cfg["hdbscan"]
    hscan_rows: list[dict[str, Any]] = []
    for metric_mode in [hcfg["primary_metric"], hcfg["sensitivity_metric"]]:
        for min_cluster_size in hcfg["grid_min_cluster_size"]:
            for min_samples in hcfg["grid_min_samples"]:
                labels = run_hdbscan(embedding, metric_mode, int(min_cluster_size), min_samples)
                hscan_rows.append(
                    {
                        "metric_mode": metric_mode,
                        "min_cluster_size": min_cluster_size,
                        "min_samples": "None" if min_samples is None else min_samples,
                        **hdbscan_metrics(embedding, labels, selected_labels, approved_labels),
                    }
                )
    hscan = pd.DataFrame(hscan_rows)

    primary_h = run_hdbscan(
        embedding,
        hcfg["primary_metric"],
        int(hcfg["min_cluster_size"]),
        hcfg["min_samples"],
    )
    sensitivity_h = run_hdbscan(
        embedding,
        hcfg["sensitivity_metric"],
        int(hcfg["min_cluster_size"]),
        hcfg["min_samples"],
    )
    hsummary = pd.DataFrame(
        [
            {
                "specification": "PRIMARY_METHOD_ALIGNED",
                "metric_mode": hcfg["primary_metric"],
                "min_cluster_size": hcfg["min_cluster_size"],
                "min_samples": hcfg["min_samples"],
                **hdbscan_metrics(embedding, primary_h, selected_labels, approved_labels),
            },
            {
                "specification": "EUCLIDEAN_SENSITIVITY_LEGACY_REPRODUCTION",
                "metric_mode": hcfg["sensitivity_metric"],
                "min_cluster_size": hcfg["min_cluster_size"],
                "min_samples": hcfg["min_samples"],
                **hdbscan_metrics(embedding, sensitivity_h, selected_labels, approved_labels),
            },
        ]
    )
    common_non_noise = (primary_h >= 0) & (sensitivity_h >= 0)
    if common_non_noise.any():
        hsummary["cosine_euclidean_ari_common_non_noise"] = adjusted_rand_score(
            primary_h[common_non_noise], sensitivity_h[common_non_noise]
        )
        hsummary["cosine_euclidean_nmi_common_non_noise"] = normalized_mutual_info_score(
            primary_h[common_non_noise], sensitivity_h[common_non_noise]
        )

    # Human adjudication handoff: all needed review fields are explicit and blank by design.
    review = free_summary.copy()
    review["neighbouring_cluster_review"] = ""
    review["proposed_canonical_name_researcher_1"] = ""
    review["proposed_canonical_name_researcher_2"] = ""
    review["operational_definition"] = ""
    review["inclusion_rule"] = ""
    review["exclusion_rule"] = ""
    review["macro_dimension"] = ""
    review["preference_direction"] = ""
    review["hard_constraint_status"] = ""
    review["retain_split_merge_decision"] = ""
    review["merge_target_if_any"] = ""
    review["documented_adjudication_note"] = ""
    review["final_family_code"] = ""
    review["final_family_name"] = ""

    save_csv(out / "embedding_metadata.csv", pd.DataFrame(metadata_rows))
    save_csv(out / "k_scan.csv", scan)
    save_csv(out / "k_selection.csv", selection)
    save_csv(out / "selected_cluster_summary.csv", free_summary)
    save_csv(out / "selected_cluster_assignments.csv", free_assignments)
    save_csv(out / "k26_cluster_summary.csv", k26_summary)
    save_csv(out / "k26_cluster_assignments.csv", k26_assignments)
    save_csv(out / "hdbscan_grid.csv", hscan)
    save_csv(out / "hdbscan_primary_and_sensitivity.csv", hsummary)
    save_csv(out / "researcher_adjudication_template.csv", review)
    save_csv(out / "boundary_review_candidates.csv", free_assignments[free_assignments["boundary_candidate"]])

    main_scan = scan[scan["variant"] == primary_variant].sort_values("k")
    fig, ax = plt.subplots(figsize=(10, 6))
    ax.plot(main_scan["k"], main_scan["silhouette_cosine"], marker="o", label="Cosine silhouette")
    ax.plot(main_scan["k"], main_scan["resampling_ari_mean"], marker="s", label="Resampling stability (ARI)")
    ax.plot(main_scan["k"], main_scan["approved_codebook_ari_posthoc"], marker="^", label="Post-hoc agreement with approved codebook (ARI)")
    ax.axvline(26, linestyle="--", label="Approved operational family count (26)")
    ax.axvline(selected_k, linestyle=":", label=f"Selected fine solution (k={selected_k})")
    ax.set_xlabel("Number of clusters (k)")
    ax.set_ylabel("Score")
    ax.set_ylim(0, 1.05)
    ax.set_title("Criterion-family discovery: validity, resampling stability, and post-hoc agreement")
    ax.grid(True, alpha=0.25)
    ax.legend()
    fig.tight_layout()
    fig.savefig(figs / "cluster_validity_stability.png", dpi=300)
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(16, 8))
    dendrogram(
        linkage(embedding, method="average", metric="cosine"),
        labels=corpus["raw_id"].tolist(),
        leaf_rotation=90,
        leaf_font_size=5,
        ax=ax,
    )
    ax.set_title("Agglomerative hierarchical clustering dendrogram")
    ax.set_ylabel("Cosine linkage distance")
    fig.tight_layout()
    fig.savefig(figs / "criterion_dendrogram.png", dpi=300)
    plt.close(fig)

    summary = {
        "raw_criteria": int(len(corpus)),
        "selected_primary_variant": primary_variant,
        "selected_k": selected_k,
        "resampling_repetitions": repetitions,
        "approved_labels_used_for_fit_or_selection": False,
        "hdbscan_primary": hsummary.iloc[0].to_dict(),
        "hdbscan_euclidean_sensitivity": hsummary.iloc[1].to_dict(),
    }
    (out / "discovery_summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--quick", action="store_true", help="Use 10 instead of 100 resampling repetitions.")
    args = parser.parse_args()
    main(args.root.resolve(), quick=args.quick)
