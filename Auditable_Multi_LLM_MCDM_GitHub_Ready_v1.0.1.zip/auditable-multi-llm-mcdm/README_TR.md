# GitHub Kullanım Özeti

Bu klasör GitHub'a yüklenmeye hazır, çalıştırılabilir yeniden üretilebilirlik paketidir.

## İçerik

- `src/`: aktif framework kodları
- `data/`: 100 kriterlik korpus, 26 aile eşlemesi, kamu-verisi girdileri, insan değerlendirmeleri ve beklenen doğrulama çıktıları
- `reference_outputs/`: seçilmiş nihai sonuç dosyaları
- `release_assets/`: tam çıktı ağacı, şekiller ve eski denetim kodlarının sıkıştırılmış arşivleri
- `README.md`: İngilizce ana açıklama
- `REPRODUCIBILITY_PROTOCOL.md`: yöntem-kod protokolü
- `METHOD_ALIGNMENT.md`: metodolojiyle yapılan kod uyarlamaları

## Çalıştırma

```bash
pip install -r requirements.txt
python run_all.py
```

Kısa test:

```bash
python run_all.py --quick
```

## GitHub'a yükleme

1. Ana ZIP'i bilgisayarınızda açın.
2. İçindeki `auditable-multi-llm-mcdm` klasörünün **içeriğini** GitHub deposuna yükleyin.
3. En güvenli yöntem GitHub Desktop veya Git komut satırıdır.
4. Tarayıcı kullanacaksanız bütün dosyalar 25 MiB sınırının altındadır ve paket 100 dosyanın altında tutulmuştur.
5. ZIP'i yalnızca GitHub Release eki olarak saklamak isterseniz doğrudan release asset olarak yükleyebilirsiniz.

Ayrıntılar: `GITHUB_UPLOAD_GUIDE.md`.
