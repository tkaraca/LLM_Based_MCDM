#!/usr/bin/env python3
"""Run the final public-data MCDM model for Istanbul European-side emergency logistics nodes.

Primary model decisions:
- Accept the disclosed 2025 district population transcription as the study input.
- Remove D3 from the primary model because, at district resolution, its rank ordering is
  indistinguishable from D2; keep D3 only as sensitivity evidence.
- Keep D4 outside the primary model because of conceptual/statistical overlap.
- Merge D1 and D2 into D12 (response accessibility) to avoid double counting while
  preserving their combined criterion weight.
- Retain D5, D6, D7 and D8.
- Treat structural safety and natural-hazard checks as post-ranking implementation
  verification, not as invented numeric scores.

The script produces PROMETHEE II as the primary ranking, VIKOR and TOPSIS as robustness
benchmarks, and Monte Carlo PROMETHEE II rank-acceptability results.
"""
from __future__ import annotations

import argparse
import json
import math
from pathlib import Path
from typing import Dict, Iterable, Tuple

import numpy as np
import pandas as pd

BASE_WEIGHTS = {
    "D12": 0.1920321196 + 0.1944541463,
    "D5": 0.1854841605,
    "D7": 0.1535391947,
    "D6": 0.1456039562,
    "D8": 0.1288864226,
}
D1_SHARE = 0.1920321196 / BASE_WEIGHTS["D12"]
D2_SHARE = 0.1944541463 / BASE_WEIGHTS["D12"]


def minmax(s: pd.Series, higher_better: bool = True) -> pd.Series:
    s = pd.to_numeric(s, errors="coerce").astype(float)
    lo, hi = s.min(), s.max()
    if not math.isfinite(lo) or not math.isfinite(hi) or abs(hi - lo) < 1e-12:
        out = pd.Series(1.0, index=s.index, dtype=float)
    else:
        out = (s - lo) / (hi - lo)
    return out if higher_better else 1.0 - out


def derive_thresholds(u: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for c in u.columns:
        x = u[c].to_numpy(float)
        diffs = []
        for i in range(len(x)):
            for j in range(i + 1, len(x)):
                d = abs(x[i] - x[j])
                if d > 1e-12:
                    diffs.append(d)
        if len(diffs) >= 4:
            q = float(np.quantile(diffs, 0.25))
            p = float(np.quantile(diffs, 0.75))
        elif diffs:
            q = float(min(diffs))
            p = float(max(diffs))
        else:
            q, p = 0.02, 0.20
        q = max(0.0, min(q, 0.45))
        p = max(q + 0.05, min(p, 1.0))
        rows.append({"criterion": c, "q": q, "p": p, "rule": "Q25/Q75 of non-zero pairwise utility differences"})
    return pd.DataFrame(rows)


def preference(diff: float, q: float, p: float) -> float:
    if diff <= q:
        return 0.0
    if diff >= p:
        return 1.0
    return (diff - q) / (p - q)


def promethee_ii(u: pd.DataFrame, weights: Dict[str, float], thresholds: pd.DataFrame) -> pd.DataFrame:
    cols = list(weights)
    w = np.array([weights[c] for c in cols], dtype=float)
    w = w / w.sum()
    q = {r.criterion: float(r.q) for r in thresholds.itertuples()}
    p = {r.criterion: float(r.p) for r in thresholds.itertuples()}
    arr = u[cols].to_numpy(float)
    n = len(arr)
    pi = np.zeros((n, n), dtype=float)
    for i in range(n):
        for k in range(n):
            if i == k:
                continue
            pref = 0.0
            for j, c in enumerate(cols):
                pref += w[j] * preference(arr[i, j] - arr[k, j], q[c], p[c])
            pi[i, k] = pref
    phi_plus = pi.sum(axis=1) / (n - 1)
    phi_minus = pi.sum(axis=0) / (n - 1)
    phi = phi_plus - phi_minus
    out = pd.DataFrame({"phi_plus": phi_plus, "phi_minus": phi_minus, "phi_net": phi}, index=u.index)
    out["PROMETHEE_rank"] = out["phi_net"].rank(ascending=False, method="min").astype(int)
    return out.sort_values(["PROMETHEE_rank", "phi_net"], ascending=[True, False])


def topsis(u: pd.DataFrame, weights: Dict[str, float]) -> pd.DataFrame:
    cols = list(weights)
    x = u[cols].to_numpy(float)
    denom = np.sqrt((x**2).sum(axis=0))
    denom[denom == 0] = 1.0
    r = x / denom
    w = np.array([weights[c] for c in cols], float)
    w /= w.sum()
    v = r * w
    ideal = v.max(axis=0)
    nadir = v.min(axis=0)
    dplus = np.sqrt(((v - ideal)**2).sum(axis=1))
    dminus = np.sqrt(((v - nadir)**2).sum(axis=1))
    cc = dminus / np.maximum(dplus + dminus, 1e-12)
    out = pd.DataFrame({"TOPSIS_score": cc}, index=u.index)
    out["TOPSIS_rank"] = out["TOPSIS_score"].rank(ascending=False, method="min").astype(int)
    return out.sort_values(["TOPSIS_rank", "TOPSIS_score"], ascending=[True, False])


def vikor(u: pd.DataFrame, weights: Dict[str, float], v: float = 0.5) -> pd.DataFrame:
    cols = list(weights)
    x = u[cols].to_numpy(float)
    w = np.array([weights[c] for c in cols], float)
    w /= w.sum()
    regret = w * (1.0 - x)
    S = regret.sum(axis=1)
    R = regret.max(axis=1)
    smin, smax = S.min(), S.max()
    rmin, rmax = R.min(), R.max()
    sn = (S - smin) / max(smax - smin, 1e-12)
    rn = (R - rmin) / max(rmax - rmin, 1e-12)
    Q = v * sn + (1-v) * rn
    out = pd.DataFrame({"VIKOR_S": S, "VIKOR_R": R, "VIKOR_Q": Q}, index=u.index)
    out["VIKOR_rank"] = out["VIKOR_Q"].rank(ascending=True, method="min").astype(int)
    return out.sort_values(["VIKOR_rank", "VIKOR_Q"], ascending=[True, True])


def rank_corr(a: pd.Series, b: pd.Series) -> float:
    return float(a.corr(b, method="spearman"))


def build_utilities(metrics: pd.DataFrame) -> Tuple[pd.DataFrame, pd.DataFrame]:
    active = metrics[metrics["analysis_status"].eq("INCLUDE_CONDITIONAL")].copy().reset_index(drop=True)
    u = pd.DataFrame(index=active["alternative_id"])
    u["D1"] = minmax(active.set_index("alternative_id")["D1_population_weighted_travel_time_min"], False)
    u["D2"] = minmax(active.set_index("alternative_id")["D2_population_coverage_30min"], True)
    u["D12"] = D1_SHARE * u["D1"] + D2_SHARE * u["D2"]
    u["D5"] = minmax(active.set_index("alternative_id")["D5_osm_route_redundancy_index"], True)
    u["D6"] = minmax(active.set_index("alternative_id")["D6_nearest_gateway_time_min"], False)
    u["D7"] = minmax(active.set_index("alternative_id")["D7_osm_last_mile_hgv_proxy"], True)
    u["D8"] = minmax(np.log1p(active.set_index("alternative_id")["site_area_proxy_m2"]), True)
    meta = active.set_index("alternative_id")[["refined_name", "district", "facility_type", "site_area_proxy_m2", "area_status", "source_id"]]
    return u, meta


def monte_carlo(u: pd.DataFrame, meta: pd.DataFrame, thresholds: pd.DataFrame, n_iter: int = 5000, seed: int = 20261008) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    ids = list(u.index)
    cols = list(BASE_WEIGHTS)
    base_w = np.array([BASE_WEIGHTS[c] for c in cols], float)
    base_w /= base_w.sum()
    concentration = 180.0
    alpha = np.maximum(base_w * concentration, 0.5)
    q0 = thresholds.set_index("criterion")["q"].to_dict()
    p0 = thresholds.set_index("criterion")["p"].to_dict()
    counts = np.zeros((len(ids), len(ids)), dtype=int)
    rank_sum = np.zeros(len(ids), dtype=float)
    rank_sq = np.zeros(len(ids), dtype=float)
    official = ~meta["area_status"].str.contains("SECONDARY|MULTI_SOURCE", case=False, na=False)
    raw_area = meta["site_area_proxy_m2"].to_numpy(float)
    for _ in range(n_iter):
        wdraw = rng.dirichlet(alpha)
        w = dict(zip(cols, wdraw))
        qpm = rng.uniform(0.75, 1.25)
        th = thresholds.copy()
        th["q"] = [min(max(q0[c] * qpm, 0.0), 0.8) for c in th["criterion"]]
        th["p"] = [min(max(p0[c] * qpm, q + 0.03), 1.0) for c, q in zip(th["criterion"], th["q"])]
        us = u.copy()
        # Area uncertainty reflects source class; other public data are held fixed.
        sigma = np.where(official.to_numpy(), 0.04, 0.15)
        sampled_area = raw_area * np.exp(rng.normal(0.0, sigma))
        us["D8"] = minmax(pd.Series(np.log1p(sampled_area), index=ids), True)
        pr = promethee_ii(us[cols], w, th)
        ranks = pr["PROMETHEE_rank"].reindex(ids).to_numpy(int)
        for i, r in enumerate(ranks):
            counts[i, r-1] += 1
        rank_sum += ranks
        rank_sq += ranks**2
    rows = []
    for i, aid in enumerate(ids):
        mean = rank_sum[i]/n_iter
        sd = math.sqrt(max(rank_sq[i]/n_iter - mean**2, 0))
        row = {
            "alternative_id": aid,
            "mean_rank": mean,
            "rank_sd": sd,
            "p_rank_1": counts[i,0]/n_iter,
            "p_top3": counts[i,:3].sum()/n_iter,
            "p_top5": counts[i,:5].sum()/n_iter,
        }
        for r in range(len(ids)):
            row[f"p_rank_{r+1:02d}"] = counts[i,r]/n_iter
        rows.append(row)
    return pd.DataFrame(rows).sort_values(["mean_rank", "p_top3"], ascending=[True, False])


def main(root: Path, n_mc: int) -> None:
    out = root / "outputs_final"
    out.mkdir(parents=True, exist_ok=True)
    metrics = pd.read_csv(root / "outputs" / "public_data_criteria_partial.csv", encoding="utf-8-sig")
    u, meta = build_utilities(metrics)
    primary = u[list(BASE_WEIGHTS)]
    thresholds = derive_thresholds(primary)
    prom = promethee_ii(primary, BASE_WEIGHTS, thresholds)
    top = topsis(primary, BASE_WEIGHTS)
    vik = vikor(primary, BASE_WEIGHTS, 0.5)
    results = meta.join(primary).join(prom).join(top).join(vik)
    results["mean_method_rank"] = results[["PROMETHEE_rank", "TOPSIS_rank", "VIKOR_rank"]].mean(axis=1)
    results["method_rank_sd"] = results[["PROMETHEE_rank", "TOPSIS_rank", "VIKOR_rank"]].std(axis=1, ddof=0)
    results["consensus_rank"] = results["mean_method_rank"].rank(ascending=True, method="min").astype(int)
    results = results.sort_values(["PROMETHEE_rank", "phi_net"], ascending=[True, False])

    # Redundancy/sensitivity models for D1 vs D2 treatment.
    w_other = {k:v for k,v in BASE_WEIGHTS.items() if k != "D12"}
    w_d1 = {"D1": BASE_WEIGHTS["D12"], **w_other}
    w_d2 = {"D2": BASE_WEIGHTS["D12"], **w_other}
    th_d1 = derive_thresholds(u[list(w_d1)])
    th_d2 = derive_thresholds(u[list(w_d2)])
    pr_d1 = promethee_ii(u[list(w_d1)], w_d1, th_d1)
    pr_d2 = promethee_ii(u[list(w_d2)], w_d2, th_d2)
    sensitivity = pd.DataFrame(index=u.index)
    sensitivity["base_D12_rank"] = prom["PROMETHEE_rank"].reindex(u.index)
    sensitivity["D1_only_rank"] = pr_d1["PROMETHEE_rank"].reindex(u.index)
    sensitivity["D2_only_rank"] = pr_d2["PROMETHEE_rank"].reindex(u.index)
    sensitivity = sensitivity.join(meta[["refined_name"]])
    sensitivity["abs_change_D1"] = (sensitivity["base_D12_rank"] - sensitivity["D1_only_rank"]).abs()
    sensitivity["abs_change_D2"] = (sensitivity["base_D12_rank"] - sensitivity["D2_only_rank"]).abs()
    sensitivity = sensitivity.sort_values("base_D12_rank")

    correlations = pd.DataFrame([
        ["PROMETHEE vs TOPSIS", rank_corr(results["PROMETHEE_rank"], results["TOPSIS_rank"])],
        ["PROMETHEE vs VIKOR", rank_corr(results["PROMETHEE_rank"], results["VIKOR_rank"])],
        ["TOPSIS vs VIKOR", rank_corr(results["TOPSIS_rank"], results["VIKOR_rank"])],
        ["Base D12 vs D1-only", rank_corr(sensitivity["base_D12_rank"], sensitivity["D1_only_rank"])],
        ["Base D12 vs D2-only", rank_corr(sensitivity["base_D12_rank"], sensitivity["D2_only_rank"])],
    ], columns=["comparison", "spearman_rho"])

    mc = monte_carlo(primary, meta, thresholds, n_iter=n_mc)
    mc = mc.merge(meta[["refined_name"]], left_on="alternative_id", right_index=True, how="left")

    primary.to_csv(out / "final_public_data_utility_matrix.csv", encoding="utf-8-sig")
    thresholds.to_csv(out / "promethee_thresholds.csv", index=False, encoding="utf-8-sig")
    results.reset_index(names="alternative_id").to_csv(out / "final_mcdm_rankings.csv", index=False, encoding="utf-8-sig")
    sensitivity.reset_index(names="alternative_id").to_csv(out / "D1_D2_sensitivity.csv", index=False, encoding="utf-8-sig")
    correlations.to_csv(out / "method_rank_correlations.csv", index=False, encoding="utf-8-sig")
    mc.to_csv(out / "monte_carlo_rank_acceptability.csv", index=False, encoding="utf-8-sig")

    model = {
        "problem": "General-purpose first-72-hour emergency logistics node suitability",
        "population_data": "Accepted 2025 district population transcription disclosed in source manifest",
        "primary_criteria": list(BASE_WEIGHTS),
        "weights": BASE_WEIGHTS,
        "D12_definition": "Weight-preserving composite of D1 and D2_30 to address empirical redundancy",
        "D12_component_shares": {"D1": D1_SHARE, "D2": D2_SHARE},
        "removed_primary": {"D3": "Rank-identical to D2 at current district resolution", "D4": "Redundant with D1/D2"},
        "structural_safety": "Post-ranking implementation verification requirement",
        "hazard_exposure": "Post-ranking public-hazard screening requirement",
        "promethee_threshold_rule": "Q25/Q75 of non-zero pairwise utility differences",
        "monte_carlo_iterations": n_mc,
    }
    with open(out / "final_model_specification.json", "w", encoding="utf-8") as f:
        json.dump(model, f, ensure_ascii=False, indent=2)

    print(results[["refined_name", "phi_net", "PROMETHEE_rank", "TOPSIS_rank", "VIKOR_rank", "consensus_rank"]].to_string())
    print("\nMethod correlations:\n", correlations.to_string(index=False))
    print("\nMonte Carlo top candidates:\n", mc[["alternative_id", "refined_name", "mean_rank", "p_rank_1", "p_top3"]].head(10).to_string(index=False))
    print(f"\nOutputs written to {out}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument("--monte-carlo", type=int, default=5000)
    args = parser.parse_args()
    main(args.root.resolve(), args.monte_carlo)