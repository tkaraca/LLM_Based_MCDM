#!/usr/bin/env python3
"""Run the complete manuscript-aligned reproducibility workflow."""
from __future__ import annotations

import argparse
import json
import platform
import shutil
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path


def run(command: list[str], root: Path, log_lines: list[str]) -> None:
    display = list(command)
    if display and Path(display[0]).resolve() == Path(sys.executable).resolve():
        display[0] = "python"
    printable = " ".join(display).replace(str(root), ".")
    print(f"\n>>> {printable}", flush=True)
    log_lines.append(f"\n>>> {printable}\n")
    process = subprocess.run(command, cwd=root, text=True, capture_output=True)
    if process.stdout:
        print(process.stdout, end="")
        log_lines.append(process.stdout)
    if process.stderr:
        print(process.stderr, end="", file=sys.stderr)
        log_lines.append(process.stderr)
    if process.returncode != 0:
        raise SystemExit(f"Command failed with exit code {process.returncode}: {printable}")


def main(root: Path, quick: bool, keep_outputs: bool) -> None:
    root = root.resolve()
    output_root = root / "outputs"
    figure_root = root / "figures"
    if not keep_outputs:
        for path in [output_root, figure_root]:
            if path.exists():
                shutil.rmtree(path)
    output_root.mkdir(parents=True, exist_ok=True)
    figure_root.mkdir(parents=True, exist_ok=True)

    log_lines = [
        "Auditable Multi-LLM MCDM reproducibility run\n",
        f"UTC start: {datetime.now(timezone.utc).isoformat()}\n",
        f"Python: {sys.version}\n",
        f"Platform: {platform.platform()}\n",
        f"Mode: {'QUICK SMOKE TEST' if quick else 'FULL FROZEN REPRODUCTION'}\n",
    ]
    py = sys.executable
    discovery = [py, "src/01_criterion_family_discovery.py", "--root", "."]
    if quick:
        discovery.append("--quick")
    run(discovery, root, log_lines)
    run([py, "src/02_criterion_evidence_fusion.py", "--root", "."], root, log_lines)
    mc = "250" if quick else "5000"
    run([py, "src/03_public_data_mcdm.py", "--root", ".", "--monte-carlo", mc], root, log_lines)
    run([py, "src/04_human_benchmark.py", "--root", "."], root, log_lines)
    if quick:
        message = (
            "Quick mode completed. Frozen-output validation was intentionally skipped because "
            "the resampling repetition count and Monte Carlo iteration count differ from the manuscript settings.\n"
        )
        print(message)
        log_lines.append(message)
    else:
        run([py, "src/05_validate_reproduction.py", "--root", "."], root, log_lines)

    runtime = {
        "utc_completed": datetime.now(timezone.utc).isoformat(),
        "mode": "quick" if quick else "full",
        "python": sys.version,
        "platform": platform.platform(),
        "monte_carlo_iterations": int(mc),
        "criterion_resampling_repetitions": 10 if quick else 100,
    }
    (output_root / "runtime_environment.json").write_text(
        json.dumps(runtime, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    (output_root / "run_log.txt").write_text("".join(log_lines), encoding="utf-8")
    print(f"\nWorkflow completed. Outputs: {output_root}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument("--quick", action="store_true", help="Run a shortened smoke test; skips frozen-output validation.")
    parser.add_argument("--keep-outputs", action="store_true", help="Do not delete existing outputs before running.")
    args = parser.parse_args()
    main(args.root, args.quick, args.keep_outputs)
