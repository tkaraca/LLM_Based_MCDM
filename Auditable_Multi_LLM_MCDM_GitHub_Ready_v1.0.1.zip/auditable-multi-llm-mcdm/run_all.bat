@echo off
setlocal
set ROOT=%~dp0
python "%ROOT%run_all.py" --root "%ROOT%" %*
endlocal
