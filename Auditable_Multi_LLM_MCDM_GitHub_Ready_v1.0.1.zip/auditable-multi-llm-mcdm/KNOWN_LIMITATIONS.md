# Known Reproducibility and Interpretation Boundaries

1. **HDBSCAN metric reporting:** the method-aligned primary implementation uses cosine distance; the historical Euclidean run reproduces the current Table 2 numerical row. The manuscript must label the reported row consistently.
2. **Codebook prose record:** the exact original adjudication prose for all 26 definitions and inclusion/exclusion rules was not present in the supplied artifacts. The frozen mapping is available; a proposed completion is explicitly marked for author verification.
3. **Raw OSM graph:** the large frozen GraphML snapshot is listed in the source manifest but not bundled. The primary analysis is fully reproducible from the included frozen candidate-level raw performance table. Upstream geospatial regeneration requires restoration of the exact graph and processed input tables.
4. **Public coordinates:** coordinates are public reference points, not verified service-gate coordinates.
5. **Hard constraints:** geological, structural, and secondary-hazard constraints were not verified uniformly for all candidates and therefore did not numerically exclude candidates. They remain mandatory post-ranking implementation checks.
6. **Proxy interpretation:** D5 and D7 are open-network proxies; D8 is documented site/staging area, not certified assignable storage capacity.
7. **Source dependence:** separately generated LLM outputs are not assumed statistically independent.
8. **Human benchmark scope:** experts were blinded to final rankings and one another, but received the evidence packet. The benchmark is an operational audit and sensitivity layer, not a fully independent remeasurement.
9. **Hallucination claims:** the package demonstrates safeguards against unsupported criterion/importance information entering the ranking. It does not estimate a formal LLM hallucination rate or complete a claim-level rationale audit.
10. **External validity:** the frozen case uses one city, one pre-event network snapshot, district-level demand references, and a five-expert panel. The rankings are conditional on that declared evidence and uncertainty space.
