# Public Repository Release Checklist

- [ ] Run `python run_all.py` from a clean environment.
- [ ] Confirm `outputs/validation/VALIDATION_REPORT.md` reports zero failures.
- [ ] Review the HDBSCAN reporting warning and align the manuscript table with the chosen primary specification.
- [ ] Review `data/criterion/proposed_codebook_definition_completion.csv` against the original adjudication record.
- [ ] Select and add an explicit code licence.
- [ ] Confirm redistribution permissions and attribution requirements for each row in `data/public/source_manifest.csv`.
- [ ] Confirm that no personal identifiers beyond approved expert IDs are present.
- [ ] Confirm that no API keys, passwords, tokens, or local absolute paths are present.
- [ ] Confirm manuscript title, author list, DOI placeholder, and citation metadata before release.
- [ ] Upload extracted repository contents; attach the outer ZIP to a GitHub Release if desired.
- [ ] Tag the release consistently with `VERSION`.
