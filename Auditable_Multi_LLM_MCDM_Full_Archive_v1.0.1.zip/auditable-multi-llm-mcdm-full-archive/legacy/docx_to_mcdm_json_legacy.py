#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Convert the structured master DOCX (LLM-generated MCDM criteria and weights)
into a detailed JSON file.

This parser is intentionally designed for the table/section layout used in
`v0_deprem_afet_mcdm.docx`. It preserves:
- original prompt/context
- model-specific main criteria
- subcriteria definitions
- reported / derived / approximate weights
- explicit top/bottom highlight evidence
- extraction completeness diagnostics

Usage
-----
python docx_to_mcdm_json.py --input v0_deprem_afet_mcdm.docx --output mcdm_master_models.json
"""

from __future__ import annotations

import argparse
import json
import re
import unicodedata
from collections import OrderedDict
from pathlib import Path

from docx import Document


def clean_text(text: str | None) -> str:
    text = "" if text is None else str(text)
    return re.sub(r"\s+", " ", text).strip()


def parse_pct(text: str | None) -> float | None:
    if text is None:
        return None
    raw = clean_text(text).replace(",", ".").replace("✓", "")
    if not raw:
        return None
    has_pct = "%" in raw
    raw = raw.replace("%", "").strip()
    m = re.search(r"[-+]?\d*\.?\d+", raw)
    if not m:
        return None
    val = float(m.group(0))
    if has_pct or val > 1:
        return val / 100.0
    return val


def parse_direction(text: str | None) -> str | None:
    t = clean_text(text).lower()
    if any(k in t for k in ["minimize", "maliyet", "min"]):
        return "cost_min"
    if any(k in t for k in ["maksimize", "fayda", "max"]):
        return "benefit_max"
    return None


def split_code_name(cell_text: str) -> tuple[str | None, str]:
    cell_text = clean_text(cell_text)
    m = re.match(r"([A-Z]\d+|\d\.\d)\.?\s*[:\-]?\s*(.+)", cell_text)
    if m:
        return m.group(1), clean_text(m.group(2))
    return None, cell_text


def parse_main_code_name(text: str) -> tuple[str | None, str | None]:
    text = clean_text(text)
    if not text:
        return None, None
    m = re.match(r"([A-Z])\s*[—\-:]\s*(.+)", text)
    if m:
        return m.group(1), clean_text(m.group(2))
    m = re.match(r"(\d+)\.\s*(.+)", text)
    if m:
        return m.group(1), clean_text(m.group(2))
    m = re.match(r"ANA KRITER\s+([A-Z])\s*[—\-:]?\s*(.+)", text, re.I)
    if m:
        return m.group(1), clean_text(m.group(2))
    return None, text


def normalize_main_name(name: str | None) -> str | None:
    if not name:
        return name
    return clean_text(
        name.replace("\n", " ")
        .replace("(Devamı)", "")
        .replace("ANA KRİTER ", "")
        .replace("Ana Kriter ", "")
    )


def parse_code_weights(line: str) -> dict[str, float]:
    pairs = re.findall(r"([A-Z]\d)\s*([0-9]+(?:\.[0-9]+)?)", line)
    return {code: float(weight) for code, weight in pairs}


def parse_numeric_code_weights(line: str) -> dict[str, float]:
    pairs = re.findall(r"(\d\.\d)\s*%(\d+(?:\.\d+)?)", line)
    return {code: float(weight) / 100.0 for code, weight in pairs}


def add_model_completeness(model: dict) -> None:
    subs = model["subcriteria"]
    total = len(subs)
    main_reported = sum(1 for m in model["main_criteria"] if m.get("weight") is not None)
    reported_local = sum(1 for s in subs if s.get("local_weight") is not None)
    reported_global = sum(1 for s in subs if s.get("global_weight") is not None)
    approx_global = sum(1 for s in subs if s.get("approximate"))

    model["completeness"] = {
        "main_weights_reported_ratio": round(main_reported / len(model["main_criteria"]), 4)
        if model["main_criteria"]
        else None,
        "local_weights_reported_ratio": round(reported_local / total, 4) if total else None,
        "global_weights_available_ratio": round(reported_global / total, 4) if total else None,
        "approx_global_ratio": round(approx_global / total, 4) if total else None,
        "subcriteria_count": total,
    }


def extract_gpt(tables: list, pars: list[str]) -> dict:
    model = OrderedDict()
    model["model_id"] = "gpt-5.2"
    model["label"] = "GPT-5.2"
    model["phase_focus"] = "ilk 72 saat / yaşam kurtarma"
    model["notes"] = "Tam ana kriter ağırlıkları ve tam yerel alt kriter ağırlıkları raporlanmıştır."

    main_weights: OrderedDict[str, dict] = OrderedDict()
    for row in tables[6][1:]:
        code, name = parse_main_code_name(row[0])
        main_weights[code] = {
            "code": code,
            "name": normalize_main_name(name),
            "weight": parse_pct(row[1]),
            "weight_source": "reported",
            "rationale": None,
        }

    local_map = {}
    for idx in [31, 33, 35, 37, 39, 41]:
        local_map.update(parse_code_weights(pars[idx]))

    table_to_main = {0: "A", 1: "B", 2: "C", 3: "D", 4: "E", 5: "F"}
    subs = []
    for table_idx, main_code in table_to_main.items():
        for row_idx, row in enumerate(tables[table_idx][1:], start=1):
            code, name = split_code_name(row[0])
            local_weight = local_map.get(code)
            main_weight = main_weights[main_code]["weight"]
            subs.append(
                OrderedDict(
                    code=code,
                    name=name,
                    parent_code=main_code,
                    parent_name=main_weights[main_code]["name"],
                    description=clean_text(row[1]),
                    measurement_unit=None,
                    data_type=clean_text(row[2]),
                    optimization_direction=parse_direction(row[3]),
                    local_weight=local_weight,
                    global_weight=round(main_weight * local_weight, 6) if local_weight is not None else None,
                    weight_status="reported_local_derived_global" if local_weight is not None else "missing",
                    approximate=False,
                    rationale=None,
                    highlight_tag=None,
                    source_locator={"table_index": table_idx, "row_index": row_idx},
                )
            )

    model["main_criteria"] = list(main_weights.values())
    model["subcriteria"] = subs
    model["evidence_hints"] = {"top": [], "bottom": []}
    return model


def extract_gemini(tables: list, pars: list[str]) -> dict:
    model = OrderedDict()
    model["model_id"] = "gemini-3-pro"
    model["label"] = "Gemini 3 PRO"
    model["phase_focus"] = "ilk 72 saat ve takip eden 2 hafta (yaşam kurtarma)"
    model["notes"] = (
        "Ana kriter ağırlıkları raporlanmış; alt kriterler için yalnızca örnek global ağırlık "
        "seçkisi verilmiştir. Tam yerel alt ağırlıklar raporda yoktur."
    )

    main_criteria: OrderedDict[str, dict] = OrderedDict()
    subs = []
    current_main_code = None
    current_main_name = None

    for row_idx, row in enumerate(tables[7][1:], start=1):
        main_cell, sub_cell, desc, dt, direction = row
        if clean_text(main_cell):
            code, name = parse_main_code_name(main_cell.split("\n")[0])
            current_main_code = code
            current_main_name = normalize_main_name(name)
            if current_main_code not in main_criteria:
                main_criteria[current_main_code] = {
                    "code": current_main_code,
                    "name": current_main_name,
                    "weight": None,
                    "weight_source": "missing",
                    "rationale": None,
                }

        code, name = split_code_name(sub_cell)
        subs.append(
            OrderedDict(
                code=code,
                name=name,
                parent_code=current_main_code,
                parent_name=current_main_name,
                description=clean_text(desc),
                measurement_unit=None,
                data_type=clean_text(dt),
                optimization_direction=parse_direction(direction),
                local_weight=None,
                global_weight=None,
                weight_status="missing",
                approximate=False,
                rationale=None,
                highlight_tag=None,
                source_locator={"table_index": 7, "row_index": row_idx},
            )
        )

    manual_main_weights = {
        "2": ("Hizmet Kapsamı ve Yanıt Hızı", 0.30, clean_text(pars[54].split(":", 1)[1])),
        "1": ("Erişilebilirlik ve Ulaşım Ağı", 0.25, clean_text(pars[55].split(":", 1)[1])),
        "4": ("Güvenlik ve Risk", 0.20, clean_text(pars[56].split(":", 1)[1])),
        "3": ("Altyapı ve Kapasite", 0.15, clean_text(pars[57].split(":", 1)[1])),
        "5": ("Maliyet ve Ekonomi", 0.10, clean_text(pars[58].split(":", 1)[1])),
    }
    for code, (_, weight, rationale) in manual_main_weights.items():
        if code in main_criteria:
            main_criteria[code]["weight"] = weight
            main_criteria[code]["weight_source"] = "reported"
            main_criteria[code]["rationale"] = rationale

    hints = {"top": [], "bottom": []}
    for line in pars[61:65]:
        m = re.search(r"(\d\.\d)\.\s*([^()]+?)\s*\(Yaklaşık %(\d+)", line)
        if not m:
            continue
        code = m.group(1)
        name = clean_text(m.group(2))
        approx_global = float(m.group(3)) / 100.0
        tag = "bottom" if "Düşük" in line or "düşük" in line else "top"
        hints[tag].append(
            {
                "code": code,
                "name": name,
                "approx_global_weight": approx_global,
                "note": clean_text(line),
            }
        )
        for sub in subs:
            if sub["code"] == code:
                sub["global_weight"] = approx_global
                sub["weight_status"] = "explicit_approx_global"
                sub["approximate"] = True
                sub["highlight_tag"] = tag
                if ")." in line:
                    sub["rationale"] = clean_text(line.split(").", 1)[1])
                else:
                    sub["rationale"] = clean_text(line)

    model["main_criteria"] = list(main_criteria.values())
    model["subcriteria"] = subs
    model["evidence_hints"] = hints
    return model


def extract_claude(tables: list, pars: list[str]) -> dict:
    model = OrderedDict()
    model["model_id"] = "claude-sonnet-4.6"
    model["label"] = "Claude Sonnet 4.6"
    model["phase_focus"] = "ilk 72 saat / acil müdahale"
    model["notes"] = "Ana kriter ağırlıkları ve tüm alt kriterler için yerel ve global ağırlıklar raporlanmıştır."

    main_criteria: OrderedDict[str, dict] = OrderedDict()
    for row in tables[13][1:6]:
        # Table layout: [Gerekçe, Sıra, Ana Kriter, Yerel Ağırlık]
        rationale, _rank, name, weight = row
        code, main_name = parse_main_code_name(name)
        main_criteria[code] = {
            "code": code,
            "name": normalize_main_name(main_name),
            "weight": parse_pct(weight),
            "weight_source": "reported",
            "rationale": clean_text(rationale),
        }

    subs: dict[str, dict] = {}
    for table_idx, main_code in zip([8, 9, 10, 11, 12], ["A", "B", "C", "D", "E"]):
        for row_idx, row in enumerate(tables[table_idx][1:], start=1):
            code = clean_text(row[0])
            subs[code] = OrderedDict(
                code=code,
                name=clean_text(row[1]),
                parent_code=main_code,
                parent_name=main_criteria[main_code]["name"],
                description=clean_text(row[2]),
                measurement_unit=clean_text(row[3]),
                data_type=clean_text(row[4]),
                optimization_direction=parse_direction(row[5]),
                local_weight=None,
                global_weight=None,
                weight_status="missing",
                approximate=False,
                rationale=None,
                highlight_tag=None,
                source_locator={"table_index": table_idx, "row_index": row_idx},
            )

    for table_idx in [14, 15, 16, 17, 18]:
        for row in tables[table_idx][1:]:
            code, _, local_weight, global_weight, rationale = row
            code = clean_text(code)
            if code not in subs:
                continue
            subs[code]["local_weight"] = parse_pct(local_weight)
            subs[code]["global_weight"] = parse_pct(global_weight)
            subs[code]["weight_status"] = "reported"
            subs[code]["rationale"] = clean_text(rationale)

    hints = {"top": [], "bottom": []}
    for line in pars[97:105]:
        m = re.search(r"([A-Z]\d)\s*:\s*([^\[]+)\[\%?([0-9.]+)\]", line)
        if not m:
            continue
        code = m.group(1)
        name = clean_text(m.group(2))
        raw_val = float(m.group(3))
        approx_global = raw_val / 100.0 if raw_val > 1 else raw_val
        tag = "bottom" if "Düşük" in line or "düşük" in line else "top"
        hints[tag].append(
            {
                "code": code,
                "name": name,
                "approx_global_weight": approx_global,
                "note": clean_text(line),
            }
        )
        if code in subs:
            subs[code]["highlight_tag"] = tag

    model["main_criteria"] = list(main_criteria.values())
    model["subcriteria"] = list(subs.values())
    model["evidence_hints"] = hints
    return model


def extract_grok(tables: list, pars: list[str]) -> dict:
    model = OrderedDict()
    model["model_id"] = "grok-4"
    model["label"] = "GROK 4"
    model["phase_focus"] = "ilk 72 saat / acil müdahale"
    model["notes"] = "Ana kriter ve yerel alt kriter ağırlıkları raporlanmıştır; global ağırlıklar türetilmiştir."

    main_criteria: OrderedDict[str, dict] = OrderedDict()
    for code, idx in zip(["1", "2", "3", "4", "5"], [110, 111, 112, 113, 114]):
        line = pars[idx]
        m = re.match(r"(.+?):\s*%(\d+)\s*\((.+)\)", line)
        if m:
            name, weight, rationale = clean_text(m.group(1)), float(m.group(2)) / 100.0, clean_text(m.group(3))
        else:
            name, weight, rationale = clean_text(line), None, None
        main_criteria[code] = {
            "code": code,
            "name": name,
            "weight": weight,
            "weight_source": "reported",
            "rationale": rationale,
        }

    local_map = {}
    for idx in [116, 117, 118, 119, 120]:
        local_map.update(parse_numeric_code_weights(pars[idx]))

    subs = []
    current_main_code = None
    current_main_name = None
    for row_idx, row in enumerate(tables[19][1:], start=1):
        main_cell, sub_cell, desc, dt, direction = row
        if clean_text(main_cell):
            code, name = parse_main_code_name(main_cell.split("\n")[0])
            current_main_code = code
            current_main_name = normalize_main_name(name)

        code, name = split_code_name(sub_cell)
        local_weight = local_map.get(code)
        main_weight = main_criteria[current_main_code]["weight"]
        subs.append(
            OrderedDict(
                code=code,
                name=name,
                parent_code=current_main_code,
                parent_name=current_main_name,
                description=clean_text(desc),
                measurement_unit=None,
                data_type=clean_text(dt),
                optimization_direction=parse_direction(direction),
                local_weight=local_weight,
                global_weight=round(main_weight * local_weight, 6)
                if main_weight is not None and local_weight is not None
                else None,
                weight_status="reported_local_derived_global" if local_weight is not None else "missing",
                approximate=False,
                rationale=None,
                highlight_tag=None,
                source_locator={"table_index": 19, "row_index": row_idx},
            )
        )

    model["main_criteria"] = list(main_criteria.values())
    model["subcriteria"] = subs
    model["evidence_hints"] = {"top": [], "bottom": []}
    return model


def extract_deepseek(tables: list) -> dict:
    model = OrderedDict()
    model["model_id"] = "deepseek-v3.2"
    model["label"] = "DeepSeek v3.2"
    model["phase_focus"] = "ilk 72 saat / kritik müdahale dönemi"
    model["notes"] = (
        "Ana kriter ağırlıkları ile tüm alt kriterlerin yerel ve global ağırlıkları raporlanmıştır; "
        "ilk 5 global öncelik listesi ayrıca verilmiştir."
    )

    main_criteria: OrderedDict[str, dict] = OrderedDict()
    manual_main = [
        ("B", tables[25][1][1], parse_pct(tables[25][1][2]), clean_text(tables[25][1][3])),
        ("A", tables[25][2][1], parse_pct(tables[25][2][2]), clean_text(tables[25][2][3])),
        ("D", tables[25][3][1], parse_pct(tables[25][3][2]), clean_text(tables[25][3][3])),
        ("C", tables[25][4][1], parse_pct(tables[25][4][2]), clean_text(tables[25][4][3])),
        ("E", tables[25][5][1], parse_pct(tables[25][5][2]), clean_text(tables[25][5][3])),
    ]
    for code, name, weight, rationale in manual_main:
        main_criteria[code] = {
            "code": code,
            "name": normalize_main_name(name),
            "weight": weight,
            "weight_source": "reported",
            "rationale": rationale,
        }

    subs: dict[str, dict] = {}
    for table_idx, main_code in zip([20, 21, 22, 23, 24], ["A", "B", "C", "D", "E"]):
        for row_idx, row in enumerate(tables[table_idx][1:], start=1):
            code = clean_text(row[0])
            subs[code] = OrderedDict(
                code=code,
                name=clean_text(row[1]),
                parent_code=main_code,
                parent_name=main_criteria[main_code]["name"],
                description=clean_text(row[2]),
                measurement_unit=None,
                data_type=clean_text(row[3]),
                optimization_direction=parse_direction(row[4]),
                local_weight=None,
                global_weight=None,
                weight_status="missing",
                approximate=False,
                rationale=None,
                highlight_tag=None,
                source_locator={"table_index": table_idx, "row_index": row_idx},
            )

    for table_idx in [26, 27, 28, 29, 30]:
        for row in tables[table_idx][1:]:
            code_name, local_weight, global_weight, criticality = row
            code, _ = split_code_name(code_name)
            if code not in subs:
                continue
            subs[code]["local_weight"] = parse_pct(local_weight)
            subs[code]["global_weight"] = parse_pct(global_weight)
            subs[code]["weight_status"] = "reported"
            subs[code]["rationale"] = clean_text(criticality)

    hints = {"top": [], "bottom": []}
    for row in tables[31][1:]:
        rank, crit, global_weight, main_name = row
        code, name = split_code_name(crit)
        hints["top"].append(
            {
                "rank": rank,
                "code": code,
                "name": name,
                "approx_global_weight": parse_pct(global_weight),
                "main_criterion": clean_text(main_name),
            }
        )
        if code in subs:
            subs[code]["highlight_tag"] = "top"

    model["main_criteria"] = list(main_criteria.values())
    model["subcriteria"] = list(subs.values())
    model["evidence_hints"] = hints
    return model


def parse_docx_to_json(input_path: Path) -> dict:
    document = Document(str(input_path))
    tables = [[[cell.text.strip() for cell in row.cells] for row in table.rows] for table in document.tables]
    paragraphs = [p.text.strip() for p in document.paragraphs]

    models = [
        extract_gpt(tables, paragraphs),
        extract_gemini(tables, paragraphs),
        extract_claude(tables, paragraphs),
        extract_grok(tables, paragraphs),
        extract_deepseek(tables),
    ]
    for model in models:
        add_model_completeness(model)

    return OrderedDict(
        schema_version="1.0",
        schema_comment=(
            "Bu JSON, nihai kriter seçimi pipeline'ında kullanılmak üzere ham model kriterleri "
            "ve ağırlık kanıtlarını saklar."
        ),
        document={
            "source_file": input_path.name,
            "language": "tr",
            "decision_context": {
                "problem": "Deprem sonrası acil yardım lojistik merkezi / yardım dağıtım merkezi yer seçimi",
                "phase_focus": "ilk 72 saat / acil müdahale",
                "objective": (
                    "yardımı en etkin, adil ve hızlı biçimde ulaştırabilecek MCDM kriter setinin oluşturulması"
                ),
            },
            "original_prompt": " ".join(
                clean_text(paragraphs[i]) for i in range(0, 11) if clean_text(paragraphs[i])
            ),
        },
        field_guide={
            "optimization_direction": {
                "benefit_max": "Fayda: daha yüksek değer tercih edilir",
                "cost_min": "Maliyet: daha düşük değer tercih edilir",
            },
            "weight_status": {
                "reported": "Belgede yerel ve/veya global ağırlık açıkça raporlandı",
                "reported_local_derived_global": (
                    "Yerel ağırlık raporlandı, global ağırlık ana kriter ağırlığından türetildi"
                ),
                "explicit_approx_global": (
                    "Belgede yalnızca yaklaşık global ağırlık örnek/seçki olarak raporlandı"
                ),
                "missing": "Belgede ilgili ağırlık bulunmuyor",
            },
            "missing_value_policy": {
                "null": "Belge bu değeri raporlamıyor veya model bu ayrıntıyı vermiyor; 0 ile aynı değildir."
            },
        },
        extraction_notes=[
            (
                "Gemini 3 PRO bölümünde alt kriterler için tam yerel ağırlık matrisi bulunmadığından "
                "yalnızca açıkça raporlanan yaklaşık global ağırlıklar JSON'a işlenmiştir."
            ),
            "GPT-5.2 ve GROK 4 için global alt kriter ağırlıkları ana kriter × yerel alt kriter ağırlığı ile türetilmiştir.",
            "Claude Sonnet 4.6 ve DeepSeek v3.2 için raporlanan global ağırlıklar doğrudan alınmıştır.",
        ],
        models=models,
    )


def main() -> None:
    parser = argparse.ArgumentParser(description="Convert the master MCDM DOCX to structured JSON.")
    parser.add_argument("--input", required=True, help="Input DOCX path")
    parser.add_argument("--output", required=True, help="Output JSON path")
    args = parser.parse_args()

    data = parse_docx_to_json(Path(args.input))
    output_path = Path(args.output)
    output_path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"JSON written to {output_path}")


if __name__ == "__main__":
    main()