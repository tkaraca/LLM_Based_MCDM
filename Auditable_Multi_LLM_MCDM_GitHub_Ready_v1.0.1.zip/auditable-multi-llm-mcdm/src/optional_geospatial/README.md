# Optional Upstream Public-Data Regeneration

`compute_public_data_criteria.py` regenerates candidate-level D1–D8 source metrics from the original spatial/public inputs. It is not required to reproduce the published rankings because the frozen candidate-level raw table is included at `data/public/raw_performance.csv`.

The optional script expects a separate workspace containing:

```text
data_raw/osm/istanbul_europe_drive_2026-07-10.graphml.xml[.gz]
data_processed/candidate_registry.csv
data_processed/district_population_reference_2025_provisional.csv
data_processed/district_social_vulnerability_ibb_2018.csv
data_processed/facility_site_area_public.csv
data_processed/strategic_gateway_registry.csv
```

The exact graph snapshot is identified in `data/public/source_manifest.csv`. Its raw bytes were not available for bundling in this release. The final manuscript-aligned utility preview uses 30-minute D2 and D3 measures; 45- and 60-minute values remain diagnostic outputs only.

The optional script should be run only after verifying graph checksum, candidate/service-point coordinates, and all source-table versions. Changes in OSM snapshot, geocoding, routing attributes, or public-area evidence may legitimately change upstream metrics and therefore will not be expected to match the frozen outputs.
