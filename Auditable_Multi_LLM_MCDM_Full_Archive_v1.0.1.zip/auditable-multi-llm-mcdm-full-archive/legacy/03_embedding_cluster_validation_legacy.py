#!/usr/bin/env python3
"""Section 2: criterion-family discovery and clustering validation.

This script reproduces the latent semantic embedding, agglomerative clustering,
cluster-count scan, bootstrap stability, HDBSCAN robustness, cluster medoids,
and comparison with the frozen researcher-approved operational codebook.

The legacy/approved labels are never used to fit the embeddings or clusters;
they are used only after clustering as a comparison partition.
"""
from __future__ import annotations

import argparse
import csv
import importlib.util
import json
import math
from collections import Counter
from pathlib import Path
from typing import Any

import matplotlib.pyplot as plt
import numpy as np
from scipy.cluster.hierarchy import dendrogram, linkage
from scipy.sparse import hstack
from scipy.spatial.distance import cdist
from sklearn.cluster import AgglomerativeClustering, HDBSCAN
from sklearn.decomposition import TruncatedSVD
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics import adjusted_rand_score, normalized_mutual_info_score, silhouette_score
from sklearn.preprocessing import Normalizer


def save_csv(path: Path, rows: list[dict[str, Any]], fields: list[str] | None = None) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        return
    if fields is None:
        fields = list(rows[0].keys())
    with path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def load_build_module(script_path: Path):
    spec = importlib.util.spec_from_file_location("criterion_selection", script_path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Could not load {script_path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def build_raw_items(json_path: Path, build_script: Path) -> tuple[list[dict[str, Any]], Any]:
    module = load_build_module(build_script)
    data = json.loads(json_path.read_text(encoding="utf-8"))
    items: list[dict[str, Any]] = []
    idx = 0
    for model in data["models"]:
        for criterion in model["subcriteria"]:
            idx += 1
            canonical, match_score = module.canonicalize_name_fields(
                criterion["name"], criterion.get("description", ""), criterion.get("parent_name", "")
            )
            if canonical is None:
                legacy_code = "UNMATCHED"
                legacy_name = "Unmatched"
            else:
                legacy_code = canonical["canonical_code"]
                legacy_name = canonical["canonical_name"]
            items.append(
                {
                    "raw_id": f"R{idx:03d}",
                    "model_id": model["model_id"],
                    "model_label": model.get("label", model["model_id"]),
                    "source_code": criterion["code"],
                    "name": criterion["name"],
                    "description": criterion.get("description", "") or "",
                    "parent_name": criterion.get("parent_name", "") or "",
                    "legacy_code": legacy_code,
                    "legacy_name": legacy_name,
                    "legacy_match_score": float(match_score),
                }
            )
    return items, module


def write_approved_codebook(module: Any, path: Path) -> None:
    rows = []
    merge_rules = getattr(module, "MERGE_RULES", {})
    for item in module.CANONICAL_LIBRARY:
        rows.append(
            {
                "canonical_code": item["canonical_code"],
                "canonical_name": item["canonical_name"],
                "macro_group": item["macro_group"],
                "hard_constraint": bool(item["hard_constraint"]),
                "keywords": " | ".join(item["keywords"]),
                "merge_target": merge_rules.get(item["canonical_code"], ""),
                "status": "FROZEN_RESEARCHER_APPROVED_OPERATIONAL_CODEBOOK",
            }
        )
    save_csv(path, rows)


def text_for(item: dict[str, Any], variant: str) -> str:
    name, desc, parent = item["name"], item["description"], item["parent_name"]
    if variant == "weighted":
        return f"{name}. {name}. {name}. {desc}. {desc}. Parent criterion: {parent}"
    if variant == "name_desc_parent":
        return f"{name}. {desc}. Parent criterion: {parent}"
    if variant == "name_desc":
        return f"{name}. {name}. {desc}"
    raise ValueError(f"Unknown representation: {variant}")


def make_embedding(texts: list[str], n_components: int, seed: int):
    word = TfidfVectorizer(
        lowercase=True,
        strip_accents="unicode",
        analyzer="word",
        ngram_range=(1, 2),
        min_df=1,
        sublinear_tf=True,
    )
    char = TfidfVectorizer(
        lowercase=True,
        strip_accents="unicode",
        analyzer="char_wb",
        ngram_range=(3, 5),
        min_df=1,
        sublinear_tf=True,
    )
    word_matrix = word.fit_transform(texts)
    char_matrix = char.fit_transform(texts)
    matrix = hstack([word_matrix, 0.7 * char_matrix]).tocsr()
    retained = min(n_components, matrix.shape[0] - 1, matrix.shape[1] - 1)
    if retained < 2:
        raise ValueError("The corpus is too small for SVD clustering.")
    svd = TruncatedSVD(n_components=retained, random_state=seed)
    embedding = svd.fit_transform(matrix)
    embedding = Normalizer(copy=False).fit_transform(embedding)
    metadata = {
        "n_items": len(texts),
        "feature_rows": matrix.shape[0],
        "feature_columns": matrix.shape[1],
        "svd_dimensions": retained,
        "explained_variance_ratio": float(svd.explained_variance_ratio_.sum()),
    }
    return embedding, metadata


def agglomerative(embedding: np.ndarray, k: int) -> np.ndarray:
    return AgglomerativeClustering(n_clusters=k, metric="cosine", linkage="average").fit_predict(embedding)


def bootstrap_stability(
    embedding: np.ndarray,
    full_labels: np.ndarray,
    k: int,
    repetitions: int,
    fraction: float,
    seed: int,
) -> dict[str, float]:
    rng = np.random.default_rng(seed)
    n = len(embedding)
    size = max(k + 2, int(round(fraction * n)))
    size = min(size, n)
    values = []
    for _ in range(repetitions):
        indices = np.sort(rng.choice(n, size=size, replace=False))
        subset_labels = agglomerative(embedding[indices], k)
        values.append(adjusted_rand_score(full_labels[indices], subset_labels))
    return {
        "bootstrap_ari_mean": float(np.mean(values)),
        "bootstrap_ari_sd": float(np.std(values)),
        "bootstrap_ari_p10": float(np.quantile(values, 0.10)),
        "bootstrap_ari_p90": float(np.quantile(values, 0.90)),
    }


def pairwise_prf(true_labels: np.ndarray, predicted_labels: np.ndarray):
    tp = fp = fn = 0
    n = len(true_labels)
    for i in range(n):
        for j in range(i + 1, n):
            same_true = true_labels[i] == true_labels[j]
            same_pred = predicted_labels[i] == predicted_labels[j]
            if same_true and same_pred:
                tp += 1
            elif not same_true and same_pred:
                fp += 1
            elif same_true and not same_pred:
                fn += 1
    precision = tp / (tp + fp) if tp + fp else 0.0
    recall = tp / (tp + fn) if tp + fn else 0.0
    f1 = 2 * precision * recall / (precision + recall) if precision + recall else 0.0
    return precision, recall, f1


def summarize_solution(
    solution_name: str,
    k: int,
    labels: np.ndarray,
    embedding: np.ndarray,
    items: list[dict[str, Any]],
    output_dir: Path,
) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    cluster_rows: list[dict[str, Any]] = []
    assignment_rows: list[dict[str, Any]] = []
    legacy_codes = [item["legacy_code"] for item in items]
    for cluster_id in sorted(set(labels)):
        indices = np.where(labels == cluster_id)[0].tolist()
        legacy = [legacy_codes[i] for i in indices]
        counts = Counter(legacy)
        majority, majority_n = counts.most_common(1)[0]
        sub = embedding[indices]
        distances = cdist(sub, sub, metric="cosine")
        medoid_local = int(np.argmin(distances.sum(axis=1)))
        medoid_index = indices[medoid_local]
        majority_name = next(item["legacy_name"] for item in items if item["legacy_code"] == majority)
        cluster_rows.append(
            {
                "solution": solution_name,
                "k": k,
                "cluster_id": int(cluster_id),
                "cluster_size": len(indices),
                "medoid_raw_id": items[medoid_index]["raw_id"],
                "medoid_name": items[medoid_index]["name"],
                "majority_legacy_code": majority,
                "majority_legacy_name": majority_name,
                "purity": majority_n / len(indices),
                "legacy_codes_in_cluster": " | ".join(f"{code}:{count}" for code, count in counts.most_common()),
                "members": " || ".join(
                    f"{items[i]['raw_id']} {items[i]['model_id']} — {items[i]['name']}" for i in indices
                ),
            }
        )
        for i in indices:
            assignment_rows.append(
                {
                    **items[i],
                    "solution": solution_name,
                    "k": k,
                    "cluster_id": int(cluster_id),
                    "cluster_medoid": items[medoid_index]["name"],
                    "cluster_majority_legacy_code": majority,
                    "cluster_purity": majority_n / len(indices),
                    "majority_match": items[i]["legacy_code"] == majority,
                }
            )
    save_csv(output_dir / f"cluster_summary_{solution_name}.csv", cluster_rows)
    save_csv(output_dir / f"assignments_{solution_name}.csv", assignment_rows)
    return cluster_rows, assignment_rows


def run_hdbscan_scan(
    embedding: np.ndarray,
    legacy: np.ndarray,
    min_cluster_sizes: range,
    min_samples_values: list[int | None],
) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for min_cluster_size in min_cluster_sizes:
        for min_samples in min_samples_values:
            model = HDBSCAN(
                min_cluster_size=min_cluster_size,
                min_samples=min_samples,
                metric="euclidean",
                allow_single_cluster=False,
                copy=True,
            )
            labels = model.fit_predict(embedding)
            mask = labels >= 0
            clusters = len(set(labels[mask])) if mask.any() else 0
            noise_fraction = float((~mask).mean())
            if mask.sum() >= 3 and clusters >= 2:
                sil = float(silhouette_score(embedding[mask], labels[mask], metric="cosine"))
                ari = float(adjusted_rand_score(legacy[mask], labels[mask]))
                nmi = float(normalized_mutual_info_score(legacy[mask], labels[mask]))
            else:
                sil = ari = nmi = math.nan
            rows.append(
                {
                    "min_cluster_size": min_cluster_size,
                    "min_samples": "None" if min_samples is None else min_samples,
                    "n_clusters": clusters,
                    "noise_fraction": noise_fraction,
                    "silhouette_nonnoise": sil,
                    "legacy_ari_nonnoise": ari,
                    "legacy_nmi_nonnoise": nmi,
                }
            )
    return rows


def generate_figures(
    scan_rows: list[dict[str, Any]],
    selection_rows: list[dict[str, Any]],
    main_variant: str,
    selected_k: int,
    cluster_summary: list[dict[str, Any]],
    embedding: np.ndarray,
    items: list[dict[str, Any]],
    figure_dir: Path,
) -> None:
    figure_dir.mkdir(parents=True, exist_ok=True)
    main = [r for r in scan_rows if r["variant"] == main_variant]
    main.sort(key=lambda r: r["k"])

    fig, ax = plt.subplots(figsize=(10, 6))
    ax.plot([r["k"] for r in main], [r["silhouette_cosine"] for r in main], marker="o", label="Silhouette")
    ax.plot([r["k"] for r in main], [r["bootstrap_ari_mean"] for r in main], marker="s", label="Bootstrap ARI")
    ax.axvline(26, linestyle="--", label="Operational family count")
    ax.axvline(selected_k, linestyle=":", label=f"Selected fine solution (k={selected_k})")
    ax.set_xlabel("Number of clusters (k)")
    ax.set_ylabel("Metric value")
    ax.set_title("Clustering validity and resampling stability")
    ax.grid(True, alpha=0.25)
    ax.legend()
    fig.tight_layout()
    fig.savefig(figure_dir / "Figure_1_k_scan.png", dpi=300)
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(9, 5))
    x = np.arange(len(selection_rows))
    ax.bar(x - 0.18, [float(r["selected_silhouette"]) for r in selection_rows], 0.36, label="Silhouette")
    ax.bar(x + 0.18, [float(r["selected_stability"]) for r in selection_rows], 0.36, label="Bootstrap ARI")
    ax.set_xticks(x, [r["variant"] for r in selection_rows], rotation=20, ha="right")
    ax.set_ylim(0, 1.05)
    ax.set_title("Selected solutions across text representations")
    ax.legend()
    ax.grid(True, axis="y", alpha=0.25)
    fig.tight_layout()
    fig.savefig(figure_dir / "Figure_2_variant_comparison.png", dpi=300)
    plt.close(fig)

    sizes = sorted([int(r["cluster_size"]) for r in cluster_summary], reverse=True)
    fig, ax = plt.subplots(figsize=(10, 5))
    ax.bar(np.arange(1, len(sizes) + 1), sizes)
    ax.set_xlabel("Cluster ordered by size")
    ax.set_ylabel("Number of raw criteria")
    ax.set_title(f"Fine-grained cluster sizes (k={selected_k})")
    ax.grid(True, axis="y", alpha=0.25)
    fig.tight_layout()
    fig.savefig(figure_dir / "Figure_3_cluster_sizes.png", dpi=300)
    plt.close(fig)

    linkage_matrix = linkage(embedding, method="average", metric="cosine")
    fig, ax = plt.subplots(figsize=(16, 8))
    dendrogram(linkage_matrix, labels=[item["raw_id"] for item in items], leaf_rotation=90, leaf_font_size=5, ax=ax)
    ax.set_title("Agglomerative hierarchical clustering dendrogram")
    ax.set_ylabel("Cosine linkage distance")
    fig.tight_layout()
    fig.savefig(figure_dir / "Figure_4_dendrogram.png", dpi=300)
    plt.close(fig)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo-root", type=Path, default=Path(__file__).resolve().parents[2])
    parser.add_argument("--json", type=Path, default=None)
    parser.add_argument("--output-dir", type=Path, default=None)
    parser.add_argument("--bootstrap-reps", type=int, default=100)
    parser.add_argument("--bootstrap-fraction", type=float, default=0.85)
    parser.add_argument("--embedding-seed", type=int, default=42)
    parser.add_argument("--bootstrap-seed", type=int, default=20261015)
    parser.add_argument("--k-min", type=int, default=10)
    parser.add_argument("--k-max", type=int, default=40)
    parser.add_argument("--svd-components", type=int, default=50)
    args = parser.parse_args()

    repo = args.repo_root.resolve()
    json_path = args.json or repo / "data/section2/interim/mcdm_master_models.json"
    output_dir = args.output_dir or repo / "outputs/generated/section2"
    figure_dir = repo / "figures/generated/section2"
    output_dir.mkdir(parents=True, exist_ok=True)
    figure_dir.mkdir(parents=True, exist_ok=True)
    build_script = repo / "src/section2/02_build_final_criteria.py"

    items, build_module = build_raw_items(json_path, build_script)
    write_approved_codebook(build_module, output_dir / "approved_operational_codebook.csv")
    save_csv(output_dir / "raw_criteria.csv", items)

    legacy_codes = [item["legacy_code"] for item in items]
    legacy_lookup = {code: i for i, code in enumerate(sorted(set(legacy_codes)))}
    legacy = np.array([legacy_lookup[code] for code in legacy_codes])

    variants = ["weighted", "name_desc_parent", "name_desc"]
    scan_rows: list[dict[str, Any]] = []
    embeddings: dict[str, np.ndarray] = {}
    labels_store: dict[tuple[str, int], np.ndarray] = {}
    embedding_metadata: list[dict[str, Any]] = []

    for variant in variants:
        texts = [text_for(item, variant) for item in items]
        embedding, metadata = make_embedding(texts, args.svd_components, args.embedding_seed)
        embeddings[variant] = embedding
        embedding_metadata.append({"variant": variant, **metadata})
        for k in range(args.k_min, args.k_max + 1):
            labels = agglomerative(embedding, k)
            labels_store[(variant, k)] = labels
            stability = bootstrap_stability(
                embedding, labels, k, args.bootstrap_reps, args.bootstrap_fraction, args.bootstrap_seed
            )
            sizes = np.bincount(labels)
            precision, recall, f1 = pairwise_prf(legacy, labels)
            scan_rows.append(
                {
                    "variant": variant,
                    "k": k,
                    "silhouette_cosine": float(silhouette_score(embedding, labels, metric="cosine")),
                    "legacy_ari": float(adjusted_rand_score(legacy, labels)),
                    "legacy_nmi": float(normalized_mutual_info_score(legacy, labels)),
                    **stability,
                    "singleton_clusters": int((sizes == 1).sum()),
                    "singleton_rate": float((sizes == 1).sum() / k),
                    "min_cluster_size": int(sizes.min()),
                    "median_cluster_size": float(np.median(sizes)),
                    "max_cluster_size": int(sizes.max()),
                    "pair_precision": precision,
                    "pair_recall": recall,
                    "pair_f1": f1,
                }
            )

    selection_rows: list[dict[str, Any]] = []
    for variant in variants:
        rows = [row for row in scan_rows if row["variant"] == variant]
        max_silhouette = max(row["silhouette_cosine"] for row in rows)
        eligible = [
            row
            for row in rows
            if row["silhouette_cosine"] >= 0.95 * max_silhouette
            and row["bootstrap_ari_mean"] >= 0.90
            and row["singleton_rate"] <= 0.40
        ]
        chosen = min(eligible, key=lambda row: row["k"]) if eligible else max(
            rows, key=lambda row: (row["silhouette_cosine"], row["bootstrap_ari_mean"])
        )
        selection_rows.append(
            {
                "variant": variant,
                "max_silhouette": max_silhouette,
                "selected_k": chosen["k"],
                "selected_silhouette": chosen["silhouette_cosine"],
                "selected_stability": chosen["bootstrap_ari_mean"],
                "selected_legacy_ari": chosen["legacy_ari"],
                "selected_legacy_nmi": chosen["legacy_nmi"],
                "selected_singletons": chosen["singleton_clusters"],
            }
        )

    main_variant = "weighted"
    selected_k = int(next(row["selected_k"] for row in selection_rows if row["variant"] == main_variant))
    solutions: dict[str, tuple[list[dict[str, Any]], list[dict[str, Any]]]] = {}
    for name, k in [("Legacy_count_k26", 26), ("Free_selected", selected_k)]:
        solutions[name] = summarize_solution(
            name, k, labels_store[(main_variant, k)], embeddings[main_variant], items, output_dir
        )

    hdbscan_rows = run_hdbscan_scan(
        embeddings[main_variant], legacy, range(2, 9), [1, 2, 3, 4, 5, None]
    )
    save_csv(output_dir / "hdbscan_scan.csv", hdbscan_rows)

    free_assignments = solutions["Free_selected"][1]
    review_rows = [row for row in free_assignments if not row["majority_match"] or float(row["cluster_purity"]) < 0.80]
    save_csv(output_dir / "manual_review_candidates.csv", review_rows)

    save_csv(output_dir / "embedding_metadata.csv", embedding_metadata)
    save_csv(output_dir / "k_scan.csv", scan_rows)
    save_csv(output_dir / "k_selection.csv", selection_rows)

    summary_rows: list[dict[str, Any]] = []
    for row in selection_rows:
        summary_rows.append(
            {
                "item": f"Selected k ({row['variant']})",
                "value": row["selected_k"],
                "interpretation": f"Silhouette={row['selected_silhouette']:.3f}; stability={row['selected_stability']:.3f}",
            }
        )
    for k in [26, selected_k]:
        row = next(r for r in scan_rows if r["variant"] == main_variant and r["k"] == k)
        for label, value, interpretation in [
            ("silhouette", row["silhouette_cosine"], "Higher indicates more cohesive/separated clusters."),
            ("bootstrap stability", row["bootstrap_ari_mean"], "Resampling ARI; 1 is perfectly stable."),
            ("agreement with approved ARI", row["legacy_ari"], "Chance-adjusted partition agreement."),
            ("agreement with approved NMI", row["legacy_nmi"], "Information overlap between partitions."),
            ("pairwise precision", row["pair_precision"], "Embedding-paired criteria also paired in approved codebook."),
            ("pairwise recall", row["pair_recall"], "Approved same-family pairs recovered by clustering."),
            ("singleton clusters", row["singleton_clusters"], "Fine-grained/single-item clusters."),
        ]:
            summary_rows.append(
                {"item": f"k={k} {label}", "value": value, "interpretation": interpretation}
            )
    save_csv(output_dir / "validation_summary.csv", summary_rows)

    generate_figures(
        scan_rows,
        selection_rows,
        main_variant,
        selected_k,
        solutions["Free_selected"][0],
        embeddings[main_variant],
        items,
        figure_dir,
    )
    print(f"Section 2 outputs written to {output_dir}")
    print(f"Section 2 figures written to {figure_dir}")


if __name__ == "__main__":
    main()
