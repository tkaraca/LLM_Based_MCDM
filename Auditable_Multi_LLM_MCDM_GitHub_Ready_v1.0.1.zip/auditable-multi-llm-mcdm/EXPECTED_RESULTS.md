# Frozen Expected Results

## Criterion discovery

| Representation | Selected k | Silhouette | Mean resampling ARI | Singleton rate |
|---|---:|---:|---:|---:|
| Weighted name–description–parent | 32 | 0.489253 | 0.975080 | 0.343750 |
| Name–description–parent | 29 | 0.436892 | 0.945170 | 0.172414 |
| Name–description | 33 | 0.516392 | 0.963929 | 0.393939 |

Cosine HDBSCAN primary: 25 clusters, 15% noise, silhouette 0.630243. Euclidean sensitivity: 24 clusters, 15% noise, silhouette 0.642138.

## Criterion selection

- 26 approved operational families
- 10 conceptual core scoring families
- 6 optional add-ons
- 3 hard constraints
- 7 merge/drop decisions

## Final public-data weights

| Criterion | Weight |
|---|---:|
| D12 response-accessibility composite | 0.3864862659 |
| D5 route redundancy | 0.1854841605 |
| D7 last-mile HGV accessibility proxy | 0.1535391947 |
| D6 strategic-gateway access | 0.1456039562 |
| D8 site-area/staging potential | 0.1288864226 |

## Primary PROMETHEE II top five

| Rank | Alternative | Net flow |
|---:|---|---:|
| 1 | Bayrampaşa Wholesale Produce Market | 0.3383867491 |
| 2 | Yenikapı Event Area | 0.2286483113 |
| 3 | Büyük İstanbul Coach Terminal | 0.2240935891 |
| 4 | İSTOÇ Trade Center | 0.2032227154 |
| 5 | Yenikapı Ferry Terminal | 0.1886815619 |

## Robustness

- PROMETHEE–TOPSIS Spearman: 0.914706
- PROMETHEE–VIKOR Spearman: 0.950000
- TOPSIS–VIKOR Spearman: 0.961765
- Base D12 vs D1-only: 0.964706
- Base D12 vs D2-only: 0.941176
- Bayrampaşa first-place Monte Carlo frequency: 5,000/5,000

## Human benchmark

| Criterion | Kendall W | ICC(2,k) | Within ±2 |
|---|---:|---:|---:|
| D5 | 0.922053 | 0.971371 | 75.0% |
| D7 | 0.871526 | 0.966892 | 43.8% |
| D8 | 0.947921 | 0.982767 | 75.0% |

Overall data–human MAE 1.725072; RMSE 2.129034; bias −0.259446; 64.583% within ±2.

Data-only vs 75% data + 25% human: Spearman 0.982353; Kendall 0.916667; top-three overlap 3/3; top-five overlap 4/5.
