#!/usr/bin/env python3
"""Reproduce the frozen five-criterion public-data MCDM model."""
from __future__ import annotations

import argparse
import json
import math
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

from mcdm_core import derive_thresholds, minmax, promethee_ii, spearman_rank_correlation, topsis, vikor


def load_config(root: Path) -> dict[str, Any]:
    return json.loads((root / "config/study_config.json").read_text(encoding="utf-8"))


def build_utilities(metrics: pd.DataFrame, cfg: dict[str, Any]) -> tuple[pd.DataFrame, pd.DataFrame]:
    active = metrics[metrics["analysis_status"].eq("INCLUDE_CONDITIONAL")].copy().reset_index(drop=True)
    if len(active) != 16:
        raise ValueError(f"Expected 16 retained alternatives, found {len(active)}")
    d1_weight = float(cfg["component_weights"]["D1"])
    d2_weight = float(cfg["component_weights"]["D2"])
    d12_total = d1_weight + d2_weight
    d1_share, d2_share = d1_weight / d12_total, d2_weight / d12_total
    indexed = active.set_index("alternative_id")
    utilities = pd.DataFrame(index=indexed.index)
    utilities["D1"] = minmax(indexed["D1_population_weighted_travel_time_min"], False)
    utilities["D2"] = minmax(indexed["D2_population_coverage_30min"], True)
    utilities["D12"] = d1_share * utilities["D1"] + d2_share * utilities["D2"]
    utilities["D5"] = minmax(indexed["D5_osm_route_redundancy_index"], True)
    utilities["D6"] = minmax(indexed["D6_nearest_gateway_time_min"], False)
    utilities["D7"] = minmax(indexed["D7_osm_last_mile_hgv_proxy"], True)
    utilities["D8"] = minmax(np.log1p(pd.to_numeric(indexed["site_area_proxy_m2"])), True)
    metadata = indexed[["refined_name", "site_area_proxy_m2", "area_status", "source_id"]].copy()
    return utilities, metadata


def monte_carlo(
    utilities: pd.DataFrame,
    metadata: pd.DataFrame,
    thresholds: pd.DataFrame,
    weights: dict[str, float],
    cfg: dict[str, Any],
    iterations: int,
) -> pd.DataFrame:
    """Propagate weight, threshold, and D8 source uncertainty.

    The simulation uses a pure-NumPy PROMETHEE II kernel so the manuscript
    configuration of 5,000 iterations remains practical on ordinary hardware.
    The random-number draw order and ranking rule are unchanged from the
    reference implementation.
    """
    mc = cfg["monte_carlo"]
    rng = np.random.default_rng(int(mc["seed"]))
    ids = list(utilities.index)
    criteria = list(weights)
    base_w = np.array([weights[c] for c in criteria], dtype=float)
    base_w /= base_w.sum()
    alpha = np.maximum(base_w * float(mc["dirichlet_concentration"]), 0.5)

    threshold_index = thresholds.set_index("criterion")
    q0 = np.array([float(threshold_index.at[c, "q"]) for c in criteria], dtype=float)
    p0 = np.array([float(threshold_index.at[c, "p"]) for c in criteria], dtype=float)
    base_array = utilities[criteria].to_numpy(float)
    d8_index = criteria.index("D8")

    counts = np.zeros((len(ids), len(ids)), dtype=int)
    rank_sum = np.zeros(len(ids), dtype=float)
    rank_sq = np.zeros(len(ids), dtype=float)
    official = ~metadata["area_status"].str.contains("SECONDARY|MULTI_SOURCE", case=False, na=False)
    raw_area = pd.to_numeric(metadata["site_area_proxy_m2"]).to_numpy(float)
    sigma = np.where(
        official.to_numpy(),
        float(mc["official_d8_sigma"]),
        float(mc["secondary_d8_sigma"]),
    )
    low, high = map(float, mc["threshold_multiplier"])
    n = len(ids)

    for _ in range(iterations):
        drawn_weights = rng.dirichlet(alpha)
        multiplier = rng.uniform(low, high)
        q = np.minimum(np.maximum(q0 * multiplier, 0.0), 0.8)
        p = np.minimum(np.maximum(p0 * multiplier, q + 0.03), 1.0)

        sampled_area = raw_area * np.exp(rng.normal(0.0, sigma))
        log_area = np.log1p(sampled_area)
        area_min, area_max = float(log_area.min()), float(log_area.max())
        if abs(area_max - area_min) < 1e-12:
            d8 = np.ones_like(log_area)
        else:
            d8 = (log_area - area_min) / (area_max - area_min)

        sampled = base_array.copy()
        sampled[:, d8_index] = d8
        differences = sampled[:, None, :] - sampled[None, :, :]
        preferences = np.where(
            differences <= q[None, None, :],
            0.0,
            np.where(
                differences >= p[None, None, :],
                1.0,
                (differences - q[None, None, :]) / (p - q)[None, None, :],
            ),
        )
        preference_index = preferences @ drawn_weights
        phi_net = (preference_index.sum(axis=1) - preference_index.sum(axis=0)) / (n - 1)
        ranks = pd.Series(phi_net).rank(ascending=False, method="min").astype(int).to_numpy()

        counts[np.arange(n), ranks - 1] += 1
        rank_sum += ranks
        rank_sq += ranks**2

    rows = []
    for i, alternative_id in enumerate(ids):
        mean_rank = rank_sum[i] / iterations
        rank_sd = math.sqrt(max(rank_sq[i] / iterations - mean_rank**2, 0))
        rows.append(
            {
                "alternative_id": alternative_id,
                "mean_rank": mean_rank,
                "rank_sd": rank_sd,
                "p_rank_1": counts[i, 0] / iterations,
                "p_top3": counts[i, :3].sum() / iterations,
                "p_top5": counts[i, :5].sum() / iterations,
                **{f"p_rank_{rank+1:02d}": counts[i, rank] / iterations for rank in range(len(ids))},
            }
        )
    return pd.DataFrame(rows).sort_values(["mean_rank", "p_top3"], ascending=[True, False])


def main(root: Path, iterations: int | None = None) -> None:
    config = load_config(root)["public_model"]
    weights = {key: float(value) for key, value in config["weights"].items()}
    out = root / "outputs/03_public_data_mcdm"
    out.mkdir(parents=True, exist_ok=True)
    metrics = pd.read_csv(root / "data/public/raw_performance.csv", encoding="utf-8-sig")
    for column in [
        "D1_population_weighted_travel_time_min",
        "D2_population_coverage_30min",
        "D5_osm_route_redundancy_index",
        "D6_nearest_gateway_time_min",
        "D7_osm_last_mile_hgv_proxy",
        "site_area_proxy_m2",
    ]:
        metrics[column] = pd.to_numeric(metrics[column], errors="raise")
    utilities, metadata = build_utilities(metrics, config)
    primary = utilities[list(weights)]
    thresholds = derive_thresholds(primary)
    promethee = promethee_ii(primary, weights, thresholds)
    topsis_result = topsis(primary, weights)
    vikor_result = vikor(primary, weights, float(config["vikor_v"]))
    results = metadata.join(primary).join(promethee).join(topsis_result).join(vikor_result)
    results["mean_method_rank"] = results[["PROMETHEE_rank", "TOPSIS_rank", "VIKOR_rank"]].mean(axis=1)
    results["method_rank_sd"] = results[["PROMETHEE_rank", "TOPSIS_rank", "VIKOR_rank"]].std(axis=1, ddof=0)
    results["consensus_rank"] = results["mean_method_rank"].rank(ascending=True, method="min").astype(int)
    results = results.sort_values(["PROMETHEE_rank", "phi_net"], ascending=[True, False])

    other_weights = {key: value for key, value in weights.items() if key != "D12"}
    d1_weights = {"D1": weights["D12"], **other_weights}
    d2_weights = {"D2": weights["D12"], **other_weights}
    d1_ranking = promethee_ii(utilities[list(d1_weights)], d1_weights, derive_thresholds(utilities[list(d1_weights)]))
    d2_ranking = promethee_ii(utilities[list(d2_weights)], d2_weights, derive_thresholds(utilities[list(d2_weights)]))
    sensitivity = pd.DataFrame(index=utilities.index)
    sensitivity["base_D12_rank"] = promethee["PROMETHEE_rank"].reindex(utilities.index)
    sensitivity["D1_only_rank"] = d1_ranking["PROMETHEE_rank"].reindex(utilities.index)
    sensitivity["D2_only_rank"] = d2_ranking["PROMETHEE_rank"].reindex(utilities.index)
    sensitivity = sensitivity.join(metadata[["refined_name"]])
    sensitivity["abs_change_D1"] = (sensitivity["base_D12_rank"] - sensitivity["D1_only_rank"]).abs()
    sensitivity["abs_change_D2"] = (sensitivity["base_D12_rank"] - sensitivity["D2_only_rank"]).abs()
    sensitivity = sensitivity.sort_values("base_D12_rank")

    correlations = pd.DataFrame(
        [
            ["PROMETHEE vs TOPSIS", spearman_rank_correlation(results["PROMETHEE_rank"], results["TOPSIS_rank"])],
            ["PROMETHEE vs VIKOR", spearman_rank_correlation(results["PROMETHEE_rank"], results["VIKOR_rank"])],
            ["TOPSIS vs VIKOR", spearman_rank_correlation(results["TOPSIS_rank"], results["VIKOR_rank"])],
            ["Base D12 vs D1-only", spearman_rank_correlation(sensitivity["base_D12_rank"], sensitivity["D1_only_rank"])],
            ["Base D12 vs D2-only", spearman_rank_correlation(sensitivity["base_D12_rank"], sensitivity["D2_only_rank"])],
        ],
        columns=["comparison", "spearman_rho"],
    )
    n_iterations = int(iterations if iterations is not None else config["monte_carlo"]["iterations"])
    mc = monte_carlo(primary, metadata, thresholds, weights, config, n_iterations)
    mc = mc.merge(metadata[["refined_name"]], left_on="alternative_id", right_index=True, how="left")

    utilities.reset_index().to_csv(out / "all_component_utilities.csv", index=False, encoding="utf-8-sig")
    primary.reset_index().to_csv(out / "final_public_data_utility_matrix.csv", index=False, encoding="utf-8-sig")
    thresholds.to_csv(out / "promethee_thresholds.csv", index=False, encoding="utf-8-sig")
    results.reset_index().to_csv(out / "final_mcdm_rankings.csv", index=False, encoding="utf-8-sig")
    sensitivity.reset_index().to_csv(out / "d1_d2_sensitivity.csv", index=False, encoding="utf-8-sig")
    correlations.to_csv(out / "method_rank_correlations.csv", index=False, encoding="utf-8-sig")
    mc.to_csv(out / "monte_carlo_rank_acceptability.csv", index=False, encoding="utf-8-sig")
    specification = {
        "weights": weights,
        "component_weights": config["component_weights"],
        "threshold_rule": "Q25/Q75 of non-zero pairwise utility differences",
        "monte_carlo_iterations": n_iterations,
        "monte_carlo_seed": config["monte_carlo"]["seed"],
        "hard_constraints": "outside compensatory scoring; NOT_VERIFIED retained as post-ranking verification flags",
        "optional_families": "not activated in the primary case-study specification",
    }
    (out / "final_model_specification.json").write_text(json.dumps(specification, ensure_ascii=False, indent=2), encoding="utf-8")
    print(results[["refined_name", "phi_net", "PROMETHEE_rank", "TOPSIS_rank", "VIKOR_rank"]].to_string())


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--monte-carlo", type=int, default=None)
    args = parser.parse_args()
    main(args.root.resolve(), args.monte_carlo)
