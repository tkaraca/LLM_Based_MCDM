
#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Build a final weighted MCDM criterion shortlist from a structured JSON file.

Input
-----
A JSON file that follows the schema produced by `docx_to_mcdm_json.py`.

Core methodological steps implemented
-------------------------------------
1. Flatten model-specific criteria.
2. Canonicalize semantically equivalent criteria to avoid double counting.
3. Aggregate *within each model and canonical criterion* using MAX(global weight)
   so that a model does not gain artificial influence merely because it split one
   concept into multiple fine-grained subcriteria.
4. Separate hard constraints from compensatory scoring criteria.
5. Compute evidence channels for each canonical criterion:
   - coverage across models
   - median global weight
   - median within-model percentile
   - top / bottom support ratios
   - completeness ratio
6. Apply an acute-phase adjustment profile (default: first 72 hours).
7. Classify criteria into:
   - CORE_SCORING
   - OPTIONAL_ADDON
   - MERGE_INTO_...
   - DROP_ACUTE
   - HARD_CONSTRAINT
8. Normalize the selected core criteria into final weights and export an Excel workbook.

Usage
-----
python build_final_criteria.py --input mcdm_master_models.json --output final_criteria.xlsx
"""

from __future__ import annotations

import argparse
import json
import math
import re
import unicodedata
from collections import Counter, defaultdict
from pathlib import Path
from statistics import median
from typing import Any

import pandas as pd
from openpyxl import load_workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter


TR_TRANS = str.maketrans(
    {
        "ç": "c",
        "Ç": "c",
        "ğ": "g",
        "Ğ": "g",
        "ı": "i",
        "I": "i",
        "İ": "i",
        "ö": "o",
        "Ö": "o",
        "ş": "s",
        "Ş": "s",
        "ü": "u",
        "Ü": "u",
        "â": "a",
        "î": "i",
        "û": "u",
    }
)


def norm_text(text: str | None) -> str:
    if text is None:
        return ""
    text = str(text).translate(TR_TRANS).lower()
    text = unicodedata.normalize("NFKD", text)
    text = "".join(ch for ch in text if not unicodedata.combining(ch))
    text = re.sub(r"[^a-z0-9]+", " ", text)
    return " ".join(text.split())


def quantile(values: list[float], q: float) -> float | None:
    vals = sorted(v for v in values if v is not None and not pd.isna(v))
    if not vals:
        return None
    if len(vals) == 1:
        return vals[0]
    pos = (len(vals) - 1) * q
    lo = int(math.floor(pos))
    hi = int(math.ceil(pos))
    if lo == hi:
        return vals[lo]
    return vals[lo] + (vals[hi] - vals[lo]) * (pos - lo)


def iqr(values: list[float]) -> float | None:
    vals = [v for v in values if v is not None and not pd.isna(v)]
    if not vals:
        return None
    if len(vals) == 1:
        return 0.0
    return quantile(vals, 0.75) - quantile(vals, 0.25)


CANONICAL_LIBRARY = [
    {
        "canonical_code": "RSK_GEOLOGICAL",
        "canonical_name": "Jeolojik zemin / fay riski",
        "macro_group": "RISK",
        "hard_constraint": True,
        "keywords": ["jeolojik", "zemin", "fay", "sivilasma", "heyelan", "geolojik"],
    },
    {
        "canonical_code": "RSK_STRUCTURAL",
        "canonical_name": "Yapısal dayanıklılık",
        "macro_group": "RISK",
        "hard_constraint": True,
        "keywords": ["yapisal dayaniklilik", "deprem yonetmeligi", "muhendislik raporu", "tbdy", "uygunluk"],
    },
    {
        "canonical_code": "RSK_SECONDARY_HAZARD",
        "canonical_name": "İkincil tehlike / afet maruziyeti",
        "macro_group": "RISK",
        "hard_constraint": True,
        "keywords": ["ikincil afet", "ikincil tehlike", "tsunami", "sel", "yangin", "kimyasal", "endustriyel", "tehlikeli madde"],
    },
    {
        "canonical_code": "ACC_MAIN_ARTERY",
        "canonical_name": "Ana arter / tedarik koridoru yakınlığı",
        "macro_group": "ACCESS",
        "hard_constraint": False,
        "keywords": ["ana arter", "ana yol", "ana yollara", "ana arterlere", "havalimani", "limana olan mesafe"],
    },
    {
        "canonical_code": "ACC_INTERMODALITY",
        "canonical_name": "Ulaşım modu çeşitliliği / intermodalite",
        "macro_group": "ACCESS",
        "hard_constraint": False,
        "keywords": ["intermodal", "ulasim modu", "coklu ulasim", "modu cesitliligi", "modu destegi", "cok modlu", "demiryolu", "helikopter"],
    },
    {
        "canonical_code": "ACC_ROAD_REDUNDANCY",
        "canonical_name": "Yol ağı yedekliliği / alternatif rota",
        "macro_group": "ACCESS",
        "hard_constraint": False,
        "keywords": ["yedekliligi", "alternatif rota", "alternatif guzergah", "redundancy", "alternatiflik"],
    },
    {
        "canonical_code": "ACC_LAST_MILE",
        "canonical_name": "Son kilometre erişilebilirliği / engel riski",
        "macro_group": "ACCESS",
        "hard_constraint": False,
        "keywords": ["son kilometre", "last mile", "enkaz", "engeller", "dar sokak", "egim", "zorlugu", "uygunlugu"],
    },
    {
        "canonical_code": "SRV_RESPONSE_TIME",
        "canonical_name": "Ortalama müdahale / ulaşım süresi",
        "macro_group": "SERVICE",
        "hard_constraint": False,
        "keywords": ["mudahale suresi", "ulasim suresi", "cevap suresi", "ortalama ulasim", "ortalama mudahale", "response time"],
    },
    {
        "canonical_code": "SRV_TIME_COVERAGE",
        "canonical_name": "Kritik sürede kapsama oranı / nüfus",
        "macro_group": "SERVICE",
        "hard_constraint": False,
        "keywords": ["kapsanan nufus", "zaman esigi", "kritik surede", "kapsama", "30 60 dk icinde"],
    },
    {
        "canonical_code": "SRV_DEMAND_INTENSITY",
        "canonical_name": "Talep yoğunluğu / talep-uyum potansiyeli",
        "macro_group": "SERVICE",
        "hard_constraint": False,
        "keywords": ["beklenen talep", "talep yogunlugu", "talep yogunlugu uyumu", "talep karsilama", "ihtiyac", "demand"],
    },
    {
        "canonical_code": "SRV_NEED_VULNERABILITY",
        "canonical_name": "Kırılganlık / sosyoekonomik ihtiyaç baskısı",
        "macro_group": "SERVICE",
        "hard_constraint": False,
        "keywords": ["kirilgan nufus", "yoksulluk", "hazirliksiz", "sosyoekonomik", "yerinden edilme", "yogunlasma riski", "vulnerability"],
    },
    {
        "canonical_code": "SRV_EQUITY_ACCESS",
        "canonical_name": "Öncelikli gruplara erişim / adil erişim",
        "macro_group": "SERVICE",
        "hard_constraint": False,
        "keywords": ["adalet", "oncelikli gruplar", "kirilgan gruplara erisim", "erisim adaleti", "hizmet esitsizligi", "adil erisim", "equity"],
    },
    {
        "canonical_code": "SRV_OVERLAP",
        "canonical_name": "Hizmet alanı örtüşme oranı",
        "macro_group": "SERVICE",
        "hard_constraint": False,
        "keywords": ["ortusme", "hizmet alani ortusme"],
    },
    {
        "canonical_code": "CAP_STORAGE",
        "canonical_name": "Depolama kapasitesi / alan büyüklüğü",
        "macro_group": "CAPACITY",
        "hard_constraint": False,
        "keywords": ["depolama", "hacmi", "alani buyuklugu", "kapasitesi", "palet", "stok tutma"],
    },
    {
        "canonical_code": "CAP_THROUGHPUT",
        "canonical_name": "Yükleme-boşaltma verimliliği / manevra alanı",
        "macro_group": "CAPACITY",
        "hard_constraint": False,
        "keywords": ["yukleme", "bosaltma", "throughput", "rampa", "manevra", "arac park", "islem hizi"],
    },
    {
        "canonical_code": "CAP_INFRA_REDUNDANCY",
        "canonical_name": "Kritik altyapı yedekliliği / kesinti toleransı",
        "macro_group": "CAPACITY",
        "hard_constraint": False,
        "keywords": ["kritik altyapi", "jenerator", "su deposu", "iletisim", "kesinti toleransi", "yedek altyapi", "sureklilik", "b plani"],
    },
    {
        "canonical_code": "CAP_EXPANSION",
        "canonical_name": "Genişleme potansiyeli / esnekliği",
        "macro_group": "CAPACITY",
        "hard_constraint": False,
        "keywords": ["genisleme", "rezerv alan", "genisleme uygunlugu", "genisleme esnekligi", "potansiyeli"],
    },
    {
        "canonical_code": "OPS_ACTIVATION_TIME",
        "canonical_name": "Kurulum / aktivasyon / temin süresi",
        "macro_group": "OPERATIONS",
        "hard_constraint": False,
        "keywords": ["aktivasyon", "kurulum", "temin suresi", "time to setup", "hazirlik suresi", "operasyonel hale gelme"],
    },
    {
        "canonical_code": "OPS_WORKFORCE",
        "canonical_name": "İş gücü erişilebilirliği",
        "macro_group": "OPERATIONS",
        "hard_constraint": False,
        "keywords": ["is gucu", "gonullu", "vardiya", "ekip sayisi"],
    },
    {
        "canonical_code": "OPS_COORDINATION",
        "canonical_name": "Koordinasyon / komuta uyumu",
        "macro_group": "OPERATIONS",
        "hard_constraint": False,
        "keywords": ["koordinasyon", "komuta", "afad", "belediye", "umke", "prosedur uyumu"],
    },
    {
        "canonical_code": "OPS_TRACEABILITY_IT",
        "canonical_name": "İzlenebilirlik / bilgi sistemi",
        "macro_group": "OPERATIONS",
        "hard_constraint": False,
        "keywords": ["izlenebilirlik", "bilgi sistemi", "stok takibi", "veri paylasimi", "traceability"],
    },
    {
        "canonical_code": "RSK_SECURITY_SOCIAL",
        "canonical_name": "Asayiş / güvenlik / toplumsal kabul riski",
        "macro_group": "RISK",
        "hard_constraint": False,
        "keywords": ["asayis", "yagma", "guvenlik olay", "kalabalik", "toplumsal kabul", "catisma", "sosyal guvenlik"],
    },
    {
        "canonical_code": "RSK_ENV_WASH",
        "canonical_name": "Çevresel-sıhhi / WASH riski",
        "macro_group": "RISK",
        "hard_constraint": False,
        "keywords": ["cevresel", "sihhi", "sanitasyon", "atik", "wash", "hijyen", "su kaynaklarina"],
    },
    {
        "canonical_code": "CST_SETUP",
        "canonical_name": "Kurulum / hazırlık maliyeti",
        "macro_group": "COST",
        "hard_constraint": False,
        "keywords": ["kurulum maliyeti", "hazirlik maliyeti", "ilk yatirim", "kurulum ve hazirlik", "kurulum hazirlik maliyeti"],
    },
    {
        "canonical_code": "CST_OPERATIONAL",
        "canonical_name": "Operasyonel / birim dağıtım maliyeti",
        "macro_group": "COST",
        "hard_constraint": False,
        "keywords": ["birim dagitim", "operasyonel dagitim", "operasyonel gider", "dagitim maliyeti", "yakit", "personel maliyeti"],
    },
    {
        "canonical_code": "CST_RESOURCE_EFFICIENCY",
        "canonical_name": "Kaynak verimliliği / sürdürülebilirlik",
        "macro_group": "COST",
        "hard_constraint": False,
        "keywords": ["kaynak verimlilik", "surdurulebilir", "atik minimizasyonu", "yeniden kullanim", "enerji verimliligi"],
    },
]

for item in CANONICAL_LIBRARY:
    item["kw_norm"] = [norm_text(k) for k in item["keywords"]]

PHASE_PROFILES = {
    "acute_72h": {
        "context_keywords": ["72", "acil", "yaşam kurtarma", "hayat kurtarma", "first 72", "ilk 72"],
        "score_adjustments": {
            "SRV_RESPONSE_TIME": 0.03,
            "SRV_TIME_COVERAGE": 0.03,
            "ACC_ROAD_REDUNDANCY": 0.02,
            "ACC_LAST_MILE": 0.02,
            "ACC_MAIN_ARTERY": 0.01,
            "SRV_DEMAND_INTENSITY": 0.02,
            "SRV_EQUITY_ACCESS": 0.02,
            "CAP_STORAGE": 0.01,
            "CAP_THROUGHPUT": 0.02,
            "CAP_INFRA_REDUNDANCY": 0.02,
            "OPS_ACTIVATION_TIME": 0.02,
            "ACC_INTERMODALITY": -0.03,
            "CAP_EXPANSION": -0.05,
            "CST_SETUP": -0.04,
            "CST_OPERATIONAL": -0.02,
            "CST_RESOURCE_EFFICIENCY": -0.06,
            "RSK_ENV_WASH": -0.03,
            "OPS_TRACEABILITY_IT": -0.02,
            "SRV_OVERLAP": -0.03,
        },
    }
}

MERGE_RULES = {
    "SRV_NEED_VULNERABILITY": "SRV_EQUITY_ACCESS",
}

OPTIONAL_PREFERRED = {
    "OPS_WORKFORCE",
    "OPS_COORDINATION",
    "OPS_TRACEABILITY_IT",
    "RSK_SECURITY_SOCIAL",
    "CST_OPERATIONAL",
    "CST_SETUP",
    "ACC_INTERMODALITY",
    "OPS_ACTIVATION_TIME",
}

GROUP_QUOTAS = {
    "ACCESS": {"min": 2, "max": 3},
    "SERVICE": {"min": 2, "max": 4},
    "CAPACITY": {"min": 2, "max": 3},
    "OPERATIONS": {"min": 0, "max": 2},
    "RISK": {"min": 0, "max": 2},
    "COST": {"min": 0, "max": 1},
}


def detect_phase_profile(data: dict[str, Any]) -> str:
    context_blob = json.dumps(data.get("document", {}), ensure_ascii=False).lower()
    if any(k in context_blob for k in PHASE_PROFILES["acute_72h"]["context_keywords"]):
        return "acute_72h"
    return "acute_72h"


def canonicalize_name_fields(name: str, description: str = "", parent_name: str = "") -> tuple[dict[str, Any] | None, float]:
    n_name = norm_text(name)
    n_desc = norm_text(description)
    n_parent = norm_text(parent_name)

    best_item = None
    best_score = 0
    for item in CANONICAL_LIBRARY:
        score = 0
        for kw in item["kw_norm"]:
            if kw and kw in n_name:
                score += 3 * max(1, len(kw.split()))
            if kw and kw in n_desc:
                score += 2 * max(1, len(kw.split()))
            if kw and kw in n_parent:
                score += 1 * max(1, len(kw.split()))
        if score > best_score:
            best_score = score
            best_item = item
    return best_item, best_score


def flatten_occurrences(data: dict[str, Any]) -> list[dict[str, Any]]:
    phase_profile = detect_phase_profile(data)
    rows: list[dict[str, Any]] = []

    for model in data["models"]:
        model_id = model["model_id"]
        model_label = model.get("label", model_id)

        ranked = sorted(
            [
                (sub["code"], sub.get("global_weight"))
                for sub in model["subcriteria"]
                if sub.get("global_weight") is not None
            ],
            key=lambda x: x[1],
            reverse=True,
        )
        rank_map = {code: idx + 1 for idx, (code, _) in enumerate(ranked)}
        n_known = len(ranked)

        for sub in model["subcriteria"]:
            canonical, match_score = canonicalize_name_fields(
                sub["name"],
                sub.get("description", ""),
                sub.get("parent_name", ""),
            )
            if canonical is None:
                continue

            rank = rank_map.get(sub["code"])
            percentile = None
            if rank is not None and n_known > 1:
                percentile = 1 - (rank - 1) / (n_known - 1)
            elif rank == 1 and n_known == 1:
                percentile = 1.0

            top_flag = 1 if sub.get("highlight_tag") == "top" else 0
            bottom_flag = 1 if sub.get("highlight_tag") == "bottom" else 0
            if top_flag == 0 and percentile is not None and percentile >= 0.80:
                top_flag = 1
            if bottom_flag == 0 and percentile is not None and percentile <= 0.20:
                bottom_flag = 1

            rows.append(
                {
                    "model_id": model_id,
                    "model_label": model_label,
                    "source_code": sub["code"],
                    "source_name": sub["name"],
                    "source_parent_code": sub["parent_code"],
                    "source_parent_name": sub["parent_name"],
                    "description": sub.get("description"),
                    "data_type": sub.get("data_type"),
                    "direction": sub.get("optimization_direction"),
                    "local_weight": sub.get("local_weight"),
                    "global_weight": sub.get("global_weight"),
                    "weight_status": sub.get("weight_status"),
                    "approximate": bool(sub.get("approximate")),
                    "rank_within_model": rank,
                    "percentile_within_model": percentile,
                    "top_flag": top_flag,
                    "bottom_flag": bottom_flag,
                    "canonical_code": canonical["canonical_code"],
                    "canonical_name": canonical["canonical_name"],
                    "macro_group": canonical["macro_group"],
                    "hard_constraint_default": canonical["hard_constraint"],
                    "match_score": match_score,
                    "phase_profile": phase_profile,
                }
            )
    return rows


def aggregate_within_model_canonical(df_raw: pd.DataFrame) -> pd.DataFrame:
    """
    Important design choice:
    If a single model splits the same conceptual family into multiple raw criteria,
    we aggregate *within that model* using MAX(global weight), not SUM.
    This prevents artificial score inflation from finer granularity.
    """
    rows = []
    for (model_id, canonical_code), grp in df_raw.groupby(["model_id", "canonical_code"], dropna=False):
        weights = [x for x in grp["global_weight"].tolist() if pd.notna(x)]
        chosen_weight = max(weights) if weights else float("nan")

        if weights:
            idx = grp["global_weight"].fillna(-1).idxmax()
        else:
            idx = grp.index[0]
        rep = grp.loc[idx].to_dict()

        rep["source_codes_merged"] = sorted(grp["source_code"].tolist())
        rep["source_names_merged"] = sorted(grp["source_name"].tolist())
        rep["merged_raw_count"] = int(len(grp))
        rep["global_weight_model_canonical"] = chosen_weight
        rep["any_approximate"] = bool(grp["approximate"].any())
        rep["top_flag_model_canonical"] = int(grp["top_flag"].max())
        rep["bottom_flag_model_canonical"] = int(grp["bottom_flag"].max())
        rows.append(rep)

    df_mc = pd.DataFrame(rows)

    for model_id, grp in df_mc.groupby("model_id"):
        known = grp[pd.notna(grp["global_weight_model_canonical"])].copy()
        known = known.sort_values("global_weight_model_canonical", ascending=False)
        n = len(known)

        rank_map = {idx: rank + 1 for rank, idx in enumerate(known.index)}
        percentile_map = {}
        for rank, idx in enumerate(known.index, start=1):
            percentile_map[idx] = 1.0 if n == 1 else 1 - (rank - 1) / (n - 1)

        df_mc.loc[grp.index, "canonical_rank_within_model"] = float("nan")
        df_mc.loc[grp.index, "canonical_percentile_within_model"] = float("nan")

        for idx, rank in rank_map.items():
            df_mc.at[idx, "canonical_rank_within_model"] = rank
            df_mc.at[idx, "canonical_percentile_within_model"] = percentile_map[idx]

        for idx in grp.index:
            perc = df_mc.at[idx, "canonical_percentile_within_model"]
            if pd.notna(perc):
                if df_mc.at[idx, "top_flag_model_canonical"] == 0 and perc >= 0.80:
                    df_mc.at[idx, "top_flag_model_canonical"] = 1
                if df_mc.at[idx, "bottom_flag_model_canonical"] == 0 and perc <= 0.20:
                    df_mc.at[idx, "bottom_flag_model_canonical"] = 1

    return df_mc


def aggregate_canonical(df_mc: pd.DataFrame, phase_profile: str) -> pd.DataFrame:
    total_models = df_mc["model_id"].nunique()
    rows = []

    for canonical_code, grp in df_mc.groupby("canonical_code"):
        weights = [x for x in grp["global_weight_model_canonical"].tolist() if pd.notna(x)]
        percentiles = [x for x in grp["canonical_percentile_within_model"].tolist() if pd.notna(x)]

        rows.append(
            {
                "canonical_code": canonical_code,
                "canonical_name": grp["canonical_name"].iloc[0],
                "macro_group": grp["macro_group"].iloc[0],
                "hard_constraint": bool(grp["hard_constraint_default"].max()),
                "models_present": grp["model_id"].nunique(),
                "coverage_ratio": grp["model_id"].nunique() / total_models if total_models else float("nan"),
                "known_weight_count": len(weights),
                "median_global_weight": float(median(weights)) if weights else float("nan"),
                "median_percentile": float(median(percentiles)) if percentiles else float("nan"),
                "iqr_global_weight": iqr(weights),
                "iqr_percentile": iqr(percentiles),
                "top_support_ratio": float(grp["top_flag_model_canonical"].mean()) if len(grp) else float("nan"),
                "bottom_support_ratio": float(grp["bottom_flag_model_canonical"].mean()) if len(grp) else float("nan"),
                "completeness_ratio": float(grp["global_weight_model_canonical"].notna().mean()) if len(grp) else float("nan"),
                "approx_ratio": float(grp["any_approximate"].mean()) if len(grp) else float("nan"),
                "aliases": sorted(set(sum(grp["source_names_merged"].tolist(), []))),
                "parent_aliases": sorted(set(grp["source_parent_name"].tolist())),
                "model_labels_present": sorted(grp["model_label"].unique().tolist()),
                "merged_member_total": int(grp["merged_raw_count"].sum()),
            }
        )

    df = pd.DataFrame(rows)
    max_median_weight = df["median_global_weight"].max(skipna=True)
    if pd.notna(max_median_weight) and max_median_weight > 0:
        df["norm_median_global_weight"] = df["median_global_weight"] / max_median_weight
    else:
        df["norm_median_global_weight"] = float("nan")

    df["support_balance"] = (1 + df["top_support_ratio"].fillna(0) - df["bottom_support_ratio"].fillna(0)) / 2
    df["median_percentile_filled"] = df["median_percentile"].fillna(0.5)

    df["robust_importance"] = (
        0.35 * df["norm_median_global_weight"].fillna(0)
        + 0.25 * df["coverage_ratio"].fillna(0)
        + 0.20 * df["median_percentile_filled"]
        + 0.20 * df["support_balance"].fillna(0.5)
    )

    max_iqr_weight = df["iqr_global_weight"].max(skipna=True)
    df["disagreement_penalty"] = 0.0

    mask_percentile_known = df["iqr_percentile"].notna()
    df.loc[mask_percentile_known, "disagreement_penalty"] = (
        df.loc[mask_percentile_known, "iqr_percentile"].fillna(0) / 1.0
    )

    mask_percentile_missing = ~mask_percentile_known
    if pd.notna(max_iqr_weight) and max_iqr_weight > 0:
        df.loc[mask_percentile_missing, "disagreement_penalty"] = (
            df.loc[mask_percentile_missing, "iqr_global_weight"].fillna(0) / max_iqr_weight
        )
    df["disagreement_penalty"] = df["disagreement_penalty"].clip(0, 1)

    df["evidence_score"] = (
        df["robust_importance"]
        - 0.10 * df["disagreement_penalty"]
        + 0.05 * df["completeness_ratio"].fillna(0)
    ).clip(0, 1)

    adjustments = PHASE_PROFILES.get(phase_profile, {}).get("score_adjustments", {})
    df["phase_adjustment"] = df["canonical_code"].map(adjustments).fillna(0.0)
    df["final_score"] = (df["evidence_score"] + df["phase_adjustment"]).clip(0, 1)

    preliminary = []
    for _, row in df.iterrows():
        code = row["canonical_code"]
        if row["hard_constraint"]:
            preliminary.append("HARD_CONSTRAINT")
        elif code in MERGE_RULES:
            preliminary.append(f"MERGE_CANDIDATE->{MERGE_RULES[code]}")
        elif row["final_score"] >= 0.60 and row["coverage_ratio"] >= 0.40:
            preliminary.append("CORE_CANDIDATE")
        elif row["final_score"] >= 0.42:
            preliminary.append("OPTIONAL_CANDIDATE")
        else:
            preliminary.append("DROP_CANDIDATE")

    df["preliminary_decision"] = preliminary
    return df.sort_values(["hard_constraint", "final_score"], ascending=[False, False]).reset_index(drop=True)


def select_final_shortlist(df_can: pd.DataFrame, target_min: int = 10, target_max: int = 12) -> pd.DataFrame:
    df = df_can.copy().sort_values("final_score", ascending=False).reset_index(drop=True)
    df["final_decision"] = df["preliminary_decision"]

    merge_map: dict[str, str] = {}
    for idx, row in df.iterrows():
        if str(row["preliminary_decision"]).startswith("MERGE_CANDIDATE->"):
            target = row["preliminary_decision"].split("->", 1)[1]
            merge_map[row["canonical_code"]] = target
            df.at[idx, "final_decision"] = f"MERGE_INTO_{target}"

    candidate_pool = df[(~df["hard_constraint"]) & (~df["canonical_code"].isin(merge_map.keys()))].copy()

    selected: list[str] = []
    group_counts: Counter[str] = Counter()

    # Pass 1: strongest core candidates first
    for _, row in candidate_pool.sort_values("final_score", ascending=False).iterrows():
        if row["preliminary_decision"] != "CORE_CANDIDATE":
            continue
        if len(selected) >= target_max:
            break
        group = row["macro_group"]
        max_q = GROUP_QUOTAS.get(group, {}).get("max", 999)
        if group_counts[group] >= max_q:
            continue
        selected.append(row["canonical_code"])
        group_counts[group] += 1

    # Pass 2: guarantee minimum group coverage
    for group, quota in GROUP_QUOTAS.items():
        while group_counts[group] < quota.get("min", 0) and len(selected) < target_max:
            candidates = candidate_pool[
                (candidate_pool["macro_group"] == group)
                & (~candidate_pool["canonical_code"].isin(selected))
            ].sort_values("final_score", ascending=False)
            if candidates.empty:
                break
            best = candidates.iloc[0]
            selected.append(best["canonical_code"])
            group_counts[group] += 1

    # Pass 3: fill to target_min with best remaining criteria
    remaining = candidate_pool[~candidate_pool["canonical_code"].isin(selected)].copy()
    remaining["priority_tier"] = (remaining["preliminary_decision"] != "CORE_CANDIDATE").astype(int)
    remaining = remaining.sort_values(["priority_tier", "final_score"], ascending=[True, False])

    for _, row in remaining.iterrows():
        if len(selected) >= target_min and row["preliminary_decision"] != "CORE_CANDIDATE":
            break
        if len(selected) >= target_max:
            break
        group = row["macro_group"]
        max_q = GROUP_QUOTAS.get(group, {}).get("max", 999)
        if group_counts[group] >= max_q:
            continue
        if row["final_score"] >= 0.45:
            selected.append(row["canonical_code"])
            group_counts[group] += 1

    # Final labels
    for idx, row in df.iterrows():
        code = row["canonical_code"]
        if row["hard_constraint"]:
            df.at[idx, "final_decision"] = "HARD_CONSTRAINT"
        elif code in selected:
            df.at[idx, "final_decision"] = "CORE_SCORING"
        elif code in merge_map:
            df.at[idx, "final_decision"] = f"MERGE_INTO_{merge_map[code]}"
        elif row["final_score"] >= 0.42 or (code in OPTIONAL_PREFERRED and row["final_score"] >= 0.40):
            df.at[idx, "final_decision"] = "OPTIONAL_ADDON"
        else:
            df.at[idx, "final_decision"] = "DROP_ACUTE"

    core_df = df[df["final_decision"] == "CORE_SCORING"].copy().sort_values("final_score", ascending=False)
    total = core_df["final_score"].sum()
    core_df["final_weight"] = core_df["final_score"] / total if total > 0 else 0
    weight_map = dict(zip(core_df["canonical_code"], core_df["final_weight"]))
    df["final_weight"] = df["canonical_code"].map(weight_map)

    return df.sort_values(["final_decision", "final_score"], ascending=[True, False]).reset_index(drop=True)


def build_workbook(
    input_json: Path,
    output_xlsx: Path,
    target_min: int = 10,
    target_max: int = 12,
) -> None:
    data = json.loads(input_json.read_text(encoding="utf-8"))
    phase_profile = detect_phase_profile(data)

    raw_occurrences = pd.DataFrame(flatten_occurrences(data))
    model_canonical = aggregate_within_model_canonical(raw_occurrences)
    canonical = aggregate_canonical(model_canonical, phase_profile=phase_profile)
    final_df = select_final_shortlist(canonical, target_min=target_min, target_max=target_max)

    core_df = final_df[final_df["final_decision"] == "CORE_SCORING"].copy().sort_values("final_weight", ascending=False)
    core_df["rank"] = range(1, len(core_df) + 1)
    core_df = core_df[
        [
            "rank",
            "canonical_code",
            "canonical_name",
            "macro_group",
            "final_weight",
            "final_score",
            "coverage_ratio",
            "median_global_weight",
            "median_percentile",
            "aliases",
            "model_labels_present",
        ]
    ]

    constraints_df = final_df[final_df["final_decision"] == "HARD_CONSTRAINT"].copy().sort_values("final_score", ascending=False)
    constraints_df["reason"] = constraints_df["canonical_code"].map(
        {
            "RSK_GEOLOGICAL": "Non-compensatory safety screen: fay/zemin/sıvılaşma/heyelan riski",
            "RSK_STRUCTURAL": "Non-compensatory safety screen: taşıyıcı sistem ve deprem yönetmeliği uygunluğu",
            "RSK_SECONDARY_HAZARD": "Non-compensatory safety screen: sel/yangın/tsunami/kimyasal ikincil tehlike",
        }
    )

    optional_df = final_df[final_df["final_decision"] == "OPTIONAL_ADDON"].copy().sort_values("final_score", ascending=False)
    merge_drop_df = final_df[final_df["final_decision"].isin(["DROP_ACUTE"]) | final_df["final_decision"].str.startswith("MERGE_INTO_")].copy()
    merge_drop_df = merge_drop_df.sort_values("final_score", ascending=False)

    group_weights = core_df.groupby("macro_group", as_index=False)["final_weight"].sum().sort_values("final_weight", ascending=False)

    input_summary = []
    for model in data["models"]:
        comp = model.get("completeness", {})
        input_summary.append(
            {
                "model_id": model.get("model_id"),
                "label": model.get("label"),
                "main_criteria_count": len(model.get("main_criteria", [])),
                "subcriteria_count": comp.get("subcriteria_count"),
                "main_weights_reported_ratio": comp.get("main_weights_reported_ratio"),
                "local_weights_reported_ratio": comp.get("local_weights_reported_ratio"),
                "global_weights_available_ratio": comp.get("global_weights_available_ratio"),
                "approx_global_ratio": comp.get("approx_global_ratio"),
                "notes": model.get("notes"),
            }
        )
    input_summary_df = pd.DataFrame(input_summary)

    method_rows = [
        {"step": 1, "title": "Input harmonization", "detail": "JSON yüklenir; karar bağlamı ve model bazlı kriter ağacı okunur."},
        {"step": 2, "title": "Canonicalization", "detail": "Eşanlamlı / örtüşen alt kriterler deterministik anahtar sözcük kütüphanesi ile kanonik kriterlere eşlenir."},
        {"step": 3, "title": "Within-model merge", "detail": "Aynı modelde aynı kanonik aileye düşen çoklu ham kriterler MAX(global weight) ile tekilleştirilir; amaç double counting'i önlemektir."},
        {"step": 4, "title": "Constraint screening", "detail": "Jeolojik risk, yapısal dayanıklılık ve ikincil tehlike aileleri hard constraint olarak işaretlenir."},
        {"step": 5, "title": "Evidence channels", "detail": "Her kanonik kriter için coverage ratio, median global weight, median percentile, top/bottom support ve completeness hesaplanır."},
        {"step": 6, "title": "Composite score", "detail": "Robust importance = 0.35*norm_median_weight + 0.25*coverage + 0.20*median_percentile + 0.20*support_balance; sonra disagreement cezası ve completeness bonusu uygulanır."},
        {"step": 7, "title": "Phase adjustment", "detail": "İlk 72 saat profili için hız/kapsama/yedeklilik lehine, maliyet/uzun dönem kriterleri aleyhine küçük bağlam düzeltmeleri uygulanır."},
        {"step": 8, "title": "Final classification", "detail": "Kriterler CORE_SCORING, OPTIONAL_ADDON, MERGE_INTO_*, DROP_ACUTE, HARD_CONSTRAINT olarak etiketlenir."},
        {"step": 9, "title": "Balanced shortlist", "detail": "ACCESS/SERVICE/CAPACITY vb. grup kotaları ile dengeli çekirdek set seçilir; final_score'lar normalize edilerek nihai ağırlıklar elde edilir."},
    ]
    method_df = pd.DataFrame(method_rows)

    with pd.ExcelWriter(output_xlsx, engine="openpyxl") as writer:
        input_summary_df.to_excel(writer, sheet_name="Input_Summary", index=False)
        raw_occurrences.to_excel(writer, sheet_name="Observed_Raw", index=False)
        model_canonical.to_excel(writer, sheet_name="Observed_Canonical", index=False)
        canonical.to_excel(writer, sheet_name="Canonical_Aggregation", index=False)
        core_df.to_excel(writer, sheet_name="Final_Core_Weights", index=False)
        constraints_df.to_excel(writer, sheet_name="Hard_Constraints", index=False)
        optional_df.to_excel(writer, sheet_name="Optional_AddOns", index=False)
        merge_drop_df.to_excel(writer, sheet_name="Merge_and_Drop", index=False)
        group_weights.to_excel(writer, sheet_name="Main_Group_Weights", index=False)
        method_df.to_excel(writer, sheet_name="Method", index=False)

    wb = load_workbook(output_xlsx)
    header_fill = PatternFill(fill_type="solid", fgColor="D9EAF7")
    bold_font = Font(bold=True)

    for ws in wb.worksheets:
        ws.freeze_panes = "A2"
        for cell in ws[1]:
            cell.fill = header_fill
            cell.font = bold_font
            cell.alignment = Alignment(vertical="top", wrap_text=True)

        # auto width
        for col_idx, column_cells in enumerate(ws.columns, start=1):
            max_len = 0
            for cell in column_cells[:200]:
                try:
                    value = "" if cell.value is None else str(cell.value)
                except Exception:
                    value = ""
                max_len = max(max_len, len(value))
            ws.column_dimensions[get_column_letter(col_idx)].width = min(max(max_len + 2, 12), 45)

        # wrap all cells
        for row in ws.iter_rows():
            for cell in row:
                cell.alignment = Alignment(vertical="top", wrap_text=True)

    wb.save(output_xlsx)


def main() -> None:
    parser = argparse.ArgumentParser(description="Build final weighted MCDM criteria shortlist from JSON.")
    parser.add_argument("--input", required=True, help="Input JSON path")
    parser.add_argument("--output", required=True, help="Output Excel path")
    parser.add_argument("--core-min", type=int, default=10, help="Minimum number of core scoring criteria")
    parser.add_argument("--core-max", type=int, default=12, help="Maximum number of core scoring criteria")
    args = parser.parse_args()

    build_workbook(
        input_json=Path(args.input),
        output_xlsx=Path(args.output),
        target_min=args.core_min,
        target_max=args.core_max,
    )
    print(f"Excel written to {args.output}")


if __name__ == "__main__":
    main()
