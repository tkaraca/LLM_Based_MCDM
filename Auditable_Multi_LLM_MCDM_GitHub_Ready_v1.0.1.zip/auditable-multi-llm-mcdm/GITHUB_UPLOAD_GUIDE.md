# GitHub Upload Guide

## Recommended approach: GitHub Desktop

1. Extract `Auditable_Multi_LLM_MCDM_GitHub_Ready_v1.0.1.zip`.
2. Open GitHub Desktop and choose **Add an Existing Repository from your Hard Drive**.
3. Select the extracted `auditable-multi-llm-mcdm` folder.
4. If prompted, create a repository in this folder.
5. Commit all files and publish the repository.

## Command-line approach

From the extracted repository folder:

```bash
git init
git add .
git commit -m "Initial reproducibility release"
git branch -M main
git remote add origin <YOUR_GITHUB_REPOSITORY_URL>
git push -u origin main
```

## Browser upload approach

The GitHub-ready package is intentionally kept below 100 tracked files, and every individual file is far below the browser upload limit. Create an empty repository, extract the ZIP locally, and drag the repository contents into the GitHub upload page.

Important:

- Upload the extracted files, not only the outer ZIP.
- Keep the folder structure unchanged.
- Do not add generated `outputs/` or `figures/` after local runs unless you deliberately want to version them.
- The complete historical output tree is already available under `release_assets/reference_outputs_full.zip`.
- The outer release ZIP itself is best attached to a GitHub Release, not committed as the only repository file.

## Before making the repository public

- Select an explicit code licence.
- Verify redistribution permissions for the public-data extracts.
- Review `data/criterion/proposed_codebook_definition_completion.csv`.
- Replace provisional manuscript title or metadata if necessary.
- Run `python run_all.py` and confirm the validation report contains zero failures.
