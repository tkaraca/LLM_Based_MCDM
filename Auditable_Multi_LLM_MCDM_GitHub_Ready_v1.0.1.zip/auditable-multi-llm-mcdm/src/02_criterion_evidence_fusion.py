#!/usr/bin/env python3
"""Fuse source-level importance evidence after the criterion-family codebook is locked.

This implementation follows Section 3 of the manuscript:
* frozen researcher-approved raw-to-family mapping;
* within-source MAX rather than SUM for fragmented labels;
* missing importance remains unavailable, not zero;
* explicit coverage, rank, support, completeness, and disagreement channels;
* hard constraints outside compensatory scoring;
* quota-balanced selection with a declared secondary admissibility threshold.
"""
from __future__ import annotations

import argparse
import ast
import json
import math
from collections import Counter
from pathlib import Path
from statistics import median
from typing import Any

import numpy as np
import pandas as pd


def load_config(root: Path) -> dict[str, Any]:
    return json.loads((root / "config/study_config.json").read_text(encoding="utf-8"))


def quantile(values: list[float], q: float) -> float | None:
    vals = sorted(v for v in values if v is not None and pd.notna(v))
    if not vals:
        return None
    if len(vals) == 1:
        return vals[0]
    pos = (len(vals) - 1) * q
    lo, hi = int(math.floor(pos)), int(math.ceil(pos))
    if lo == hi:
        return vals[lo]
    return vals[lo] + (vals[hi] - vals[lo]) * (pos - lo)


def iqr(values: list[float]) -> float | None:
    vals = [v for v in values if v is not None and pd.notna(v)]
    if not vals:
        return None
    if len(vals) == 1:
        return 0.0
    q75, q25 = quantile(vals, 0.75), quantile(vals, 0.25)
    assert q75 is not None and q25 is not None
    return q75 - q25


def to_bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    return str(value).strip().lower() in {"true", "1", "yes"}


def save_csv(path: Path, frame: pd.DataFrame) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    frame.to_csv(path, index=False, encoding="utf-8-sig")


def within_source_max(records: pd.DataFrame, top_band: float, bottom_band: float) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    for (model_id, family_code), group in records.groupby(["model_id", "family_code"], dropna=False):
        numeric_weights = pd.to_numeric(group["global_weight"], errors="coerce")
        available = numeric_weights.dropna()
        if len(available):
            chosen_index = available.idxmax()
            representative = group.loc[chosen_index].to_dict()
            chosen_weight = float(available.max())
        else:
            representative = group.iloc[0].to_dict()
            chosen_weight = np.nan
        representative.update(
            {
                "source_codes_merged": json.dumps(sorted(group["source_code"].astype(str).tolist()), ensure_ascii=False),
                "source_names_merged": json.dumps(sorted(group["source_name"].astype(str).tolist()), ensure_ascii=False),
                "merged_raw_count": int(len(group)),
                "global_weight_model_family": chosen_weight,
                "any_approximate": bool(group["approximate"].map(to_bool).any()),
                "top_flag_model_family": int(pd.to_numeric(group["top_flag"], errors="coerce").fillna(0).max()),
                "bottom_flag_model_family": int(pd.to_numeric(group["bottom_flag"], errors="coerce").fillna(0).max()),
            }
        )
        rows.append(representative)
    collapsed = pd.DataFrame(rows)
    collapsed["family_rank_within_model"] = np.nan
    collapsed["family_percentile_within_model"] = np.nan
    for model_id, group in collapsed.groupby("model_id"):
        known = group[pd.to_numeric(group["global_weight_model_family"], errors="coerce").notna()].copy()
        known["_weight"] = pd.to_numeric(known["global_weight_model_family"], errors="coerce")
        known = known.sort_values("_weight", ascending=False)
        n = len(known)
        for rank, idx in enumerate(known.index, start=1):
            percentile = 1.0 if n == 1 else 1.0 - (rank - 1) / (n - 1)
            collapsed.at[idx, "family_rank_within_model"] = rank
            collapsed.at[idx, "family_percentile_within_model"] = percentile
            if collapsed.at[idx, "top_flag_model_family"] == 0 and percentile >= top_band:
                collapsed.at[idx, "top_flag_model_family"] = 1
            if collapsed.at[idx, "bottom_flag_model_family"] == 0 and percentile <= bottom_band:
                collapsed.at[idx, "bottom_flag_model_family"] = 1
    return collapsed


def aggregate_families(collapsed: pd.DataFrame, codebook: pd.DataFrame, cfg: dict[str, Any]) -> pd.DataFrame:
    total_sources = collapsed["model_id"].nunique()
    codebook_index = codebook.set_index("family_code")
    rows: list[dict[str, Any]] = []
    for family_code, group in collapsed.groupby("family_code"):
        weights = pd.to_numeric(group["global_weight_model_family"], errors="coerce").dropna().tolist()
        percentiles = pd.to_numeric(group["family_percentile_within_model"], errors="coerce").dropna().tolist()
        cb = codebook_index.loc[family_code]
        aliases: list[str] = []
        for value in group["source_names_merged"]:
            aliases.extend(json.loads(value))
        rows.append(
            {
                "family_code": family_code,
                "family_name": cb["family_name"],
                "macro_group": cb["macro_dimension"],
                "hard_constraint": to_bool(cb["hard_constraint"]),
                "models_present": int(group["model_id"].nunique()),
                "coverage_ratio": float(group["model_id"].nunique() / total_sources),
                "known_weight_count": int(len(weights)),
                "median_global_weight": float(median(weights)) if weights else np.nan,
                "median_percentile": float(median(percentiles)) if percentiles else np.nan,
                "iqr_global_weight": iqr(weights),
                "iqr_percentile": iqr(percentiles),
                "top_support_ratio": float(group["top_flag_model_family"].mean()),
                "bottom_support_ratio": float(group["bottom_flag_model_family"].mean()),
                "completeness_ratio": float(pd.to_numeric(group["global_weight_model_family"], errors="coerce").notna().mean()),
                "approx_ratio": float(group["any_approximate"].map(to_bool).mean()),
                "aliases": json.dumps(sorted(set(aliases)), ensure_ascii=False),
                "model_labels_present": json.dumps(sorted(group["model_label"].astype(str).unique().tolist()), ensure_ascii=False),
                "merged_member_total": int(pd.to_numeric(group["merged_raw_count"]).sum()),
                "merge_target": "" if pd.isna(cb.get("merge_target", "")) else str(cb.get("merge_target", "")),
            }
        )
    result = pd.DataFrame(rows)
    max_median = result["median_global_weight"].max(skipna=True)
    result["norm_median_global_weight"] = result["median_global_weight"] / max_median
    result["support_balance"] = (
        1 + result["top_support_ratio"].fillna(0) - result["bottom_support_ratio"].fillna(0)
    ) / 2
    result["median_percentile_filled"] = result["median_percentile"].fillna(0.5)
    coefficients = cfg["coefficients"]
    result["robust_importance"] = (
        float(coefficients["normalized_median_importance"]) * result["norm_median_global_weight"].fillna(0)
        + float(coefficients["coverage"]) * result["coverage_ratio"].fillna(0)
        + float(coefficients["median_percentile"]) * result["median_percentile_filled"]
        + float(coefficients["support_balance"]) * result["support_balance"].fillna(0.5)
    )
    result["disagreement_measure"] = result["iqr_percentile"]
    max_weight_iqr = result["iqr_global_weight"].max(skipna=True)
    missing = result["disagreement_measure"].isna()
    if pd.notna(max_weight_iqr) and max_weight_iqr > 0:
        result.loc[missing, "disagreement_measure"] = (
            result.loc[missing, "iqr_global_weight"].fillna(0) / max_weight_iqr
        )
    result["disagreement_measure"] = result["disagreement_measure"].fillna(0).clip(0, 1)
    result["evidence_score"] = (
        result["robust_importance"]
        - float(cfg["disagreement_penalty"]) * result["disagreement_measure"]
        + float(cfg["completeness_bonus"]) * result["completeness_ratio"].fillna(0)
    ).clip(0, 1)
    adjustments = cfg["phase_adjustments"]
    result["phase_adjustment"] = result["family_code"].map(adjustments).fillna(0.0)
    result["final_score"] = (result["evidence_score"] + result["phase_adjustment"]).clip(0, 1)

    preliminary: list[str] = []
    for _, row in result.iterrows():
        if row["hard_constraint"]:
            preliminary.append("HARD_CONSTRAINT")
        elif str(row["merge_target"]).strip():
            preliminary.append(f"MERGE_CANDIDATE->{row['merge_target']}")
        elif (
            row["final_score"] >= float(cfg["primary_evidence_threshold"])
            and row["coverage_ratio"] >= float(cfg["primary_coverage_threshold"])
        ):
            preliminary.append("CORE_CANDIDATE")
        elif row["final_score"] >= float(cfg["optional_threshold"]):
            preliminary.append("OPTIONAL_CANDIDATE")
        else:
            preliminary.append("DROP_CANDIDATE")
    result["preliminary_decision"] = preliminary
    return result.sort_values(["hard_constraint", "final_score"], ascending=[False, False]).reset_index(drop=True)


def select_shortlist(families: pd.DataFrame, cfg: dict[str, Any]) -> tuple[pd.DataFrame, pd.DataFrame]:
    df = families.sort_values("final_score", ascending=False).copy().reset_index(drop=True)
    df["final_decision"] = df["preliminary_decision"]
    df["merge_target"] = df["merge_target"].fillna("").astype(str)
    merge_codes = set(df.loc[df["merge_target"].str.strip() != "", "family_code"])
    pool = df[(~df["hard_constraint"]) & (~df["family_code"].isin(merge_codes))].copy()
    selected: list[str] = []
    counts: Counter[str] = Counter()
    audit: list[dict[str, Any]] = []
    max_total = int(cfg["target_core_max"])
    min_total = int(cfg["target_core_min"])
    quotas = cfg["group_quotas"]

    # Pass 1: primary thresholds.
    for _, row in pool.sort_values("final_score", ascending=False).iterrows():
        if row["preliminary_decision"] != "CORE_CANDIDATE" or len(selected) >= max_total:
            continue
        group = row["macro_group"]
        if counts[group] >= int(quotas.get(group, {}).get("max", 999)):
            continue
        selected.append(row["family_code"]); counts[group] += 1
        audit.append({"pass":1,"family_code":row["family_code"],"reason":"primary evidence and coverage thresholds"})

    # Pass 2: quota completion with the declared secondary threshold and coverage floor.
    secondary = float(cfg["secondary_backfill_threshold"])
    coverage_floor = float(cfg["primary_coverage_threshold"])
    for group, quota in quotas.items():
        while counts[group] < int(quota.get("min", 0)) and len(selected) < max_total:
            candidates = pool[
                (pool["macro_group"] == group)
                & (~pool["family_code"].isin(selected))
                & (pool["final_score"] >= secondary)
                & (pool["coverage_ratio"] >= coverage_floor)
            ].sort_values("final_score", ascending=False)
            if candidates.empty:
                audit.append({"pass":2,"family_code":"","reason":f"quota shortfall for {group}: no admissible family"})
                break
            row = candidates.iloc[0]
            selected.append(row["family_code"]); counts[group] += 1
            audit.append({"pass":2,"family_code":row["family_code"],"reason":f"minimum {group} quota backfill"})

    # Pass 3: shortlist-size completion under the same secondary admissibility rule.
    remaining = pool[
        (~pool["family_code"].isin(selected))
        & (pool["final_score"] >= secondary)
        & (pool["coverage_ratio"] >= coverage_floor)
    ].copy()
    remaining["priority_tier"] = (remaining["preliminary_decision"] != "CORE_CANDIDATE").astype(int)
    remaining = remaining.sort_values(["priority_tier", "final_score"], ascending=[True, False])
    for _, row in remaining.iterrows():
        if len(selected) >= min_total:
            break
        group = row["macro_group"]
        if counts[group] >= int(quotas.get(group, {}).get("max", 999)):
            continue
        selected.append(row["family_code"]); counts[group] += 1
        audit.append({"pass":3,"family_code":row["family_code"],"reason":"minimum shortlist-size backfill"})

    optional_preferred = set(cfg["optional_preferred"])
    for idx, row in df.iterrows():
        code = row["family_code"]
        if row["hard_constraint"]:
            decision = "HARD_CONSTRAINT"
        elif code in selected:
            decision = "CORE_SCORING"
        elif code in merge_codes:
            decision = f"MERGE_INTO_{row['merge_target']}"
        elif row["final_score"] >= float(cfg["optional_threshold"]) or (
            code in optional_preferred and row["final_score"] >= 0.40
        ):
            decision = "OPTIONAL_ADDON"
        else:
            decision = "DROP_ACUTE"
        df.at[idx, "final_decision"] = decision

    core = df[df["final_decision"] == "CORE_SCORING"].copy().sort_values("final_score", ascending=False)
    total = core["final_score"].sum()
    core["conceptual_weight"] = core["final_score"] / total
    weight_map = dict(zip(core["family_code"], core["conceptual_weight"]))
    df["conceptual_weight"] = df["family_code"].map(weight_map)
    return df, pd.DataFrame(audit)


def main(root: Path) -> None:
    cfg = load_config(root)["evidence_fusion"]
    out = root / "outputs/02_evidence_fusion"
    out.mkdir(parents=True, exist_ok=True)
    corpus = pd.read_csv(root / "data/criterion/criterion_corpus.csv", encoding="utf-8-sig")
    mapping = pd.read_csv(root / "data/criterion/raw_to_family_mapping.csv", encoding="utf-8-sig")
    codebook = pd.read_csv(root / "data/criterion/approved_family_codebook.csv", encoding="utf-8-sig")
    records = corpus.merge(mapping, on=["raw_id", "model_id", "source_code"], validate="one_to_one")
    records = records.rename(
        columns={
            "approved_family_code": "family_code",
            "approved_family_name": "family_name",
            "hard_constraint": "hard_constraint_from_mapping",
        }
    )
    for column in ["global_weight", "local_weight", "top_flag", "bottom_flag"]:
        records[column] = pd.to_numeric(records[column], errors="coerce")
    collapsed = within_source_max(records, float(cfg["top_band"]), float(cfg["bottom_band"]))
    families = aggregate_families(collapsed, codebook, cfg)
    final, audit = select_shortlist(families, cfg)

    save_csv(out / "source_family_records.csv", collapsed)
    save_csv(out / "family_evidence_channels.csv", final)
    save_csv(out / "selection_audit.csv", audit)
    save_csv(out / "conceptual_core_weights.csv", final[final["final_decision"] == "CORE_SCORING"].sort_values("conceptual_weight", ascending=False))
    save_csv(out / "optional_families.csv", final[final["final_decision"] == "OPTIONAL_ADDON"])
    save_csv(out / "hard_constraints.csv", final[final["final_decision"] == "HARD_CONSTRAINT"])
    save_csv(out / "merge_and_drop.csv", final[final["final_decision"].str.startswith("MERGE_INTO_") | (final["final_decision"] == "DROP_ACUTE")])
    summary = {
        "sources": int(records["model_id"].nunique()),
        "raw_criteria": int(len(records)),
        "approved_families": int(final["family_code"].nunique()),
        "core": int((final["final_decision"] == "CORE_SCORING").sum()),
        "optional": int((final["final_decision"] == "OPTIONAL_ADDON").sum()),
        "hard_constraints": int((final["final_decision"] == "HARD_CONSTRAINT").sum()),
        "merge_or_drop": int(final["final_decision"].str.startswith("MERGE_INTO_").sum() + (final["final_decision"] == "DROP_ACUTE").sum()),
        "within_source_aggregation": "MAX(global_weight), never SUM",
        "missing_weight_policy": "unavailable, not zero",
        "secondary_backfill": {
            "evidence_threshold": cfg["secondary_backfill_threshold"],
            "coverage_threshold": cfg["primary_coverage_threshold"],
        },
    }
    (out / "evidence_fusion_summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[1])
    args = parser.parse_args()
    main(args.root.resolve())
