"""Shared deterministic MCDM functions used by the reproducibility package."""
from __future__ import annotations

import math
from typing import Mapping

import numpy as np
import pandas as pd


def minmax(series: pd.Series, higher_better: bool = True) -> pd.Series:
    values = pd.to_numeric(series, errors="coerce").astype(float)
    lo, hi = values.min(), values.max()
    if not math.isfinite(lo) or not math.isfinite(hi) or abs(hi - lo) < 1e-12:
        out = pd.Series(1.0, index=values.index, dtype=float)
    else:
        out = (values - lo) / (hi - lo)
    return out if higher_better else 1.0 - out


def derive_thresholds(utilities: pd.DataFrame) -> pd.DataFrame:
    rows: list[dict[str, float | str]] = []
    for criterion in utilities.columns:
        x = utilities[criterion].to_numpy(float)
        differences = [
            abs(x[i] - x[j])
            for i in range(len(x))
            for j in range(i + 1, len(x))
            if abs(x[i] - x[j]) > 1e-12
        ]
        if len(differences) >= 4:
            q = float(np.quantile(differences, 0.25))
            p = float(np.quantile(differences, 0.75))
        elif differences:
            q, p = float(min(differences)), float(max(differences))
        else:
            q, p = 0.02, 0.20
        q = max(0.0, min(q, 0.45))
        p = max(q + 0.05, min(p, 1.0))
        rows.append(
            {
                "criterion": criterion,
                "q": q,
                "p": p,
                "rule": "Q25/Q75 of non-zero pairwise utility differences",
            }
        )
    return pd.DataFrame(rows)


def linear_preference(difference: float, q: float, p: float) -> float:
    if difference <= q:
        return 0.0
    if difference >= p:
        return 1.0
    return (difference - q) / (p - q)


def promethee_ii(
    utilities: pd.DataFrame,
    weights: Mapping[str, float],
    thresholds: pd.DataFrame,
) -> pd.DataFrame:
    criteria = list(weights)
    missing = set(criteria) - set(utilities.columns)
    if missing:
        raise ValueError(f"Utility matrix is missing criteria: {sorted(missing)}")
    w = np.array([weights[c] for c in criteria], dtype=float)
    if not np.isfinite(w).all() or w.sum() <= 0:
        raise ValueError("Weights must be finite and have a positive sum.")
    w /= w.sum()
    q = thresholds.set_index("criterion")["q"].astype(float).to_dict()
    p = thresholds.set_index("criterion")["p"].astype(float).to_dict()
    if set(criteria) - set(q):
        raise ValueError("Threshold table does not cover every criterion.")

    arr = utilities[criteria].to_numpy(float)
    if np.isnan(arr).any():
        raise ValueError("PROMETHEE II does not accept missing utilities in the primary matrix.")
    n = len(arr)

    # Vectorised pairwise preference calculation. This is algebraically identical to
    # the scalar nested-loop implementation but is substantially faster during the
    # 5,000-run Monte Carlo analysis. Pairwise differences have shape (n, n, m),
    # where m is the number of criteria.
    differences = arr[:, None, :] - arr[None, :, :]
    q_arr = np.array([q[c] for c in criteria], dtype=float)[None, None, :]
    p_arr = np.array([p[c] for c in criteria], dtype=float)[None, None, :]
    preferences = np.where(
        differences <= q_arr,
        0.0,
        np.where(
            differences >= p_arr,
            1.0,
            (differences - q_arr) / (p_arr - q_arr),
        ),
    )
    pi = np.tensordot(preferences, w, axes=([2], [0]))
    np.fill_diagonal(pi, 0.0)
    phi_plus = pi.sum(axis=1) / (n - 1)
    phi_minus = pi.sum(axis=0) / (n - 1)
    phi_net = phi_plus - phi_minus
    out = pd.DataFrame(
        {"phi_plus": phi_plus, "phi_minus": phi_minus, "phi_net": phi_net},
        index=utilities.index,
    )
    out["PROMETHEE_rank"] = out["phi_net"].rank(ascending=False, method="min").astype(int)
    return out.sort_values(["PROMETHEE_rank", "phi_net"], ascending=[True, False])


def topsis(utilities: pd.DataFrame, weights: Mapping[str, float]) -> pd.DataFrame:
    criteria = list(weights)
    x = utilities[criteria].to_numpy(float)
    denominator = np.sqrt((x**2).sum(axis=0))
    denominator[denominator == 0] = 1.0
    normalized = x / denominator
    w = np.array([weights[c] for c in criteria], dtype=float)
    w /= w.sum()
    weighted = normalized * w
    ideal = weighted.max(axis=0)
    nadir = weighted.min(axis=0)
    d_plus = np.sqrt(((weighted - ideal) ** 2).sum(axis=1))
    d_minus = np.sqrt(((weighted - nadir) ** 2).sum(axis=1))
    score = d_minus / np.maximum(d_plus + d_minus, 1e-12)
    out = pd.DataFrame({"TOPSIS_score": score}, index=utilities.index)
    out["TOPSIS_rank"] = out["TOPSIS_score"].rank(ascending=False, method="min").astype(int)
    return out.sort_values(["TOPSIS_rank", "TOPSIS_score"], ascending=[True, False])


def vikor(
    utilities: pd.DataFrame,
    weights: Mapping[str, float],
    compromise_v: float = 0.5,
) -> pd.DataFrame:
    criteria = list(weights)
    x = utilities[criteria].to_numpy(float)
    w = np.array([weights[c] for c in criteria], dtype=float)
    w /= w.sum()
    regret = w * (1.0 - x)
    s = regret.sum(axis=1)
    r = regret.max(axis=1)
    s_norm = (s - s.min()) / max(s.max() - s.min(), 1e-12)
    r_norm = (r - r.min()) / max(r.max() - r.min(), 1e-12)
    q = compromise_v * s_norm + (1.0 - compromise_v) * r_norm
    out = pd.DataFrame({"VIKOR_S": s, "VIKOR_R": r, "VIKOR_Q": q}, index=utilities.index)
    out["VIKOR_rank"] = out["VIKOR_Q"].rank(ascending=True, method="min").astype(int)
    return out.sort_values(["VIKOR_rank", "VIKOR_Q"], ascending=[True, True])


def spearman_rank_correlation(a: pd.Series, b: pd.Series) -> float:
    return float(pd.to_numeric(a).corr(pd.to_numeric(b), method="spearman"))
