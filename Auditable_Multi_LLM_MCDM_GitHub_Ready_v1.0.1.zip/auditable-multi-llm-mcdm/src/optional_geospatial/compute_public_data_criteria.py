#!/usr/bin/env python3
"""Compute the reproducible public-data criteria for the Istanbul European Side study.

The script intentionally does not impute missing facility areas and does not produce a
final PROMETHEE II ranking when the primary data matrix is incomplete. It uses:
  - a frozen OSM-derived driving graph,
  - a candidate registry,
  - a population reference table,
  - official IBB district social-vulnerability scores,
  - a pre-registered strategic-gateway table,
  - public facility/site-area evidence.

Outputs: D1, D2 (30/45/60 min), D3 (30/45/60 min), D4 sensitivity metric,
D5 OSM route-redundancy proxy, D6 gateway time, D7 last-mile HGV proxy,
and partial D8 site-area utility.
The manuscript-aligned primary/sensitivity utilities use the 30-minute D2/D3 variants;
45- and 60-minute values are retained only as additional diagnostic outputs.
"""
from __future__ import annotations

import argparse
import ast
import gzip
import json
import math
import shutil
from pathlib import Path
from typing import Any, List, Tuple

import networkx as nx
import numpy as np
import pandas as pd
from scipy.spatial import cKDTree

ROAD_SCORES = {
    "motorway": 1.00, "motorway_link": 0.95,
    "trunk": 0.95, "trunk_link": 0.90,
    "primary": 0.88, "primary_link": 0.84,
    "secondary": 0.76, "secondary_link": 0.72,
    "tertiary": 0.64, "tertiary_link": 0.60,
    "unclassified": 0.50, "residential": 0.40,
    "living_street": 0.25, "service": 0.20,
}
MAJOR_CLASSES = {
    "motorway", "motorway_link", "trunk", "trunk_link",
    "primary", "primary_link", "secondary", "secondary_link",
}


def as_float(value: Any, default: float = math.nan) -> float:
    if value is None:
        return default
    try:
        if isinstance(value, (int, float, np.number)):
            return float(value)
        text = str(value).strip()
        if not text:
            return default
        if text.startswith("["):
            values = ast.literal_eval(text)
            values = [as_float(v, math.nan) for v in values]
            values = [v for v in values if math.isfinite(v)]
            return max(values) if values else default
        return float(text.replace(",", "."))
    except Exception:
        return default


def as_items(value: Any) -> List[str]:
    if value is None:
        return []
    if isinstance(value, (list, tuple, set)):
        return [str(v) for v in value]
    text = str(value).strip()
    if not text:
        return []
    if text.startswith("[") and text.endswith("]"):
        try:
            return [str(v) for v in ast.literal_eval(text)]
        except Exception:
            pass
    return [text]


def highway_values(value: Any) -> List[str]:
    return [v for v in as_items(value) if v]


def road_score(value: Any) -> float:
    values = highway_values(value)
    if not values:
        return 0.30
    return max(ROAD_SCORES.get(v, 0.30) for v in values)


def is_major(value: Any) -> bool:
    return any(v in MAJOR_CLASSES for v in highway_values(value))


def lanes_score(value: Any) -> float:
    values = as_items(value)
    nums = []
    for value in values:
        try:
            nums.append(float(str(value).split(";")[0]))
        except Exception:
            continue
    if not nums:
        return 0.40
    return min(max(nums) / 4.0, 1.0)


def access_score(value: Any) -> float:
    values = {v.lower() for v in as_items(value)}
    if not values:
        return 1.0
    if values & {"no", "private"}:
        return 0.0
    if values & {"destination", "customers", "delivery"}:
        return 0.55
    return 0.85


def minmax(series: pd.Series, higher_better: bool = True) -> pd.Series:
    s = pd.to_numeric(series, errors="coerce").astype(float)
    lo, hi = s.min(), s.max()
    if not math.isfinite(lo) or not math.isfinite(hi) or abs(hi - lo) < 1e-12:
        out = pd.Series(np.nan, index=s.index, dtype=float)
        out[s.notna()] = 1.0
        return out
    out = (s - lo) / (hi - lo)
    return out if higher_better else 1.0 - out


def ensure_graph(root: Path) -> Path:
    raw = root / "data_raw" / "osm"
    graph = raw / "istanbul_europe_drive_2026-07-10.graphml.xml"
    zipped = raw / "istanbul_europe_drive_2026-07-10.graphml.xml.gz"
    if graph.exists():
        return graph
    if not zipped.exists():
        raise FileNotFoundError(
            f"Neither {graph} nor {zipped} exists. Run download_public_data.py or restore the frozen snapshot."
        )
    with gzip.open(zipped, "rb") as source, graph.open("wb") as target:
        shutil.copyfileobj(source, target)
    return graph


def load_inputs(root: Path):
    processed = root / "data_processed"
    required = {
        "candidates": processed / "candidate_registry.csv",
        "population": processed / "district_population_reference_2025_provisional.csv",
        "svi": processed / "district_social_vulnerability_ibb_2018.csv",
        "areas": processed / "facility_site_area_public.csv",
        "gateways": processed / "strategic_gateway_registry.csv",
    }
    missing = [str(path) for path in required.values() if not path.exists()]
    if missing:
        raise FileNotFoundError("Missing required inputs:\n" + "\n".join(missing))
    return (
        pd.read_csv(required["candidates"], encoding="utf-8-sig"),
        pd.read_csv(required["population"], encoding="utf-8-sig"),
        pd.read_csv(required["svi"], encoding="utf-8-sig"),
        pd.read_csv(required["areas"], encoding="utf-8-sig"),
        pd.read_csv(required["gateways"], encoding="utf-8-sig"),
    )


def build_graphs(graph_path: Path):
    print(f"Loading GraphML: {graph_path}")
    gm = nx.read_graphml(graph_path)
    directed = nx.DiGraph()
    undirected = nx.Graph()
    for node, data in gm.nodes(data=True):
        directed.add_node(node, **data)
        undirected.add_node(node, **data)
    for u, v, key, data in gm.edges(keys=True, data=True):
        travel_time = as_float(data.get("travel_time"))
        length = as_float(data.get("length"))
        if not math.isfinite(length):
            continue
        if not math.isfinite(travel_time) or travel_time <= 0:
            speed = as_float(data.get("speed_kph"), 30.0)
            travel_time = length / max(speed, 5.0) * 3.6
        attrs = dict(data)
        attrs["travel_time"] = float(travel_time)
        attrs["length"] = float(length)
        if not directed.has_edge(u, v) or travel_time < directed[u][v]["travel_time"]:
            directed.add_edge(u, v, **attrs)
        if not undirected.has_edge(u, v) or length < undirected[u][v]["length"]:
            undirected.add_edge(u, v, **attrs)
    largest_scc = max(nx.strongly_connected_components(directed), key=len)
    node_ids = list(largest_scc)
    xy = np.array([
        [as_float(directed.nodes[n].get("x")), as_float(directed.nodes[n].get("y"))]
        for n in node_ids
    ])
    return gm, directed, undirected, node_ids, cKDTree(xy)


def compute(root: Path) -> None:
    processed = root / "data_processed"
    outputs = root / "outputs"
    outputs.mkdir(parents=True, exist_ok=True)
    graph_path = ensure_graph(root)
    candidates, population, svi, areas, gateways = load_inputs(root)

    population = population.merge(
        svi[["district", "social_vulnerability_score_2018"]],
        left_on="demand_name", right_on="district", how="left",
    ).drop(columns=["district"])
    population["vulnerability_weight"] = (
        population["population_2025"] * population["social_vulnerability_score_2018"] / 100.0
    )

    graph_meta, gd, gu, node_ids, tree = build_graphs(graph_path)

    def nearest_node(lon: float, lat: float) -> Tuple[str, float]:
        distance, idx = tree.query([lon, lat], k=1)
        return node_ids[int(idx)], float(distance)

    candidate_nodes = []
    for _, row in candidates.iterrows():
        node, distance = nearest_node(float(row["lon"]), float(row["lat"]))
        candidate_nodes.append((row["alternative_id"], node, distance))
    candidate_nodes_df = pd.DataFrame(
        candidate_nodes,
        columns=["alternative_id", "osm_node", "nearest_node_degree_distance"],
    )
    candidate_nodes_df.to_csv(processed / "candidate_osm_nodes.csv", index=False, encoding="utf-8-sig")

    demand_nodes = []
    for _, row in population.iterrows():
        node, distance = nearest_node(float(row["lon"]), float(row["lat"]))
        demand_nodes.append((row["demand_id"], node, distance))
    demand_nodes_df = pd.DataFrame(
        demand_nodes,
        columns=["demand_id", "osm_node", "nearest_node_degree_distance"],
    )
    demand_nodes_df.to_csv(processed / "demand_osm_nodes.csv", index=False, encoding="utf-8-sig")

    candidate_node_map = dict(zip(candidate_nodes_df.alternative_id, candidate_nodes_df.osm_node))
    demand_node_map = dict(zip(demand_nodes_df.demand_id, demand_nodes_df.osm_node))

    travel_rows = []
    metric_rows = []
    for _, candidate in candidates.iterrows():
        alternative_id = candidate["alternative_id"]
        lengths = nx.single_source_dijkstra_path_length(
            gd, candidate_node_map[alternative_id], weight="travel_time", cutoff=4 * 3600
        )
        times = []
        for _, demand in population.iterrows():
            seconds = lengths.get(demand_node_map[demand["demand_id"]], math.nan)
            minutes = seconds / 60.0 if math.isfinite(seconds) else math.nan
            times.append(minutes)
            travel_rows.append({
                "alternative_id": alternative_id,
                "demand_id": demand["demand_id"],
                "demand_name": demand["demand_name"],
                "travel_time_min": minutes,
                "population_2025": demand["population_2025"],
                "social_vulnerability_score_2018": demand["social_vulnerability_score_2018"],
                "vulnerability_weight": demand["vulnerability_weight"],
            })
        travel = np.array(times, dtype=float)
        pop = population["population_2025"].to_numpy(dtype=float)
        vuln = population["vulnerability_weight"].to_numpy(dtype=float)
        valid = np.isfinite(travel)
        row = {
            "alternative_id": alternative_id,
            "D1_population_weighted_travel_time_min": float(np.sum(pop[valid] * travel[valid]) / np.sum(pop[valid])),
            "D4_gravity_population_accessibility": float(np.sum(pop[valid] / (1.0 + travel[valid]))),
        }
        for threshold in (30, 45, 60):
            row[f"D2_population_coverage_{threshold}min"] = float(
                np.sum(pop[valid & (travel <= threshold)]) / np.sum(pop[valid])
            )
            row[f"D3_svi_weighted_coverage_{threshold}min"] = float(
                np.sum(vuln[valid & (travel <= threshold)]) / np.sum(vuln[valid])
            )
        metric_rows.append(row)

    travel_df = pd.DataFrame(travel_rows)
    travel_df.to_csv(outputs / "travel_time_matrix_district_centres.csv", index=False, encoding="utf-8-sig")
    metrics = pd.DataFrame(metric_rows)

    primary_gateways = gateways[gateways["include_in_primary"].astype(bool)]
    gateway_nodes = {
        row.gateway_id: nearest_node(float(row.lon), float(row.lat))[0]
        for _, row in primary_gateways.iterrows()
    }
    d6_rows = []
    for alternative_id, source in candidate_node_map.items():
        lengths = nx.single_source_dijkstra_path_length(gd, source, weight="travel_time", cutoff=4 * 3600)
        values = []
        for gateway_id, gateway_node in gateway_nodes.items():
            seconds = lengths.get(gateway_node, math.nan)
            if math.isfinite(seconds):
                values.append((seconds / 60.0, gateway_id))
        if values:
            best = min(values)
            d6_rows.append({"alternative_id": alternative_id, "D6_nearest_gateway_time_min": best[0], "D6_nearest_gateway_id": best[1]})
        else:
            d6_rows.append({"alternative_id": alternative_id, "D6_nearest_gateway_time_min": math.nan, "D6_nearest_gateway_id": None})
    metrics = metrics.merge(pd.DataFrame(d6_rows), on="alternative_id", how="left")

    redundancy_rows = []
    for alternative_id, source in candidate_node_map.items():
        distances = nx.single_source_dijkstra_path_length(gu, source, weight="length", cutoff=2000)
        nodes = set(distances.keys())
        subgraph = gu.subgraph(nodes)
        n_nodes = subgraph.number_of_nodes()
        n_edges = subgraph.number_of_edges()
        components = nx.number_connected_components(subgraph) if n_nodes else 0
        avg_degree = float(np.mean([degree for _, degree in subgraph.degree()])) if n_nodes else 0.0
        cycle_density = max(n_edges - n_nodes + components, 0) / max(n_nodes, 1)
        boundary_exits = 0
        major_refs = set()
        for u in nodes:
            for v, data in gu[u].items():
                if v not in nodes:
                    boundary_exits += 1
                if is_major(data.get("highway")):
                    refs = as_items(data.get("ref")) or as_items(data.get("name"))
                    if refs:
                        major_refs.update(refs)
                    else:
                        major_refs.add(f"{u}-{v}")
        redundancy_rows.append({
            "alternative_id": alternative_id,
            "D5_local_avg_degree": avg_degree,
            "D5_cycle_density": cycle_density,
            "D5_boundary_exit_count": boundary_exits,
            "D5_major_road_diversity": len(major_refs),
            "D5_local_nodes_2km": n_nodes,
        })
    redundancy = pd.DataFrame(redundancy_rows)
    for column in ["D5_local_avg_degree", "D5_cycle_density", "D5_boundary_exit_count", "D5_major_road_diversity"]:
        redundancy[f"{column}_u"] = minmax(redundancy[column], True)
    redundancy["D5_osm_route_redundancy_index"] = (
        0.25 * redundancy["D5_local_avg_degree_u"]
        + 0.30 * redundancy["D5_cycle_density_u"]
        + 0.25 * redundancy["D5_boundary_exit_count_u"]
        + 0.20 * redundancy["D5_major_road_diversity_u"]
    )
    metrics = metrics.merge(redundancy, on="alternative_id", how="left")

    major_nodes = set()
    for u, v, data in gu.edges(data=True):
        if is_major(data.get("highway")):
            major_nodes.add(u)
            major_nodes.add(v)

    last_mile_rows = []
    for alternative_id, source in candidate_node_map.items():
        distances = nx.single_source_dijkstra_path_length(gu, source, weight="length", cutoff=5000)
        available = [(distance, node) for node, distance in distances.items() if node in major_nodes]
        if available:
            major_distance, target = min(available)
            path = nx.shortest_path(gu, source, target, weight="length")
        else:
            major_distance, path = 5000.0, [source]
        edges = [gu[u][v] for u, v in zip(path[:-1], path[1:])]
        if edges:
            cls = float(np.mean([road_score(edge.get("highway")) for edge in edges]))
            lanes = float(np.mean([lanes_score(edge.get("lanes")) for edge in edges]))
            access = float(np.mean([access_score(edge.get("access")) for edge in edges]))
            edge_count = len(edges)
        else:
            incident = [data for _, _, data in gu.edges(source, data=True)]
            cls = max([road_score(edge.get("highway")) for edge in incident], default=0.3)
            lanes = max([lanes_score(edge.get("lanes")) for edge in incident], default=0.4)
            access = min([access_score(edge.get("access")) for edge in incident], default=1.0)
            edge_count = 0
        distance_utility = 1.0 - min(major_distance / 3000.0, 1.0)
        turns_per_km = edge_count / max(major_distance / 1000.0, 0.25)
        simplicity = 1.0 / (1.0 + turns_per_km / 8.0)
        raw = 0.35 * cls + 0.25 * distance_utility + 0.15 * lanes + 0.15 * access + 0.10 * simplicity
        last_mile_rows.append({
            "alternative_id": alternative_id,
            "D7_distance_to_major_road_m": major_distance,
            "D7_mean_road_class_score": cls,
            "D7_mean_lanes_score": lanes,
            "D7_access_score": access,
            "D7_path_edge_count": edge_count,
            "D7_path_simplicity_score": simplicity,
            "D7_osm_last_mile_hgv_proxy": raw,
        })
    metrics = metrics.merge(pd.DataFrame(last_mile_rows), on="alternative_id", how="left")

    metrics = metrics.merge(areas, on="alternative_id", how="left")
    metrics["D8_log_site_area"] = np.log1p(metrics["site_area_proxy_m2"])
    metrics["D8_site_area_utility"] = np.nan
    mask = metrics["D8_log_site_area"].notna()
    metrics.loc[mask, "D8_site_area_utility"] = minmax(metrics.loc[mask, "D8_log_site_area"], True)
    metrics = candidates[["alternative_id", "refined_name", "district", "facility_type", "lat", "lon", "analysis_status"]].merge(
        metrics, on="alternative_id", how="left"
    )
    metrics.to_csv(outputs / "public_data_criteria_partial.csv", index=False, encoding="utf-8-sig")

    utility = metrics[["alternative_id", "refined_name", "analysis_status"]].copy()
    utility["D1_u"] = minmax(metrics["D1_population_weighted_travel_time_min"], False)
    utility["D2_u"] = minmax(metrics["D2_population_coverage_30min"], True)
    utility["D3_u"] = minmax(metrics["D3_svi_weighted_coverage_30min"], True)
    utility["D5_u"] = metrics["D5_osm_route_redundancy_index"]
    utility["D6_u"] = minmax(metrics["D6_nearest_gateway_time_min"], False)
    utility["D7_u"] = metrics["D7_osm_last_mile_hgv_proxy"]
    utility["D8_u"] = metrics["D8_site_area_utility"]
    utility.to_csv(outputs / "public_data_utility_matrix_partial.csv", index=False, encoding="utf-8-sig")

    completeness_rows = []
    primary_columns = ["D1_u", "D2_u", "D3_u", "D5_u", "D6_u", "D7_u", "D8_u"]
    for _, row in utility.iterrows():
        available = [column for column in primary_columns if pd.notna(row[column])]
        missing = [column.replace("_u", "") for column in primary_columns if pd.isna(row[column])]
        completeness_rows.append({
            "alternative_id": row["alternative_id"],
            "refined_name": row["refined_name"],
            "analysis_status": row["analysis_status"],
            "available_criteria_count": len(available),
            "total_primary_criteria": len(primary_columns),
            "completeness_ratio": len(available) / len(primary_columns),
            "missing_criteria": ";".join(missing),
            "ready_for_full_primary_model": len(missing) == 0 and row["analysis_status"] == "INCLUDE_CONDITIONAL",
        })
    completeness = pd.DataFrame(completeness_rows)
    completeness.to_csv(outputs / "data_completeness_report.csv", index=False, encoding="utf-8-sig")

    summary = {
        "graph": dict(graph_meta.graph),
        "candidate_count": int(len(candidates)),
        "primary_included_candidates": int((candidates["analysis_status"] == "INCLUDE_CONDITIONAL").sum()),
        "demand_point_count": int(len(population)),
        "criteria_computed": ["D1", "D2_30", "D2_45", "D2_60", "D3_30", "D3_45", "D3_60", "D4", "D5", "D6", "D7", "D8_partial"],
        "final_ranking_produced": False,
        "ranking_blockers": [
            "Official TÜİK export not yet archived",
            "D8 missing for some candidates",
            "Candidate service-gate coordinates provisional",
            "Hard constraints not verified",
        ],
    }
    with (outputs / "phase2_status.json").open("w", encoding="utf-8") as handle:
        json.dump(summary, handle, ensure_ascii=False, indent=2)

    print(completeness[["alternative_id", "completeness_ratio", "missing_criteria", "ready_for_full_primary_model"]].to_string(index=False))
    print(f"Outputs written to: {outputs}")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--root",
        type=Path,
        default=Path(__file__).resolve().parent,
        help="Package root containing data_raw/, data_processed/, and outputs/.",
    )
    args = parser.parse_args()
    compute(args.root.resolve())


if __name__ == "__main__":
    main()