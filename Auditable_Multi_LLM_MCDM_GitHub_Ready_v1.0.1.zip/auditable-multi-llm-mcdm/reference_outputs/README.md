# Reference outputs

This folder contains a compact, human-readable subset of the frozen full-run outputs.
The full generated output tree is preserved in `../release_assets/reference_outputs_full.zip`.
Running `python run_all.py` regenerates a fresh `outputs/` directory and validation report.
