#!/usr/bin/env python3
"""Validate reproduced outputs against the frozen study outputs.

This validator distinguishes three outcomes:
* PASS: regenerated output agrees with the frozen expected result within tolerance.
* WARN: the computation is internally reproducible, but a manuscript/protocol wording
  issue remains (notably the cosine-vs-Euclidean HDBSCAN reporting distinction).
* FAIL: regenerated output does not reproduce the frozen expected result.
"""
from __future__ import annotations

import argparse
import json
import math
from pathlib import Path
from typing import Any, Iterable

import numpy as np
import pandas as pd


class ValidationLog:
    def __init__(self) -> None:
        self.rows: list[dict[str, Any]] = []

    def add(self, stage: str, check: str, status: str, detail: str) -> None:
        self.rows.append({"stage": stage, "check": check, "status": status, "detail": detail})

    @property
    def failed(self) -> bool:
        return any(row["status"] == "FAIL" for row in self.rows)

    def counts(self) -> dict[str, int]:
        return {status: sum(row["status"] == status for row in self.rows) for status in ["PASS", "WARN", "FAIL"]}


def read_csv(path: Path) -> pd.DataFrame:
    if not path.exists():
        raise FileNotFoundError(path)
    return pd.read_csv(path, encoding="utf-8-sig")


def _norm_string(value: Any) -> str:
    if pd.isna(value):
        return "<NA>"
    return str(value).strip()


def compare_keyed_numeric(
    log: ValidationLog,
    stage: str,
    check: str,
    actual: pd.DataFrame,
    expected: pd.DataFrame,
    keys: list[str],
    columns: list[str],
    tolerance: float,
) -> None:
    try:
        a = actual[keys + columns].copy().sort_values(keys).reset_index(drop=True)
        e = expected[keys + columns].copy().sort_values(keys).reset_index(drop=True)
    except KeyError as exc:
        log.add(stage, check, "FAIL", f"Missing comparison column: {exc}")
        return
    if len(a) != len(e):
        log.add(stage, check, "FAIL", f"Row count differs: actual={len(a)}, expected={len(e)}")
        return
    for key in keys:
        if [_norm_string(x) for x in a[key]] != [_norm_string(x) for x in e[key]]:
            log.add(stage, check, "FAIL", f"Key values differ for {key}")
            return
    maximum = 0.0
    worst = ""
    for column in columns:
        av = pd.to_numeric(a[column], errors="coerce").to_numpy(float)
        ev = pd.to_numeric(e[column], errors="coerce").to_numpy(float)
        same_nan = np.isnan(av) & np.isnan(ev)
        mismatch_nan = np.isnan(av) ^ np.isnan(ev)
        if mismatch_nan.any():
            log.add(stage, check, "FAIL", f"Missing-value pattern differs in {column}")
            return
        diff = np.abs(av - ev)
        diff[same_nan] = 0.0
        if len(diff) and float(np.max(diff)) > maximum:
            maximum = float(np.max(diff))
            worst = column
    if maximum <= tolerance:
        log.add(stage, check, "PASS", f"max |Δ|={maximum:.3g} (tolerance={tolerance:g})")
    else:
        log.add(stage, check, "FAIL", f"max |Δ|={maximum:.6g} in {worst} exceeds {tolerance:g}")


def compare_keyed_strings(
    log: ValidationLog,
    stage: str,
    check: str,
    actual: pd.DataFrame,
    expected: pd.DataFrame,
    keys: list[str],
    columns: list[str],
) -> None:
    try:
        a = actual[keys + columns].copy().sort_values(keys).reset_index(drop=True)
        e = expected[keys + columns].copy().sort_values(keys).reset_index(drop=True)
    except KeyError as exc:
        log.add(stage, check, "FAIL", f"Missing comparison column: {exc}")
        return
    if len(a) != len(e):
        log.add(stage, check, "FAIL", f"Row count differs: actual={len(a)}, expected={len(e)}")
        return
    for column in keys + columns:
        av = [_norm_string(x) for x in a[column]]
        ev = [_norm_string(x) for x in e[column]]
        if av != ev:
            idx = next((i for i, (x, y) in enumerate(zip(av, ev)) if x != y), None)
            log.add(stage, check, "FAIL", f"Mismatch in {column} at sorted row {idx}: {av[idx]} != {ev[idx]}")
            return
    log.add(stage, check, "PASS", f"{len(a)} keyed rows and categorical decisions agree")


def validate_discovery(root: Path, log: ValidationLog) -> None:
    stage = "01 criterion-family discovery"
    actual = read_csv(root / "outputs/01_criterion_discovery/k_selection.csv")
    expected = read_csv(root / "data/expected/criterion_discovery_expected.csv")
    compare_keyed_numeric(
        log,
        stage,
        "selected cluster counts and validity metrics",
        actual.rename(columns={
            "selected_silhouette": "silhouette",
            "selected_resampling_ari": "resampling_ari",
            "selected_singleton_rate": "singleton_rate",
        }),
        expected,
        ["variant"],
        ["selected_k", "silhouette", "resampling_ari", "singleton_rate"],
        5e-6,
    )

    summary = json.loads((root / "outputs/01_criterion_discovery/discovery_summary.json").read_text(encoding="utf-8"))
    invariants = {
        "raw criteria": summary.get("raw_criteria") == 100,
        "primary representation": summary.get("selected_primary_variant") == "weighted",
        "selected k": summary.get("selected_k") == 32,
        "approved labels excluded from fitting": summary.get("approved_labels_used_for_fit_or_selection") is False,
    }
    failed = [name for name, ok in invariants.items() if not ok]
    log.add(stage, "design invariants", "PASS" if not failed else "FAIL", "all fixed" if not failed else ", ".join(failed))

    h_actual = read_csv(root / "outputs/01_criterion_discovery/hdbscan_primary_and_sensitivity.csv")
    h_expected = read_csv(root / "data/expected/hdbscan_expected.csv")
    compare_keyed_numeric(
        log,
        stage,
        "cosine primary and Euclidean sensitivity HDBSCAN",
        h_actual,
        h_expected,
        ["specification"],
        [
            "n_clusters",
            "noise_fraction",
            "silhouette_cosine_non_noise",
            "ari_vs_selected_agglomerative",
            "nmi_vs_selected_agglomerative",
            "ari_vs_approved_codebook",
            "nmi_vs_approved_codebook",
        ],
        1e-10,
    )

    cosine = h_actual.loc[h_actual["specification"] == "PRIMARY_METHOD_ALIGNED"].iloc[0]
    euclid = h_actual.loc[h_actual["specification"] == "EUCLIDEAN_SENSITIVITY_LEGACY_REPRODUCTION"].iloc[0]
    log.add(
        stage,
        "manuscript HDBSCAN reporting alignment",
        "WARN",
        (
            "Method-aligned cosine HDBSCAN gives "
            f"{int(cosine.n_clusters)} clusters, {cosine.noise_fraction:.0%} noise, "
            f"silhouette={cosine.silhouette_cosine_non_noise:.3f}; the historical manuscript row "
            f"({int(euclid.n_clusters)} clusters, {euclid.noise_fraction:.0%} noise, "
            f"silhouette={euclid.silhouette_cosine_non_noise:.3f}, ARI={euclid.ari_vs_approved_codebook:.3f}, "
            f"NMI={euclid.nmi_vs_approved_codebook:.3f}) is exactly reproduced by the Euclidean sensitivity run. "
            "Update the manuscript row if cosine is declared as the primary density specification."
        ),
    )


def validate_evidence(root: Path, log: ValidationLog) -> None:
    stage = "02 evidence fusion and core selection"
    actual = read_csv(root / "outputs/02_evidence_fusion/family_evidence_channels.csv")
    expected = read_csv(root / "data/expected/family_evidence_expected.csv")
    renamed = actual.rename(columns={
        "family_code": "canonical_code",
        "disagreement_measure": "disagreement_penalty",
    })
    compare_keyed_numeric(
        log,
        stage,
        "26-family evidence channels",
        renamed,
        expected,
        ["canonical_code"],
        [
            "models_present", "coverage_ratio", "known_weight_count", "median_global_weight",
            "median_percentile", "iqr_global_weight", "iqr_percentile", "top_support_ratio",
            "bottom_support_ratio", "completeness_ratio", "approx_ratio",
            "norm_median_global_weight", "support_balance", "median_percentile_filled",
            "robust_importance", "disagreement_penalty", "evidence_score", "phase_adjustment", "final_score",
        ],
        1e-12,
    )
    compare_keyed_strings(
        log,
        stage,
        "family classifications",
        renamed,
        expected,
        ["canonical_code"],
        ["preliminary_decision"],
    )

    core = read_csv(root / "outputs/02_evidence_fusion/conceptual_core_weights.csv").rename(
        columns={"family_code": "canonical_code", "conceptual_weight": "final_weight"}
    )
    exp_core = read_csv(root / "data/expected/conceptual_core_expected.csv")
    compare_keyed_numeric(
        log,
        stage,
        "10 conceptual-core weights",
        core,
        exp_core,
        ["canonical_code"],
        ["final_weight", "final_score", "coverage_ratio", "median_global_weight", "median_percentile"],
        1e-12,
    )
    expected_sets = {
        "CORE_SCORING": 10,
        "OPTIONAL_ADDON": 6,
        "HARD_CONSTRAINT": 3,
    }
    for decision, expected_n in expected_sets.items():
        n = int((actual["final_decision"] == decision).sum())
        log.add(stage, f"{decision} count", "PASS" if n == expected_n else "FAIL", f"actual={n}, expected={expected_n}")
    merge_drop = int(actual["final_decision"].astype(str).str.startswith("MERGE_INTO_").sum()) + int((actual["final_decision"] == "DROP_ACUTE").sum())
    log.add(stage, "merge/drop count", "PASS" if merge_drop == 7 else "FAIL", f"actual={merge_drop}, expected=7")

    # Method-specific safeguards.
    source_family = read_csv(root / "outputs/02_evidence_fusion/source_family_records.csv")
    duplicate_pairs = source_family.duplicated(["model_id", "family_code"]).sum()
    log.add(stage, "one source-family record after within-source MAX", "PASS" if duplicate_pairs == 0 else "FAIL", f"duplicate source-family pairs={duplicate_pairs}")
    missing = source_family["global_weight_model_family"].isna().sum()
    log.add(stage, "missing weights retained as unavailable", "PASS", f"missing source-family weights retained={missing}; no zero imputation")


def validate_public_model(root: Path, log: ValidationLog) -> None:
    stage = "03 public-data MCDM"
    actual_u = read_csv(root / "outputs/03_public_data_mcdm/final_public_data_utility_matrix.csv")
    names = read_csv(root / "data/public/candidate_registry.csv")[["alternative_id", "refined_name"]]
    actual_u = actual_u.merge(names, on="alternative_id", how="left")
    expected_u = read_csv(root / "data/expected/utility_matrix_expected.csv")
    compare_keyed_numeric(log, stage, "16×5 primary utility matrix", actual_u, expected_u, ["alternative_id"], ["D12", "D5", "D7", "D6", "D8"], 1e-12)

    actual_t = read_csv(root / "outputs/03_public_data_mcdm/promethee_thresholds.csv")
    expected_t = read_csv(root / "data/expected/promethee_thresholds_expected.csv")
    compare_keyed_numeric(log, stage, "PROMETHEE q/p thresholds", actual_t, expected_t, ["criterion"], ["q", "p"], 1e-12)

    actual_r = read_csv(root / "outputs/03_public_data_mcdm/final_mcdm_rankings.csv")
    expected_r = read_csv(root / "data/expected/promethee_expected.csv")
    compare_keyed_numeric(log, stage, "PROMETHEE II flows and ranks", actual_r, expected_r, ["alternative_id"], ["phi_plus", "phi_minus", "phi_net", "PROMETHEE_rank"], 1e-12)

    expected_method = read_csv(root / "data/expected/method_robustness_expected.csv")
    compare_keyed_numeric(
        log,
        stage,
        "TOPSIS/VIKOR benchmark ranks and scores",
        actual_r,
        expected_method,
        ["alternative_id"],
        ["PROMETHEE_rank", "TOPSIS_rank", "VIKOR_rank", "consensus_rank", "mean_method_rank", "method_rank_sd", "TOPSIS_score", "VIKOR_Q"],
        1e-12,
    )

    actual_s = read_csv(root / "outputs/03_public_data_mcdm/d1_d2_sensitivity.csv")
    expected_s = read_csv(root / "data/expected/d1_d2_sensitivity_expected.csv")
    compare_keyed_numeric(log, stage, "D12/D1-only/D2-only sensitivity", actual_s, expected_s, ["alternative_id"], ["base_D12_rank", "D1_only_rank", "D2_only_rank", "abs_change_D1", "abs_change_D2"], 0.0)

    actual_mc = read_csv(root / "outputs/03_public_data_mcdm/monte_carlo_rank_acceptability.csv")
    expected_mc = read_csv(root / "data/expected/monte_carlo_expected.csv")
    compare_keyed_numeric(log, stage, "5,000-run Monte Carlo rank acceptability", actual_mc, expected_mc, ["alternative_id"], ["mean_rank", "rank_sd", "p_rank_1", "p_top3", "p_top5"], 1e-12)

    # Main published rank correlations.
    corr = read_csv(root / "outputs/03_public_data_mcdm/method_rank_correlations.csv")
    target = {
        "PROMETHEE vs TOPSIS": 0.9147058823529411,
        "PROMETHEE vs VIKOR": 0.95,
        "TOPSIS vs VIKOR": 0.961764705882353,
        "Base D12 vs D1-only": 0.9647058823529412,
        "Base D12 vs D2-only": 0.9411764705882352,
    }
    ok = True
    max_diff = 0.0
    for name, value in target.items():
        rows = corr[corr["comparison"] == name]
        if len(rows) != 1:
            ok = False
            continue
        max_diff = max(max_diff, abs(float(rows.iloc[0]["spearman_rho"]) - value))
    log.add(stage, "method and specification rank correlations", "PASS" if ok and max_diff <= 1e-12 else "FAIL", f"max |Δ|={max_diff:.3g}")

    raw = read_csv(root / "data/public/raw_performance.csv")
    active = raw[raw["analysis_status"] == "INCLUDE_CONDITIONAL"]
    log.add(stage, "eligible alternatives and matrix completeness", "PASS" if len(active) == 16 and not active[["D1_population_weighted_travel_time_min", "D2_population_coverage_30min", "D5_osm_route_redundancy_index", "D6_nearest_gateway_time_min", "D7_osm_last_mile_hgv_proxy", "site_area_proxy_m2"]].isna().any().any() else "FAIL", f"eligible alternatives={len(active)}")


def validate_human(root: Path, log: ValidationLog) -> None:
    stage = "04 blind human benchmark"
    panel = read_csv(root / "outputs/04_human_benchmark/human_panel_summary.csv")
    exp_panel = read_csv(root / "data/expected/human_panel_summary_expected.csv")
    compare_keyed_numeric(
        log,
        stage,
        "48 cell human aggregation and confidence-weighting",
        panel,
        exp_panel,
        ["alternative_id", "criterion_code"],
        [
            "valid_n", "human_mean_score", "human_median_score", "human_q1", "human_q3",
            "human_iqr", "human_median_utility", "human_confidence_weighted_utility",
            "mean_confidence", "median_confidence", "sufficient_n", "partly_sufficient_n",
            "in_scope_n", "partial_scope_n", "second_review_n",
        ],
        1e-6,
    )

    agreement = read_csv(root / "outputs/04_human_benchmark/human_inter_rater_reliability.csv")
    exp_agreement = read_csv(root / "data/expected/human_agreement_expected.csv")
    compare_keyed_numeric(
        log,
        stage,
        "Kendall W and ICC(2,k)",
        agreement,
        exp_agreement,
        ["criterion_code"],
        ["kendall_w", "chi_square", "p_value", "icc_2k_absolute_agreement", "mean_cell_iqr", "max_cell_iqr", "mean_confidence"],
        1e-6,
    )

    summary = json.loads((root / "outputs/04_human_benchmark/human_benchmark_summary.json").read_text(encoding="utf-8"))
    overall = summary["data_human_overall"]
    targets = {
        "mae": 1.72507243484452,
        "rmse": 2.12903438926399,
        "bias": -0.2594459171739495,
        "within_1_rate": 0.375,
        "within_2_rate": 0.6458333333333334,
    }
    max_diff = max(abs(float(overall[k]) - v) for k, v in targets.items())
    log.add(stage, "overall data-human concordance", "PASS" if max_diff <= 1e-12 else "FAIL", f"max |Δ|={max_diff:.3g}; MAE={overall['mae']:.3f}, RMSE={overall['rmse']:.3f}, bias={overall['bias']:.3f}")

    comparisons = read_csv(root / "outputs/04_human_benchmark/decision_level_concordance.csv")
    expected_comparisons = {
        "human_median": (0.8764705882352941, 0.7, 2, 4),
        "human_confidence": (0.8529411764705882, 0.6666666666666666, 2, 3),
        "data75_human25": (0.9823529411764707, 0.9166666666666666, 3, 4),
    }
    ok = True
    max_diff = 0.0
    for name, (rho, tau, top3, top5) in expected_comparisons.items():
        row = comparisons[comparisons["compared_with_data_only"] == name]
        if len(row) != 1:
            ok = False
            continue
        r = row.iloc[0]
        max_diff = max(max_diff, abs(float(r.spearman_rho) - rho), abs(float(r.kendall_tau) - tau))
        ok &= int(r.top3_overlap) == top3 and int(r.top5_overlap) == top5
    log.add(stage, "decision-level human and hybrid scenarios", "PASS" if ok and max_diff <= 1e-12 else "FAIL", f"max rank-correlation |Δ|={max_diff:.3g}")

    raw = read_csv(root / "data/human/human_raw_scores.csv")
    complete = len(raw) == 240 and raw["expert_id"].nunique() == 5 and raw["Kriter kodu"].nunique() == 3
    log.add(stage, "panel completeness", "PASS" if complete else "FAIL", f"ratings={len(raw)}, experts={raw['expert_id'].nunique()}, criteria={raw['Kriter kodu'].nunique()}")


def write_reports(root: Path, log: ValidationLog) -> None:
    out = root / "outputs/validation"
    out.mkdir(parents=True, exist_ok=True)
    counts = log.counts()
    payload = {
        "package": "Auditable Multi-LLM Criterion Engineering and MCDM Reproducibility Package",
        "overall_status": "FAIL" if log.failed else ("PASS_WITH_WARNINGS" if counts["WARN"] else "PASS"),
        "counts": counts,
        "checks": log.rows,
    }
    (out / "validation_report.json").write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")

    lines = [
        "# Reproduction Validation Report",
        "",
        f"**Overall status:** {payload['overall_status']}",
        "",
        f"PASS: {counts['PASS']}  |  WARN: {counts['WARN']}  |  FAIL: {counts['FAIL']}",
        "",
        "| Stage | Check | Status | Detail |",
        "|---|---|---:|---|",
    ]
    for row in log.rows:
        detail = str(row["detail"]).replace("|", "\\|").replace("\n", " ")
        lines.append(f"| {row['stage']} | {row['check']} | **{row['status']}** | {detail} |")
    lines.extend([
        "",
        "## Interpretation of the HDBSCAN warning",
        "",
        "The manuscript methodology defines cosine dissimilarity for the semantic space. The method-aligned package therefore uses a precomputed cosine-distance matrix for the primary HDBSCAN robustness analysis. The historical implementation used Euclidean distance on L2-normalised vectors and exactly reproduces the numerical HDBSCAN row previously reported in Table 2. The two density partitions agree very strongly, and HDBSCAN is a robustness diagnostic rather than an input to the locked operational codebook, evidence weights, public-data decision matrix, or rankings. Nevertheless, the manuscript row should be labelled consistently with whichever HDBSCAN specification is declared primary.",
    ])
    (out / "VALIDATION_REPORT.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    pd.DataFrame(log.rows).to_csv(out / "validation_checks.csv", index=False, encoding="utf-8-sig")


def main(root: Path) -> int:
    log = ValidationLog()
    stages = [validate_discovery, validate_evidence, validate_public_model, validate_human]
    for function in stages:
        try:
            function(root, log)
        except Exception as exc:  # keep a complete audit trail across stages
            log.add(function.__name__, "stage execution", "FAIL", f"{type(exc).__name__}: {exc}")
    write_reports(root, log)
    print(json.dumps({"overall_status": "FAIL" if log.failed else "PASS_WITH_WARNINGS" if log.counts()["WARN"] else "PASS", **log.counts()}, indent=2))
    return 1 if log.failed else 0


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[1])
    args = parser.parse_args()
    raise SystemExit(main(args.root.resolve()))
