#!/usr/bin/env python3
"""Reproduce the blind human-panel reliability and data-human sensitivity analyses."""
from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
from scipy.stats import chi2, kendalltau, rankdata, spearmanr

from mcdm_core import promethee_ii


def load_config(root: Path) -> dict[str, Any]:
    return json.loads((root / "config/study_config.json").read_text(encoding="utf-8"))


def kendalls_w(matrix: np.ndarray) -> tuple[float, float, float]:
    """Kendall's W with tie correction; rows are alternatives, columns are experts."""
    n, m = matrix.shape
    ranks = np.apply_along_axis(rankdata, 0, matrix, method="average")
    rank_sums = ranks.sum(axis=1)
    expected = m * (n + 1) / 2
    s = float(((rank_sums - expected) ** 2).sum())
    tie_term = 0.0
    for column in range(m):
        _, counts = np.unique(matrix[:, column], return_counts=True)
        tie_term += float(np.sum(counts**3 - counts))
    denominator = m**2 * (n**3 - n) - m * tie_term
    w = 12 * s / denominator
    statistic = m * (n - 1) * w
    p_value = float(chi2.sf(statistic, n - 1))
    return float(w), float(statistic), p_value


def icc_2k_absolute_agreement(matrix: np.ndarray) -> float:
    """Two-way random-effects, absolute-agreement, average-measures ICC(2,k)."""
    n, k = matrix.shape
    grand = matrix.mean()
    row_means = matrix.mean(axis=1)
    column_means = matrix.mean(axis=0)
    ss_rows = k * np.sum((row_means - grand) ** 2)
    ss_columns = n * np.sum((column_means - grand) ** 2)
    ss_error = np.sum((matrix - row_means[:, None] - column_means[None, :] + grand) ** 2)
    ms_rows = ss_rows / (n - 1)
    ms_columns = ss_columns / (k - 1)
    ms_error = ss_error / ((n - 1) * (k - 1))
    return float((ms_rows - ms_error) / (ms_rows + (ms_columns - ms_error) / n))


def panel_aggregation(raw: pd.DataFrame, cfg: dict[str, Any]) -> pd.DataFrame:
    score_max = int(cfg["rating_scale_max"])
    confidence_max = float(cfg["confidence_scale_max"])
    evidence = cfg["evidence_factors"]
    scope = cfg["scope_factors"]
    frame = raw.copy()
    frame["score"] = pd.to_numeric(frame["Puan 1–9"], errors="raise")
    frame["confidence"] = pd.to_numeric(frame["Güven 1–5"], errors="raise")
    frame["evidence_factor"] = frame["Kanıt yeterliliği"].map(evidence)
    frame["scope_factor"] = frame["Uzmanlık kapsamı"].map(scope)
    if frame[["evidence_factor", "scope_factor"]].isna().any().any():
        unknown_evidence = sorted(frame.loc[frame["evidence_factor"].isna(), "Kanıt yeterliliği"].unique())
        unknown_scope = sorted(frame.loc[frame["scope_factor"].isna(), "Uzmanlık kapsamı"].unique())
        raise ValueError(f"Unknown human-weight labels: evidence={unknown_evidence}, scope={unknown_scope}")
    frame["rating_weight"] = (
        frame["confidence"] / confidence_max * frame["evidence_factor"] * frame["scope_factor"]
    )
    frame["score_utility"] = (frame["score"] - 1) / (score_max - 1)

    rows: list[dict[str, Any]] = []
    for (alternative_id, criterion), group in frame.groupby(["Alternative ID", "Kriter kodu"]):
        scores = group["score"].to_numpy(float)
        weights = group["rating_weight"].to_numpy(float)
        rows.append(
            {
                "alternative_id": alternative_id,
                "alternative_name": group["Aday"].iloc[0],
                "criterion_code": criterion,
                "valid_n": int(len(group)),
                "human_mean_score": float(scores.mean()),
                "human_median_score": float(np.median(scores)),
                "human_q1": float(np.quantile(scores, 0.25)),
                "human_q3": float(np.quantile(scores, 0.75)),
                "human_iqr": float(np.quantile(scores, 0.75) - np.quantile(scores, 0.25)),
                "human_min": float(scores.min()),
                "human_max": float(scores.max()),
                "human_median_utility": float((np.median(scores) - 1) / (score_max - 1)),
                "human_confidence_weighted_utility": float(
                    np.sum(group["score_utility"].to_numpy(float) * weights) / np.sum(weights)
                ),
                "mean_confidence": float(group["confidence"].mean()),
                "median_confidence": float(group["confidence"].median()),
                "sufficient_n": int((group["Kanıt yeterliliği"] == "SUFFICIENT").sum()),
                "partly_sufficient_n": int((group["Kanıt yeterliliği"] == "PARTLY SUFFICIENT").sum()),
                "in_scope_n": int((group["Uzmanlık kapsamı"] == "IN_SCOPE").sum()),
                "partial_scope_n": int((group["Uzmanlık kapsamı"] == "PARTIAL").sum()),
                "second_review_n": int((group["İkinci inceleme?"] == "YES").sum()),
            }
        )
    return pd.DataFrame(rows).sort_values(["alternative_id", "criterion_code"]).reset_index(drop=True)


def reliability(raw: pd.DataFrame) -> pd.DataFrame:
    frame = raw.copy()
    frame["score"] = pd.to_numeric(frame["Puan 1–9"], errors="raise")
    frame["confidence"] = pd.to_numeric(frame["Güven 1–5"], errors="raise")
    rows = []
    for criterion, group in frame.groupby("Kriter kodu"):
        matrix = group.pivot(index="Alternative ID", columns="expert_id", values="score").sort_index().to_numpy(float)
        w, statistic, p_value = kendalls_w(matrix)
        rows.append(
            {
                "criterion_code": criterion,
                "n_candidates": matrix.shape[0],
                "n_experts": matrix.shape[1],
                "kendall_w": w,
                "chi_square": statistic,
                "df": matrix.shape[0] - 1,
                "p_value": p_value,
                "icc_2k_absolute_agreement": icc_2k_absolute_agreement(matrix),
                "mean_cell_iqr": float(
                    group.groupby("Alternative ID")["score"].apply(
                        lambda s: np.quantile(s, 0.75) - np.quantile(s, 0.25)
                    ).mean()
                ),
                "max_cell_iqr": float(
                    group.groupby("Alternative ID")["score"].apply(
                        lambda s: np.quantile(s, 0.75) - np.quantile(s, 0.25)
                    ).max()
                ),
                "mean_confidence": float(group["confidence"].mean()),
            }
        )
    return pd.DataFrame(rows).sort_values("criterion_code")


def data_human_concordance(
    public_utilities: pd.DataFrame,
    panel: pd.DataFrame,
    scale_max: int,
) -> tuple[pd.DataFrame, pd.DataFrame, dict[str, float]]:
    long = public_utilities.melt(
        id_vars=["alternative_id"],
        value_vars=["D5", "D7", "D8"],
        var_name="criterion_code",
        value_name="data_utility",
    )
    long["data_score"] = 1 + (scale_max - 1) * pd.to_numeric(long["data_utility"])
    merged = long.merge(
        panel[["alternative_id", "alternative_name", "criterion_code", "human_median_score", "human_iqr", "second_review_n"]],
        on=["alternative_id", "criterion_code"],
        how="inner",
        validate="one_to_one",
    )
    merged["signed_difference_data_minus_human"] = merged["data_score"] - merged["human_median_score"]
    merged["absolute_difference"] = merged["signed_difference_data_minus_human"].abs()
    merged["within_1"] = merged["absolute_difference"] <= 1
    merged["within_2"] = merged["absolute_difference"] <= 2

    rows = []
    for criterion, group in merged.groupby("criterion_code"):
        signed = group["signed_difference_data_minus_human"]
        rho, rho_p = spearmanr(group["data_score"], group["human_median_score"])
        tau, tau_p = kendalltau(group["data_score"], group["human_median_score"])
        data_top5 = set(group.nsmallest(5, "data_score", keep="all")["alternative_id"]) if False else set(
            group.nlargest(5, "data_score")["alternative_id"]
        )
        human_top5 = set(group.nlargest(5, "human_median_score")["alternative_id"])
        rows.append(
            {
                "criterion_code": criterion,
                "n_candidates": len(group),
                "data_mean": float(group["data_score"].mean()),
                "human_mean": float(group["human_median_score"].mean()),
                "bias": float(signed.mean()),
                "mae": float(group["absolute_difference"].mean()),
                "rmse": float(np.sqrt(np.mean(signed**2))),
                "within_1_rate": float(group["within_1"].mean()),
                "within_2_rate": float(group["within_2"].mean()),
                "spearman_rho": float(rho),
                "spearman_p": float(rho_p),
                "kendall_tau_b": float(tau),
                "kendall_p": float(tau_p),
                "top5_overlap": int(len(data_top5 & human_top5)),
            }
        )
    criterion = pd.DataFrame(rows).sort_values("criterion_code")
    signed = merged["signed_difference_data_minus_human"]
    overall = {
        "n_cells": int(len(merged)),
        "mae": float(merged["absolute_difference"].mean()),
        "rmse": float(np.sqrt(np.mean(signed**2))),
        "bias": float(signed.mean()),
        "within_1_rate": float(merged["within_1"].mean()),
        "within_2_rate": float(merged["within_2"].mean()),
    }
    return merged.sort_values(["criterion_code", "alternative_id"]), criterion, overall


def scenario_rankings(
    public_utilities: pd.DataFrame,
    panel: pd.DataFrame,
    thresholds: pd.DataFrame,
    weights: dict[str, float],
    data_share: float,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    public = public_utilities.set_index("alternative_id")[list(weights)].copy()
    median_wide = panel.pivot(index="alternative_id", columns="criterion_code", values="human_median_utility")
    confidence_wide = panel.pivot(index="alternative_id", columns="criterion_code", values="human_confidence_weighted_utility")
    scenarios = {
        "data_only": public.copy(),
        "human_median": public.copy(),
        "human_confidence": public.copy(),
        "data75_human25": public.copy(),
    }
    for criterion in ["D5", "D7", "D8"]:
        scenarios["human_median"][criterion] = median_wide[criterion]
        scenarios["human_confidence"][criterion] = confidence_wide[criterion]
        scenarios["data75_human25"][criterion] = (
            data_share * public[criterion] + (1 - data_share) * median_wide[criterion]
        )
    outputs = []
    rank_series: dict[str, pd.Series] = {}
    for scenario, matrix in scenarios.items():
        result = promethee_ii(matrix, weights, thresholds)
        rank_series[scenario] = result["PROMETHEE_rank"].reindex(public.index)
        temp = result.reset_index().rename(columns={"index": "alternative_id"})
        temp.insert(1, "scenario", scenario)
        outputs.append(temp)
    all_results = pd.concat(outputs, ignore_index=True)
    baseline = rank_series["data_only"]
    base_top3 = set(baseline.nsmallest(3).index)
    base_top5 = set(baseline.nsmallest(5).index)
    comparisons = []
    for scenario in ["human_median", "human_confidence", "data75_human25"]:
        ranks = rank_series[scenario]
        rho, rho_p = spearmanr(baseline, ranks)
        tau, tau_p = kendalltau(baseline, ranks)
        comparisons.append(
            {
                "compared_with_data_only": scenario,
                "spearman_rho": float(rho),
                "spearman_p": float(rho_p),
                "kendall_tau": float(tau),
                "kendall_p": float(tau_p),
                "top3_overlap": int(len(base_top3 & set(ranks.nsmallest(3).index))),
                "top5_overlap": int(len(base_top5 & set(ranks.nsmallest(5).index))),
            }
        )
    return all_results, pd.DataFrame(comparisons)


def main(root: Path) -> None:
    full_config = load_config(root)
    cfg = full_config["human_benchmark"]
    public_cfg = full_config["public_model"]
    out = root / "outputs/04_human_benchmark"
    out.mkdir(parents=True, exist_ok=True)
    raw = pd.read_csv(root / "data/human/human_raw_scores.csv", encoding="utf-8-sig")
    panel = panel_aggregation(raw, cfg)
    agreement = reliability(raw)
    public_utilities = pd.read_csv(
        root / "outputs/03_public_data_mcdm/final_public_data_utility_matrix.csv",
        encoding="utf-8-sig",
    )
    thresholds = pd.read_csv(
        root / "outputs/03_public_data_mcdm/promethee_thresholds.csv",
        encoding="utf-8-sig",
    )
    weights = {key: float(value) for key, value in public_cfg["weights"].items()}
    cell, criterion, overall = data_human_concordance(public_utilities, panel, int(cfg["rating_scale_max"]))
    scenarios, comparisons = scenario_rankings(
        public_utilities,
        panel,
        thresholds,
        weights,
        float(cfg["hybrid_data_share"]),
    )

    panel.to_csv(out / "human_panel_summary.csv", index=False, encoding="utf-8-sig")
    agreement.to_csv(out / "human_inter_rater_reliability.csv", index=False, encoding="utf-8-sig")
    cell.to_csv(out / "data_human_cell_concordance.csv", index=False, encoding="utf-8-sig")
    criterion.to_csv(out / "data_human_criterion_concordance.csv", index=False, encoding="utf-8-sig")
    scenarios.to_csv(out / "human_informed_promethee_scenarios.csv", index=False, encoding="utf-8-sig")
    comparisons.to_csv(out / "decision_level_concordance.csv", index=False, encoding="utf-8-sig")
    flagged = cell.sort_values(["absolute_difference", "human_iqr", "second_review_n"], ascending=[False, True, False]).head(10)
    flagged.to_csv(out / "largest_proxy_divergences.csv", index=False, encoding="utf-8-sig")
    (out / "human_benchmark_summary.json").write_text(
        json.dumps(
            {
                "experts": int(raw["expert_id"].nunique()),
                "ratings": int(len(raw)),
                "criteria": sorted(raw["Kriter kodu"].unique().tolist()),
                "confidence_weight_formula": "(confidence/5) * evidence_factor * scope_factor",
                "evidence_factors": cfg["evidence_factors"],
                "scope_factors": cfg["scope_factors"],
                "data_human_overall": overall,
            },
            ensure_ascii=False,
            indent=2,
        ),
        encoding="utf-8",
    )
    print(json.dumps(overall, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[1])
    args = parser.parse_args()
    main(args.root.resolve())
