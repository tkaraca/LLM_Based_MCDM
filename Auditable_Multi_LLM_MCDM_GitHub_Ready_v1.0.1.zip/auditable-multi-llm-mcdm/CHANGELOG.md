# Changelog

## 1.0.0-method-aligned — 2026-11-01

- separated unsupervised criterion discovery from approved-family labels;
- replaced bootstrap terminology with resampling terminology;
- made cosine HDBSCAN the primary density specification and retained Euclidean as a legacy-reproduction sensitivity analysis;
- reported HDBSCAN agreement against both the selected agglomerative partition and the frozen approved codebook;
- added medoid, boundary-case, and researcher-adjudication artifacts;
- enforced within-source `MAX(global weight)` consolidation;
- preserved missing importance as unavailable rather than zero;
- implemented evidence/coverage thresholds, macro-dimension quotas, and coverage-preserving secondary backfill;
- froze D6/D8 construct-fidelity carry-forward and D1/D2 weight-preserving D12 consolidation;
- retained hard constraints outside compensatory scoring;
- aligned optional geospatial utilities to the final 30-minute D2/D3 specification;
- documented human-confidence conversion coefficients;
- added deterministic PROMETHEE II, TOPSIS, VIKOR, Monte Carlo, and human-benchmark regeneration;
- added 25 numerical/structural PASS checks and an explicit HDBSCAN manuscript-alignment warning;
- added a draft codebook-definition completion file marked for author verification.

## 1.0.1-github-ready — 2026-11-11

- Reorganized the package for direct GitHub publication.
- Kept all active source code and frozen reproducibility inputs.
- Moved generated outputs, figures, and historical scripts into compressed release assets to reduce browser-upload file count.
- Added selected readable reference outputs, `.gitattributes`, a GitHub upload guide, and repository inventory.
- No numerical method or frozen result was changed.
- Vectorised the PROMETHEE II pairwise kernel and Monte Carlo execution; all frozen numerical checks remain identical within the declared tolerances.
- Reused one average-linkage hierarchy per resampled subset across all candidate cluster counts; this is partition-equivalent to repeated agglomerative fits and preserves all frozen clustering checks.
