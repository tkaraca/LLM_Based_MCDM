# Method–Code Alignment Record

This document records the changes made to align the reproducibility implementation with the final methodology in Sections 2–3. Historical scripts are retained under `legacy/` for auditability; the executable primary workflow is under `src/`.

## Alignment summary

| Topic | Historical implementation or ambiguity | Method-aligned implementation | Consequence |
|---|---|---|---|
| Semantic input | Approved family mapping was loaded while raw records were prepared | `criterion_corpus.csv` contains no approved-family label; the codebook is loaded only after embedding, cluster scanning, and fine-solution selection | Prevents approved labels from influencing unsupervised fitting or model selection |
| Text representation | Three practical text variants existed but their field influence was implicit | Configuration explicitly freezes name:description:parent repetition as 3:2:1 for the weighted primary representation | Reproduces the selected `k=32` solution and makes field influence auditable |
| Latent representation | Word/character TF–IDF and SVD were implemented locally | TF–IDF is fitted on the complete corpus; word and 0.7-scaled character blocks are concatenated; one 50-dimensional truncated SVD is fitted to the full matrix; L2 normalisation follows | All criteria share one latent coordinate system |
| Agglomerative clustering | Average-linkage/cosine already used | Retained | Matches Equations (3)–(4) |
| Stability terminology | Variables and figures said `bootstrap`, although 85% of records were sampled without replacement | Renamed to `resampling`; implementation remains 85% subsampling without replacement for 100 repetitions | Correct statistical terminology; numerical values unchanged |
| Cluster-count selection | Rule was embedded in code | `η=0.95`, `τ=0.90`, `ρmax=0.40`, `k=10…40`, minimum eligible k | Matches Equation (7) and supplementary configuration |
| HDBSCAN metric | Historical code used Euclidean distance on L2-normalised vectors | Primary run uses a precomputed cosine-distance matrix; historical Euclidean run is retained as an explicit sensitivity/legacy-reproduction specification | See the dedicated HDBSCAN note below |
| HDBSCAN comparison | Historical ARI/NMI were calculated against approved labels, but the manuscript wording could be read as agglomerative–HDBSCAN agreement | Package reports both: agreement with the selected agglomerative partition and post-hoc agreement with the approved codebook, on the non-noise subset | Removes ambiguity and prevents approved labels from being presented as fitting targets |
| Human adjudication | Code could appear to decide the final family structure automatically | Script produces medoids, members, source distributions, boundary cases, and an adjudication template. The frozen researcher mapping is consumed only after clustering | Preserves researcher decision authority in Sections 2.7–2.8 |
| Codebook | Frozen numerical family mapping was available; exact prose definitions/boundaries were not present in supplied files | Numerical mapping remains frozen. A separate complete draft definition file is marked `AUTHOR_REVIEW_REQUIRED` and is never used in numerical analysis | Avoids silently inventing an “approved” prose record |
| Within-source fragmentation | Same source could split a construct into multiple labels | One source–family record is created using `MAX(global weight)`, not SUM; aliases and record counts are preserved; within-source ranks are recalculated at family level | Prevents artificial source influence |
| Missing importance | Missing values risked being interpreted as zero | Missing remains unavailable; coverage and completeness are calculated separately | Matches Equations (11), (12), and (15) |
| Evidence score | Coefficients existed in code | Frozen explicitly in `study_config.json`: 0.35 importance, 0.25 coverage, 0.20 percentile, 0.20 support; 0.10 disagreement penalty; 0.05 completeness contribution | Matches Equation (16) and Supplementary Methods |
| Selection operator | Equation (17) appeared stricter than the historical three-pass code | Primary threshold: score ≥0.60 and coverage ≥0.40. Quota and shortlist backfill require score ≥0.45 and retain coverage ≥0.40; upper quotas remain binding | Implements the documented secondary backfill rule without allowing low-coverage families |
| Merge | `SRV_NEED_VULNERABILITY → SRV_EQUITY_ACCESS` was a fixed researcher rule | Retained as an explicit semantic-operational merge rule; source family does not receive a separate compensatory weight | Avoids conceptual double counting |
| D1/D2 redundancy | Two related response-accessibility measures had separate conceptual weights | D12 preserves their combined weight and uses fixed internal shares; D1-only and D2-only specifications are reproduced | Matches Equation (19) and Section 4.9 |
| D6/D8 re-operationalisation | Case-study labels narrowed, while a separate reassessment record was unavailable | Original family evidence is carried forward only under the declared construct-fidelity rule: the narrower measure remains within the approved family and preserves the same decision function | Matches the revised Section 3.3 wording; weights remain frozen |
| Hard constraints | No complete comparable facility-level evidence was available | Hard constraints remain outside compensatory aggregation and carry `NOT VERIFIED` implementation status; no numerical safety score is invented | Matches Equation (20) and the prioritisation-not-authorisation boundary |
| Optional criteria | Optional families could be confused with the primary model | Explicitly excluded from the five-criterion primary matrix | Scenario/add-on status only |
| D2/D3 time threshold | Optional geospatial script used 45-minute utilities in an intermediate preview | Updated to the final 30-minute D2 and D3 variants; 45/60-minute outputs remain diagnostics | Aligns upstream optional script with Table 3 and the executable model |
| Human confidence weighting | Coefficient-to-category conversion was not visible in the main manuscript | Frozen mapping: confidence/5; sufficient=1.00, partly sufficient=0.75; in-scope=1.00, partial=0.75 | Reproduces the reported confidence-weighted utilities |
| Human role | Human-informed models could be read as replacements | Data-only public model remains primary; human-median, human-confidence, and 75% data + 25% human are sensitivity specifications | Matches Sections 3.9 and 5.5–5.6 |

## HDBSCAN reporting note

The final semantic methodology uses cosine dissimilarity. The method-aligned primary run therefore produces:

- 25 dense clusters;
- 15% noise;
- non-noise cosine silhouette = 0.630243;
- ARI/NMI versus selected `k=32` agglomerative partition = 0.907646 / 0.971054;
- ARI/NMI versus the approved codebook = 0.855024 / 0.956455.

The historical Euclidean implementation exactly reproduces the currently reported Table 2 values:

- 24 dense clusters;
- 15% noise;
- non-noise cosine silhouette = 0.642138;
- ARI/NMI versus approved codebook = 0.881107 / 0.962654.

Cosine and Euclidean density partitions themselves agree strongly on common non-noise records:

- ARI = 0.975320;
- NMI = 0.993669.

Because HDBSCAN is used only as an independent robustness diagnostic, this specification change does not alter the frozen operational codebook, evidence fusion, final weights, five-criterion matrix, rankings, Monte Carlo results, or human benchmark. The manuscript should nevertheless make one consistent choice:

1. declare cosine HDBSCAN primary and update the HDBSCAN row; or
2. describe Euclidean HDBSCAN as the reported implementation and present cosine as sensitivity.

The package recommends option 1 because it matches the stated distance definition in Section 2.3 and Equation (8).

## Codebook prose boundary

The supplied artifacts support the 26 family codes/names, raw-member mapping, aliases, macro dimensions, hard-constraint flags, and merge rule. They do not contain the original adjudication log or exact approved prose for every operational definition, inclusion rule, exclusion rule, and preference direction. Accordingly:

- `approved_family_codebook.csv` is the frozen **numerical mapping artifact**;
- `proposed_codebook_definition_completion.csv` is a best-effort release draft;
- every proposed definition is labelled `AUTHOR_REVIEW_REQUIRED`;
- no proposed definition is read by any analytical script.

Before public repository release, the authors should either approve this draft or replace it with the original adjudication record.

## Implementation-only performance optimisation

The GitHub-ready release vectorises the PROMETHEE II pairwise preference kernel and the 5,000-run Monte Carlo loop. This changes only execution efficiency. The utility matrix, thresholds, flows, ranks, random-number draw order, and Monte Carlo rank-acceptability outputs remain identical to the frozen reference outputs within the validation tolerances.
The criterion-discovery stage also fits one average-linkage hierarchy per seeded resampled subset and cuts that hierarchy at all candidate cluster counts. Under the frozen configuration, this is partition-equivalent to fitting the same average-linkage model separately for each k and preserves the reported silhouette, stability, and selection outputs.
