# Licence and Third-Party Data Notice

This reproducibility package does not assign a blanket software or data licence. Before public release, the manuscript authors should:

1. select an explicit licence for original source code;
2. verify whether each input can be redistributed or should instead be referenced by URL/checksum;
3. preserve OpenStreetMap attribution and ODbL obligations for derived network data;
4. preserve source-specific terms for official/operator facility information;
5. avoid presenting public reference coordinates as verified service-gate coordinates;
6. avoid redistributing expert-identifying material beyond the anonymised/frozen analytical records approved for release.

`data/public/source_manifest.csv` records source class, URL, status, local identifier, checksum when available, licence note, and analytical caveat.
