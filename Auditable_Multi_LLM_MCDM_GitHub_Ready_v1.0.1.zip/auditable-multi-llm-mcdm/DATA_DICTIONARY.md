# Data Dictionary

All CSV files use UTF-8 with a byte-order mark where written by the analysis scripts. Missing values are empty/NA and are not equivalent to zero.

## `data/criterion/criterion_corpus.csv`

One row per raw LLM criterion (`N=100`).

| Field | Meaning |
|---|---|
| `raw_id` | Stable raw-record identifier |
| `model_id`, `model_label` | Source-system identifier and display label |
| `source_code`, `source_name` | Original criterion code and name |
| `source_parent_code`, `source_parent_name` | Original parent dimension |
| `description` | Original explanatory description |
| `data_type`, `direction` | Source-reported data type and preference direction |
| `local_weight`, `global_weight` | Reported/derived source importance; missing remains missing |
| `weight_status` | Reported, derived, approximate, or missing provenance |
| `approximate` | Whether the numerical importance was explicitly approximate |
| `source_rank_within_model`, `source_percentile_within_model` | Raw source-level rank information; family-level ranks are recalculated later |
| `source_top_flag`, `source_bottom_flag` | Explicit or rank-band support evidence |

No approved family labels are included in this clustering input.

## `data/criterion/raw_to_family_mapping.csv`

Frozen mapping applied only after unsupervised semantic discovery.

| Field | Meaning |
|---|---|
| `raw_id` | Raw criterion identifier |
| `family_code`, `family_name` | Researcher-approved operational family |
| `macro_group` | ACCESS, SERVICE, CAPACITY, OPERATIONS, RISK, or COST |
| `hard_constraint` | Non-compensatory status |
| `mapping_status` | Frozen mapping provenance label |

## `data/criterion/approved_family_codebook.csv`

Numerical release artifact for the 26 operational families.

| Field | Meaning |
|---|---|
| `family_code`, `family_name` | Stable family identity |
| `macro_dimension` | Conceptual dimension |
| `hard_constraint` | Whether family is excluded from compensatory scoring |
| `source_aliases`, `parent_aliases`, `source_models` | Frozen provenance summaries |
| `merge_target` | Explicit researcher-approved conceptual merge target, when applicable |
| `operational_definition`, `inclusion_rule`, `exclusion_rule`, `preference_direction` | Exact approved prose fields were unavailable in supplied artifacts and remain blank |
| `definition_source_status` | Makes this missing-prose boundary explicit |
| `codebook_status`, `codebook_version` | Frozen mapping status/version |

`proposed_codebook_definition_completion.csv` provides a complete, non-executable, author-review draft.

## `outputs/01_criterion_discovery/`

| File | Key contents |
|---|---|
| `embedding_metadata.csv` | Feature counts, retained SVD dimensions, explained variance |
| `k_scan.csv` | Variant × k silhouette, resampling ARI, singleton counts/rates, cluster sizes |
| `k_selection.csv` | Selected k under Equation (7) rule |
| `selected_cluster_summary.csv` | Cluster size, medoid, silhouette, source distribution, members |
| `selected_cluster_assignments.csv` | Raw-record cluster assignments and boundary flag |
| `boundary_review_candidates.csv` | Low-silhouette records requiring adjudication attention |
| `researcher_adjudication_template.csv` | Blank decision fields for retain/split/merge/name/boundary review |
| `hdbscan_primary_and_sensitivity.csv` | Cosine primary and Euclidean sensitivity density results |
| `hdbscan_grid.csv` | Full 42-configuration HDBSCAN scan for both metric modes |

## `outputs/02_evidence_fusion/`

### `source_family_records.csv`

One row per source × operational family after within-source MAX consolidation.

Key fields: source/model identifiers, family identifiers, merged aliases, number of merged raw records, retained family weight, recalculated family rank/percentile, top/bottom flags, approximate flag.

### `family_evidence_channels.csv`

One row per family (`H=26`).

| Field | Methodological meaning |
|---|---|
| `models_present`, `coverage_ratio` | Equation (11) |
| `known_weight_count`, `median_global_weight`, `norm_median_global_weight` | Equation (12) |
| `median_percentile` | Equation (13) |
| `top_support_ratio`, `bottom_support_ratio`, `support_balance` | Equation (14) |
| `completeness_ratio`, `iqr_percentile` | Equation (15) |
| `robust_importance`, `disagreement_measure`, `evidence_score`, `phase_adjustment`, `final_score` | Equation (16) components |
| `preliminary_decision`, `final_decision` | Core/optional/hard/merge/drop classification |
| `conceptual_weight` | Equation (18) weight for conceptual core families only |

Other output files are filtered views for conceptual core, optional, hard-constraint, and merge/drop sets.

## `data/public/candidate_registry.csv`

One row per initial alternative (`n0=18`). Fields include stable ID, refined name, district, facility type, public reference coordinate, audit action, analysis status, overlap group, coordinate/source status, source URL, requested facility-specific verification, and registry version.

## `data/public/raw_performance.csv`

Frozen alternative-level input table. The active primary analysis uses rows with `analysis_status=INCLUDE_CONDITIONAL` (`n=16`).

| Field | Meaning |
|---|---|
| `D1_population_weighted_travel_time_min` | Cost-oriented population-weighted network travel time |
| `D2_population_coverage_30min` | Benefit-oriented population share reachable within 30 minutes |
| `D3_svi_weighted_coverage_30min` | Vulnerability-weighted coverage sensitivity measure |
| `D4_gravity_population_accessibility` | Gravity-based demand-accessibility sensitivity measure |
| `D5_osm_route_redundancy_index` | OSM topology-derived route-redundancy proxy |
| `D6_nearest_gateway_time_min` | Cost-oriented network time to nearest pre-registered strategic gateway |
| `D7_osm_last_mile_hgv_proxy` | OSM-derived local heavy-vehicle access proxy |
| `site_area_proxy_m2` | Documented site/operational area used for D8 |
| `area_status`, `source_id` | D8 provenance and uncertainty class |

## `outputs/03_public_data_mcdm/`

| File | Contents |
|---|---|
| `all_component_utilities.csv` | D1, D2, D12, D5, D6, D7, D8 and sensitivity utilities |
| `final_public_data_utility_matrix.csv` | Frozen 16×5 primary matrix |
| `promethee_thresholds.csv` | Criterion-specific q/p values |
| `final_mcdm_rankings.csv` | PROMETHEE flows/rank, TOPSIS score/rank, VIKOR S/R/Q/rank, consensus summaries |
| `method_rank_correlations.csv` | Cross-method and D1/D2 sensitivity Spearman correlations |
| `d1_d2_sensitivity.csv` | Base, D1-only, and D2-only ranks |
| `monte_carlo_rank_acceptability.csv` | Mean/SD rank and rank-acceptability probabilities |
| `final_model_specification.json` | Machine-readable weights, definitions, exclusions, and uncertainty settings |

## `data/human/human_raw_scores.csv`

One row per expert × alternative × criterion (`240` rows).

| Field | Meaning |
|---|---|
| `expert_id`, `discipline` | Anonymised expert identifier and domain |
| `Alternative ID`, `Aday tesis`, `İlçe`, `Tesis türü` | Candidate metadata |
| `Kriter kodu` | D5, D7, or D8 |
| `Uzmanlık kapsamı` | `IN_SCOPE` or `PARTIAL` |
| `Puan 1–9` | Higher-is-better operational rating |
| `Güven 1–5` | Expert confidence |
| `Kanıt yeterliliği` | `SUFFICIENT` or `PARTLY SUFFICIENT` |
| `Gerekçe`, `Eksik kritik kanıt`, `Notlar` | Qualitative audit trail |
| `İkinci inceleme?` | Targeted follow-up flag |
| `completion_status` | Record completeness status |

## `outputs/04_human_benchmark/`

| File | Contents |
|---|---|
| `human_panel_summary.csv` | Medians, IQR, confidence-weighted utility, evidence/scope counts per 48 cells |
| `human_inter_rater_reliability.csv` | Kendall W, chi-square/p, ICC(2,k), IQR, confidence by criterion |
| `data_human_cell_concordance.csv` | Public-data score, human median, signed/absolute difference, ±1/±2 flags |
| `data_human_criterion_concordance.csv` | Bias, MAE, RMSE, score bands, rank association, top-5 overlap by criterion |
| `largest_proxy_divergences.csv` | Ten largest candidate–criterion differences |
| `human_informed_promethee_scenarios.csv` | Long-form data-only, human-median, human-confidence, and 75/25 hybrid flows/ranks |
| `decision_level_concordance.csv` | Spearman, Kendall, top-3/top-5 overlap against data-only |

## `data/expected/`

Frozen regression-test outputs. These are not model inputs. `05_validate_reproduction.py` compares regenerated outputs against them and reports the largest difference and tolerance for each check.
