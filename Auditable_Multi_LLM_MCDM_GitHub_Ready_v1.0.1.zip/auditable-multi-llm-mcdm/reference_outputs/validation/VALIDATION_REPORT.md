# Reproduction Validation Report

**Overall status:** PASS_WITH_WARNINGS

PASS: 25  |  WARN: 1  |  FAIL: 0

| Stage | Check | Status | Detail |
|---|---|---:|---|
| 01 criterion-family discovery | selected cluster counts and validity metrics | **PASS** | max \|Δ\|=4.65e-07 (tolerance=5e-06) |
| 01 criterion-family discovery | design invariants | **PASS** | all fixed |
| 01 criterion-family discovery | cosine primary and Euclidean sensitivity HDBSCAN | **PASS** | max \|Δ\|=0 (tolerance=1e-10) |
| 01 criterion-family discovery | manuscript HDBSCAN reporting alignment | **WARN** | Method-aligned cosine HDBSCAN gives 25 clusters, 15% noise, silhouette=0.630; the historical manuscript row (24 clusters, 15% noise, silhouette=0.642, ARI=0.881, NMI=0.963) is exactly reproduced by the Euclidean sensitivity run. Update the manuscript row if cosine is declared as the primary density specification. |
| 02 evidence fusion and core selection | 26-family evidence channels | **PASS** | max \|Δ\|=1.11e-16 (tolerance=1e-12) |
| 02 evidence fusion and core selection | family classifications | **PASS** | 26 keyed rows and categorical decisions agree |
| 02 evidence fusion and core selection | 10 conceptual-core weights | **PASS** | max \|Δ\|=9.71e-17 (tolerance=1e-12) |
| 02 evidence fusion and core selection | CORE_SCORING count | **PASS** | actual=10, expected=10 |
| 02 evidence fusion and core selection | OPTIONAL_ADDON count | **PASS** | actual=6, expected=6 |
| 02 evidence fusion and core selection | HARD_CONSTRAINT count | **PASS** | actual=3, expected=3 |
| 02 evidence fusion and core selection | merge/drop count | **PASS** | actual=7, expected=7 |
| 02 evidence fusion and core selection | one source-family record after within-source MAX | **PASS** | duplicate source-family pairs=0 |
| 02 evidence fusion and core selection | missing weights retained as unavailable | **PASS** | missing source-family weights retained=15; no zero imputation |
| 03 public-data MCDM | 16×5 primary utility matrix | **PASS** | max \|Δ\|=0 (tolerance=1e-12) |
| 03 public-data MCDM | PROMETHEE q/p thresholds | **PASS** | max \|Δ\|=0 (tolerance=1e-12) |
| 03 public-data MCDM | PROMETHEE II flows and ranks | **PASS** | max \|Δ\|=0 (tolerance=1e-12) |
| 03 public-data MCDM | TOPSIS/VIKOR benchmark ranks and scores | **PASS** | max \|Δ\|=0 (tolerance=1e-12) |
| 03 public-data MCDM | D12/D1-only/D2-only sensitivity | **PASS** | max \|Δ\|=0 (tolerance=0) |
| 03 public-data MCDM | 5,000-run Monte Carlo rank acceptability | **PASS** | max \|Δ\|=0 (tolerance=1e-12) |
| 03 public-data MCDM | method and specification rank correlations | **PASS** | max \|Δ\|=0 |
| 03 public-data MCDM | eligible alternatives and matrix completeness | **PASS** | eligible alternatives=16 |
| 04 blind human benchmark | 48 cell human aggregation and confidence-weighting | **PASS** | max \|Δ\|=4.48e-07 (tolerance=1e-06) |
| 04 blind human benchmark | Kendall W and ICC(2,k) | **PASS** | max \|Δ\|=4.54e-07 (tolerance=1e-06) |
| 04 blind human benchmark | overall data-human concordance | **PASS** | max \|Δ\|=0; MAE=1.725, RMSE=2.129, bias=-0.259 |
| 04 blind human benchmark | decision-level human and hybrid scenarios | **PASS** | max rank-correlation \|Δ\|=1.11e-16 |
| 04 blind human benchmark | panel completeness | **PASS** | ratings=240, experts=5, criteria=3 |

## Interpretation of the HDBSCAN warning

The manuscript methodology defines cosine dissimilarity for the semantic space. The method-aligned package therefore uses a precomputed cosine-distance matrix for the primary HDBSCAN robustness analysis. The historical implementation used Euclidean distance on L2-normalised vectors and exactly reproduces the numerical HDBSCAN row previously reported in Table 2. The two density partitions agree very strongly, and HDBSCAN is a robustness diagnostic rather than an input to the locked operational codebook, evidence weights, public-data decision matrix, or rankings. Nevertheless, the manuscript row should be labelled consistently with whichever HDBSCAN specification is declared primary.
