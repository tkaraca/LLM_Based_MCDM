# Reproducibility Protocol and Manuscript Crosswalk

## Scope

The frozen workflow reproduces the numerical analysis from the multi-LLM criterion corpus through final MCDM ranking and blind-human benchmarking. It distinguishes:

1. **criterion knowledge discovery**, which does not use importance values or approved labels for clustering;
2. **researcher-approved family locking**, represented by a frozen mapping;
3. **criterion selection and conceptual weighting**;
4. **public-data operationalisation and alternative scoring**;
5. **MCDM ranking and uncertainty analysis**;
6. **human benchmark and decision-level sensitivity**.

## Section 2 crosswalk

| Manuscript location | Analytical object | Reproducibility implementation | Input | Output |
|---|---|---|---|---|
| Section 2.1 | Raw corpus and provenance | `criterion_corpus.csv` retains all 100 raw records and source metadata | `data/criterion/criterion_corpus.csv` | same frozen table |
| Eq. (1), Section 2.2 | Name + description + parent text | `build_text()` in `01_criterion_family_discovery.py`; weighted primary uses fixed 3:2:1 field repetition | criterion corpus + config | representation-specific texts held in memory |
| Eq. (2), Section 2.3 | Word/character TF–IDF, concatenation, SVD, L2 normalisation | `make_embedding()` | full text corpus | `embedding_metadata.csv`; latent matrix used downstream |
| Eq. (3) | Cosine distance | scikit-learn cosine metric / precomputed cosine matrix | L2-normalised vectors | pairwise distances used for clustering and medoids |
| Eq. (4), Section 2.4 | Average-linkage agglomerative clustering | `agglomerative()` | latent vectors, candidate k | `k_scan.csv`, assignments and summaries |
| Eqs. (5)–(7), Section 2.5 | Silhouette, resampling ARI, constrained k selection | `resampling_stability()` and fixed selection rule | k=10…40, 100 × 85% subsamples | `k_selection.csv`; selected weighted k=32 |
| Eq. (8), Section 2.6 | Density robustness | cosine-precomputed HDBSCAN primary; Euclidean sensitivity | weighted latent vectors | `hdbscan_primary_and_sensitivity.csv`, `hdbscan_grid.csv` |
| Eq. (9) | Medoids | minimum total within-cluster cosine distance | selected and k=26 partitions | cluster summaries and assignment tables |
| Sections 2.7–2.8 | Human naming, merge/split adjudication, codebook locking | code generates review candidates/template; consumes frozen mapping only after discovery | medoids/members/boundaries + frozen mapping | `researcher_adjudication_template.csv`, `approved_family_codebook.csv` |

## Section 3 crosswalk

| Manuscript location | Analytical object | Reproducibility implementation | Output |
|---|---|---|---|
| Section 3.1 | Family/core/optional/hard-constraint sets | frozen codebook plus classification fields | evidence-fusion tables |
| Before Eq. (11) | Within-source fragmentation control | group by source and family; retain MAX available global importance; preserve aliases; recalculate family ranks | `source_family_records.csv` |
| Eq. (11) | Cross-source coverage | number of sources in which family is present / 5 | `coverage_ratio` |
| Eq. (12) | Median and maximum-normalised importance | median over available numerical source-family weights only | `median_global_weight`, `norm_median_global_weight` |
| Eq. (13) | Within-source percentile | recalculated after source-family MAX consolidation | `median_percentile` |
| Eq. (14) | Support balance | top and bottom bands 0.80/0.20 | `top_support_ratio`, `bottom_support_ratio`, `support_balance` |
| Eq. (15) | Completeness and disagreement | available numerical weights / family-presence records; percentile IQR | `completeness_ratio`, `iqr_percentile` |
| Eq. (16) | Evidence fusion | configured coefficients, disagreement penalty, completeness contribution, acute-phase adjustment | `evidence_score`, `final_score` |
| Eq. (17) | Group-balanced core selection | primary score/coverage thresholds, upper/lower quotas, secondary score/coverage backfill, target 10–12 | `selection_audit.csv`, 10 conceptual core families |
| Eq. (18) | Conceptual core weights | nonnegative final scores normalised over selected conceptual core | `conceptual_core_weights.csv` |
| Eq. (19) | Empirical redundancy composite | D1 + D2 → D12 with joint weight retained and fixed internal shares | final five-criterion specification |
| Section 3.4 | Data audit and re-operationalisation | frozen criterion-audit decision table; no imputation of unsupported constructs | `criterion_audit_decisions.csv` |
| Eq. (20), Section 3.5 | Candidate eligibility and hard constraints | 18-candidate registry; two pre-ranking exclusions; hard constraints remain NOT VERIFIED flags | 16 eligible alternatives |
| Eqs. (21a–b) | Benefit/cost normalisation | `minmax()`; D8 uses log1p before benefit normalisation | final utility matrix |
| Eqs. (22)–(24) | Human median, confidence weighting, hybrid utility | `04_human_benchmark.py` | panel summary and scenario matrices |
| Eqs. (25)–(28) | PROMETHEE II | Q25/Q75 nonzero pairwise utility differences; linear preference; positive/negative/net flows | thresholds and rankings |
| Eqs. (29)–(30) | TOPSIS and VIKOR | deterministic benchmark implementations; VIKOR v=0.50 | benchmark ranks and correlations |
| Eq. (31) | Monte Carlo rank acceptability | Dirichlet weights, shared q/p multiplier, source-sensitive D8 lognormal error, seed 20261008 | 5,000-run acceptability table |
| Eqs. (32)–(34) | Human reliability and data–human concordance | tie-corrected Kendall W; ICC(2,k); 1–9 back-transform; MAE/RMSE/bias | human reliability/concordance outputs |

## Frozen parameters

All fixed values are stored in `config/study_config.json`. Principal values:

- TF–IDF word n-grams: 1–2;
- character n-grams: 3–5;
- character block multiplier: 0.7;
- SVD dimensions: 50;
- embedding seed: 42;
- resampling seed: 20261015;
- resampling: 100 repetitions, 85%, without replacement;
- k range: 10–40;
- η=0.95, τ=0.90, ρmax=0.40;
- evidence coefficients: 0.35/0.25/0.20/0.20;
- disagreement penalty: 0.10;
- completeness contribution: 0.05;
- primary score/coverage: 0.60/0.40;
- secondary backfill score/coverage: 0.45/0.40;
- final public weights: D12=0.3864862659, D5=0.1854841605, D7=0.1535391947, D6=0.1456039562, D8=0.1288864226;
- Monte Carlo: 5,000 iterations, seed 20261008, Dirichlet concentration 180, q/p multiplier 0.75–1.25, D8 σ=0.04 official and 0.15 secondary/multi-source;
- confidence weighting: confidence/5 × evidence factor × scope factor;
- evidence factors: sufficient 1.00, partly sufficient 0.75;
- scope factors: in-scope 1.00, partial 0.75;
- hybrid: 75% public data + 25% human median for D5/D7/D8 only.

## Reproduction commands

Full frozen run:

```bash
python run_all.py
```

Individual stages:

```bash
python src/01_criterion_family_discovery.py --root .
python src/02_criterion_evidence_fusion.py --root .
python src/03_public_data_mcdm.py --root . --monte-carlo 5000
python src/04_human_benchmark.py --root .
python src/05_validate_reproduction.py --root .
```

## Determinism

- TF–IDF and clustering are deterministic conditional on the corpus and configuration.
- Truncated SVD uses seed 42.
- Resampling uses seed 20261015.
- Monte Carlo uses seed 20261008.
- Evidence fusion, deterministic MCDM methods, human aggregation, and reliability calculations do not draw random numbers.
- CSV output order is explicitly sorted before writing where order is analytically relevant.

## Validation acceptance

The full validation suite compares regenerated outputs with frozen expected artifacts. Tight tolerances are used because the reference environment is pinned. A PASS/WARN distinction is maintained for the HDBSCAN metric-reporting issue. No result is silently coerced to match the expected output.
